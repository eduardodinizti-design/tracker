"""Backend leve do NVT Tracker (sem dependências novas): serve as telas de ui/ e expõe
endpoints JSON que reaproveitam a camada de dados (stats, bb/100, EV, sessões, posições…).

    python -m nvttracker.viz.server          (usa NVT_DATABASE_URL)
    nvt-server --port 8750

As telas em ui/*.html buscam /api/* e se preenchem com dados reais do banco."""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
from decimal import Decimal
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from nvttracker.db import connect, migrate            # noqa: E402
from nvttracker.viz import data                        # noqa: E402

UI_DIR = Path(__file__).resolve().parent / "ui"
_DSN = os.environ.get("NVT_DATABASE_URL")

_MIME = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript",
         ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json"}


@lru_cache(maxsize=1)
def _conn():
    c = connect(_DSN)
    migrate(c)
    return c


def _json_default(o):
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
        return None
    return str(o)


def _clean(v):
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    if isinstance(v, Decimal):
        return float(v)
    return v


# ------------------------------------------------------------------ endpoints
def _member():
    """Membro autorizado atual (e-mail salvo + reverificado no banco), ou None."""
    from nvttracker import auth
    try:
        return auth.authorize(_conn(), auth.load_email())
    except Exception:
        return None


def api_auth_status(q):
    m = _member()
    return {"authorized": bool(m), "email": (m or {}).get("email"), "name": (m or {}).get("name")}


def api_version(q):
    """Versão atual + se há update no manifesto remoto (NVT_UPDATE_URL)."""
    from nvttracker import updater
    from nvttracker._version import __version__
    man = updater.check_manifest(os.environ.get("NVT_UPDATE_URL"), timeout=4.0)
    latest = man.get("version") if man else __version__
    return {"current": __version__, "latest": latest,
            "update_available": bool(man and updater.is_newer(latest, __version__)),
            "notes": (man or {}).get("notes", ""), "url": (man or {}).get("url", "")}


def api_overview(q):
    c = _conn()
    hands = c.execute("SELECT count(*) FROM hands").fetchone()[0]
    players = c.execute("SELECT count(DISTINCT player_id) FROM stat_acc").fetchone()[0]
    rooms = [{"room": r, "fmt": f, "n": n}
             for r, f, n in c.execute("SELECT room, format, count(*) FROM hands GROUP BY 1,2 ORDER BY 3 DESC")]
    mn, mx = c.execute("SELECT min(started_utc), max(started_utc) FROM hands").fetchone()
    return {"hands": hands, "players": players, "rooms": rooms,
            "date_min": mn.isoformat() if mn else None, "date_max": mx.isoformat() if mx else None}


def _profile(hands, vpip):
    if hands is None or hands < 500:
        return "Em análise"
    if vpip is not None and vpip > 35:
        return "Recreativo"
    return "Regular"


def api_players(q):
    fmt = (q.get("fmt", ["tournament"])[0])
    room = q.get("room", [None])[0]
    limit = int(q.get("limit", ["300"])[0])
    df = data.players_table(_conn(), fmt=fmt, room=room or None)
    if df.empty:
        return {"players": []}
    df = df.sort_values("Mãos", ascending=False).head(limit)
    out = []
    for _, r in df.iterrows():
        vpip = _clean(r.get("VPIP"))
        hands = int(r.get("Mãos") or 0)
        out.append({"nick": r.get("Jogador"), "room": r.get("Sala"), "hands": hands,
                    "profile": _profile(hands, vpip), "vpip": vpip, "pfr": _clean(r.get("PFR")),
                    "three_bet": _clean(r.get("3Bet"))})
    return {"players": out, "total": len(out)}


def api_player(q):
    pid = q.get("id", [None])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    if not pid:
        return {"error": "id obrigatório"}
    detail = data.player_detail(_conn(), room, pid, fmt)
    stats = {s: {"pct": _clean(sl.pct), "opps": sl.opps} for s, sl in detail.items()}
    hands = detail["vpip"].opps if "vpip" in detail else 0
    return {"id": pid, "room": room, "fmt": fmt, "hands": hands, "stats": stats}


def api_range(q):
    """Matriz 13×13 de uma ação (stat) para um jogador: frequência por mão inicial."""
    from nvttracker.stats.range_matrix import all_combos

    pid = q.get("player", [""])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    stat = q.get("stat", ["pfr"])[0]
    lim = int(q.get("limit", ["1500"])[0])
    if not pid:
        return {"combos": all_combos(), "grid": {}}
    g = data.range_grid(_conn(), room, pid, fmt, stat, limit=lim)
    grid = {c: {"opps": o, "cases": k, "freq": round(100.0 * k / o, 1) if o else None}
            for c, (o, k) in g.items()}
    total = sum(o for o, _ in g.values())
    return {"combos": all_combos(), "grid": grid, "sample": total, "stat": stat}


def api_postflop(q):
    """Pós-flop por textura do board (c-bet por Rainbow/Two-tone/Monotone/Pareado)."""
    from nvttracker.stats.postflop_texture import TEXTURES

    pid = q.get("player", [""])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    stat = q.get("stat", ["cbet_flop"])[0]
    lim = int(q.get("limit", ["1500"])[0])
    if not pid:
        return {"textures": TEXTURES, "rows": {}}
    g = data.postflop_by_texture(_conn(), room, pid, fmt, stat, limit=lim)
    rows = {t: {"opps": o, "cases": k, "freq": round(100.0 * k / o, 1) if o else None}
            for t, (o, k) in g.items()}
    return {"textures": TEXTURES, "rows": rows, "stat": stat}


def api_marked(q):
    """Mãos marcadas do jogador (aba Marcadas)."""
    pid = q.get("player", [""])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    if not pid:
        return {"hands": []}
    df = data.marked_hands(_conn(), room, pid, fmt)
    if df.empty:
        return {"hands": []}
    return {"hands": [{k: _clean(v) for k, v in r.items()} for _, r in df.iterrows()]}


def api_sessions(q):
    """Sessões do jogador (corte por intervalo de tempo): ganho/EV/duração/VPIP/PFR por sessão."""
    pid = q.get("player", [None])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    if not pid:
        return {"sessions": []}
    lim = int(q.get("limit", ["800"])[0])
    with_ev = q.get("ev", ["0"])[0] in ("1", "true")
    gap = int(q.get("gap", ["30"])[0])
    df = data.sessions(_conn(), room, pid, fmt, gap_minutes=gap, limit=lim, with_ev=with_ev)
    if df.empty:
        return {"sessions": []}
    return {"sessions": [{k: _clean(v) for k, v in r.items()} for _, r in df.iterrows()]}


def api_hand_results(q):
    """Mãos de um jogador com resultado (net_bb) — rápido, direto do banco (sem parsear).
    Serve a Revisão de sessão (maiores perdas/ganhos) e o Explorador."""
    pid = q.get("player", [None])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    tour = q.get("tournament", [None])[0]
    order = q.get("sort", ["net_asc"])[0]
    limit = min(int(q.get("limit", ["200"])[0]), 1000)
    if not pid:
        return {"hands": []}
    ob = {"net_asc": "hp.net_bb ASC", "net_desc": "hp.net_bb DESC", "recent": "h.started_utc DESC"}.get(order, "hp.net_bb ASC")
    extra, args = "", [pid, room, fmt]
    if tour:
        extra = "AND h.tournament_id=%s"
        args.append(tour)
    rows = _conn().execute(f"""
        SELECT h.hand_pk, h.tournament_id, h.started_utc, hp.position, hp.net_bb, hp.cards,
               array_to_string(h.board,' '), h.pot, h.bb, hp.went_sd, hp.won_sd
        FROM hands h JOIN hand_players hp USING (hand_pk)
        WHERE hp.player_id=%s AND h.room=%s AND h.format=%s {extra}
        ORDER BY {ob} LIMIT {limit}""", args).fetchall()
    out = []
    for pk, tid, ts, pos, net, cards, board, pot, bb, sd, wsd in rows:
        net = _clean(net)
        bbv = float(bb) if bb else 1.0
        diag = None
        if net is not None and sd and net < 0:
            diag = "perdeu no showdown"
        elif net is not None and net <= -30:
            diag = "grande perda sem showdown"
        elif net is not None and net >= 30:
            diag = "grande ganho"
        out.append({"pk": pk, "tournament": tid, "when": ts.isoformat() if ts else None,
                    "position": pos, "net_bb": round(net, 1) if net is not None else None,
                    "cards": cards or [], "board": board, "pot_bb": round(float(pot) / bbv, 1) if pot else None,
                    "went_sd": sd, "won_sd": wsd, "diag": diag})
    return {"hands": out}


def api_winnings(q):
    """Curva de ganhos (Won / All-in EV / showdown) de um jogador, em bb."""
    pid = q.get("player", [None])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    if not pid:
        return {"points": []}
    lim = int(q.get("limit", ["500"])[0])
    with_ev = q.get("ev", ["0"])[0] in ("1", "true")
    df = data.winnings(_conn(), room, pid, fmt, limit=lim, with_ev=with_ev)
    if df.empty:
        return {"points": []}
    pts = [{"n": int(i), "won": _clean(r["Won (real)"]), "ev": _clean(r["All-in EV"]),
            "sd": _clean(r["Ganho no showdown"]), "nosd": _clean(r["Ganho sem showdown"])}
           for i, r in df.iterrows()]
    last = pts[-1]
    return {"points": pts, "total": {"won": last["won"], "ev": last["ev"], "sd": last["sd"], "nosd": last["nosd"]}}


def api_by_position(q):
    """Stats + bb/100 + EV bb/100 por posição de um jogador."""
    pid = q.get("player", [None])[0]
    room = q.get("room", ["PPPoker"])[0]
    fmt = q.get("fmt", ["tournament"])[0]
    if not pid:
        return {"rows": []}
    lim = int(q.get("limit", ["500"])[0])
    with_ev = q.get("ev", ["0"])[0] in ("1", "true")
    df = data.by_position(_conn(), room, pid, fmt, limit=lim, with_ev=with_ev)
    if df.empty:
        return {"rows": [], "cols": []}
    rows = [{k: _clean(v) for k, v in r.items()} for _, r in df.iterrows()]
    return {"rows": rows, "cols": list(df.columns)}


def api_tournaments(q):
    room = q.get("room", [None])[0]
    limit = int(q.get("limit", ["200"])[0])
    cond = "WHERE tournament_id IS NOT NULL" + (" AND room=%s" if room else "")
    args = (room,) if room else ()
    rows = _conn().execute(f"""
        SELECT tournament_id, room, count(*) AS n, min(started_utc), max(started_utc)
        FROM hands {cond} GROUP BY tournament_id, room ORDER BY max(started_utc) DESC LIMIT {limit}
    """, args).fetchall()
    return {"tournaments": [{"id": t, "room": r, "hands": n,
                             "date_min": mn.isoformat() if mn else None, "date_max": mx.isoformat() if mx else None}
                            for t, r, n, mn, mx in rows]}


import re as _re


def _parse_buyin(text):
    """'$40 USD'->40.0 · '$45.60 USD'->45.6 · '¥33+¥8.50 CNY'->41.5 (buy-in+fee)."""
    if not text:
        return None
    nums = _re.findall(r"\d+(?:\.\d+)?", text)
    if not nums:
        return None
    if "+" in text and len(nums) >= 2:
        return round(float(nums[0]) + float(nums[1]), 2)
    return float(nums[0])


def api_tournament_control(q):
    """Controle de torneios: histórico (buy-in, entrada/queda, mãos) + economia do ledger
    (field, reentradas, rebuys, colocação, prêmio) → investimento, lucro e ROI reais."""
    pid = q.get("player", [None])[0]
    room = q.get("room", [None])[0]
    limit = int(q.get("limit", ["400"])[0])
    cond, args = "h.format='tournament'", []
    if pid:
        cond += " AND EXISTS (SELECT 1 FROM hand_players hp WHERE hp.hand_pk=h.hand_pk AND hp.player_id=%s)"
        args.append(pid)
    if room:
        cond += " AND h.room=%s"
        args.append(room)
    c = _conn()
    rows = c.execute(f"""
        SELECT h.tournament_id, h.room, max(h.buyin_text), max(h.currency),
               min(h.started_utc), max(h.started_utc), count(*)
        FROM hands h WHERE {cond} GROUP BY h.tournament_id, h.room
        ORDER BY max(h.started_utc) DESC LIMIT {limit}""", args).fetchall()
    led = {}
    if pid:
        for r in c.execute("""SELECT room,tournament_id,name,my_entries,rebuys,addons,field_size,
                              position,prize,itm,extra_cost FROM tournament_results WHERE player_id=%s""", (pid,)):
            led[(r[0], r[1])] = r
    out = []
    for tid, rm, bi, cur, mn, mx, n in rows:
        buyin = _parse_buyin(bi)
        L = led.get((rm, tid))
        entries = L[3] if L else 1
        rebuys = L[4] if L else 0
        extra = float(L[10]) if L and L[10] is not None else 0.0
        prize = float(L[8]) if L and L[8] is not None else None
        invest = round(buyin * entries + extra, 2) if buyin is not None else None
        profit = round(prize - invest, 2) if (prize is not None and invest is not None) else None
        roi = round(profit / invest * 100, 1) if (profit is not None and invest) else None
        out.append({"id": tid, "room": rm, "name": (L[2] if L else None),
                    "buyin_text": bi, "buyin": buyin, "currency": cur,
                    "entry_time": mn.isoformat() if mn else None, "bust_time": mx.isoformat() if mx else None,
                    "duration_min": round((mx - mn).total_seconds() / 60) if mn and mx else None, "hands": n,
                    "entries": entries, "rebuys": rebuys, "field_size": (L[6] if L else None),
                    "position": (L[7] if L else None), "prize": prize, "itm": (L[9] if L else None),
                    "invest": invest, "profit": profit, "roi": roi})
    return {"tournaments": out}


def api_hands_txt(q):
    """Texto (.txt) das mãos de um torneio / jogador / recentes — alimenta o Replay."""
    tour = q.get("tournament", [None])[0]
    pid = q.get("player", [None])[0]
    limit = min(int(q.get("limit", ["400"])[0]), 1000)
    if tour:
        where, args = "h.tournament_id=%s", (tour,)
    elif pid:
        where, args = "EXISTS (SELECT 1 FROM hand_players hp WHERE hp.hand_pk=h.hand_pk AND hp.player_id=%s)", (pid,)
    else:
        where, args = "TRUE", ()
    rows = _conn().execute(f"""
        SELECT r.raw_text FROM hands h
        JOIN LATERAL (SELECT raw_text FROM hand_raw hr WHERE hr.hand_pk=h.hand_pk ORDER BY length(raw_text) DESC LIMIT 1) r ON TRUE
        WHERE {where} ORDER BY h.started_utc LIMIT {limit}
    """, args).fetchall()
    txt = "\n\n".join(x[0] for x in rows)
    return {"txt": txt, "count": len(rows)}


ROUTES = {"/api/version": api_version, "/api/auth/status": api_auth_status,
          "/api/overview": api_overview, "/api/players": api_players, "/api/player": api_player,
          "/api/tournaments": api_tournaments, "/api/hands_txt": api_hands_txt,
          "/api/tournament_control": api_tournament_control,
          "/api/winnings": api_winnings, "/api/by_position": api_by_position,
          "/api/hand_results": api_hand_results, "/api/sessions": api_sessions,
          "/api/marked": api_marked, "/api/range": api_range, "/api/postflop": api_postflop}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        u = urlparse(self.path)
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            if u.path == "/api/tournament_result":
                from nvttracker.stats.tournament_ledger import record_from_capture
                record_from_capture(_conn(), body["room"], str(body["tournament_id"]), str(body["player_id"]),
                                    rank=body.get("rank") or body.get("position"), field=body.get("field") or body.get("field_size"),
                                    prize=body.get("prize"), name=body.get("name"),
                                    entries=int(body.get("entries", 1)), rebuys=int(body.get("rebuys", 0)))
            elif u.path == "/api/auth/login":
                from nvttracker import auth
                m = auth.authorize(_conn(), body.get("email"))
                if not m:
                    self._send(403, json.dumps({"error": "E-mail não autorizado. Fale com o admin do NVT."}).encode("utf-8"))
                    return
                auth.save_email(m["email"])
                self._send(200, json.dumps({"ok": True, "name": m["name"]}).encode("utf-8"))
                return
            elif u.path == "/api/auth/logout":
                from nvttracker import auth
                auth.clear_email()
                self._send(200, json.dumps({"ok": True}).encode("utf-8"))
                return
            elif u.path == "/api/mark":
                pk = int(body["hand_pk"])
                if body.get("action") == "unmark":
                    data.unmark_hand(_conn(), pk)
                else:
                    tags = body.get("tags") or []
                    if isinstance(tags, str):
                        tags = [t.strip() for t in tags.split(",") if t.strip()]
                    data.mark_hand(_conn(), pk, tags, body.get("note", ""))
            else:
                self._send(404, b"not found", "text/plain")
                return
            self._send(200, json.dumps({"ok": True}).encode("utf-8"))
        except Exception as e:  # noqa: BLE001
            self._send(400, json.dumps({"error": str(e)}).encode("utf-8"))

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ROUTES:
            if u.path not in ("/api/version", "/api/auth/status") and not _member():
                self._send(403, json.dumps({"error": "não autorizado"}).encode("utf-8"))
                return
            try:
                payload = ROUTES[u.path](parse_qs(u.query))
                body = json.dumps(payload, default=_json_default, ensure_ascii=False).encode("utf-8")
                self._send(200, body)
            except Exception as e:  # noqa: BLE001
                self._send(500, json.dumps({"error": str(e)}).encode("utf-8"))
            return
        # estático de ui/
        rel = u.path.lstrip("/") or "nvt_app.html"
        fpath = (UI_DIR / rel).resolve()
        if not str(fpath).startswith(str(UI_DIR)) or not fpath.is_file():
            self._send(404, b"not found", "text/plain")
            return
        self._send(200, fpath.read_bytes(), _MIME.get(fpath.suffix, "application/octet-stream"))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="nvt-server", description="Backend + telas do NVT Tracker")
    ap.add_argument("--port", type=int, default=8750)
    ap.add_argument("--dsn")
    a = ap.parse_args(argv)
    global _DSN
    if a.dsn:
        _DSN = a.dsn
    _conn()  # falha cedo se o banco não conectar
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    print(f"NVT Tracker em http://127.0.0.1:{a.port}  (Ctrl+C para parar)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
