/* NVT Tracker — shell compartilhado: injeta a nav lateral e a barra de topo em cada tela. */
(function () {
  const ICON = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    bars: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
    cal:  '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    users:'<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/><path d="M17 15c2 0 4 2 4 5"/>',
    cards:'<rect x="4" y="3" width="11" height="15" rx="2"/><rect x="9" y="6" width="11" height="15" rx="2"/>',
    hud:  '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
    book: '<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2z"/><path d="M4 19V5"/>',
    down: '<path d="M12 3v12M8 11l4 4 4-4"/><path d="M4 21h16"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.1-1l2-1.6-2-3.4-2.3 1a7 7 0 00-1.7-1l-.4-2.5H10l-.4 2.5a7 7 0 00-1.7 1l-2.3-1-2 3.4 2 1.6a7 7 0 000 2l-2 1.6 2 3.4 2.3-1a7 7 0 001.7 1l.4 2.5h3.9l.4-2.5a7 7 0 001.7-1l2.3 1 2-3.4-2-1.6c.1-.3.1-.7.1-1z"/>',
    chev: '<path d="M6 9l6 6 6-6"/>'
  };
  const NAV = [
    ['overview', 'Visão geral', 'home', 'nvt_app.html'],
    ['resultados', 'Resultados', 'bars', 'resultados.html'],
    ['sessoes', 'Sessões', 'cal', 'sessoes.html'],
    ['jogadores', 'Jogadores', 'users', 'jogadores.html'],
    ['maos', 'Mãos', 'cards', 'explorador.html'],
    ['estatisticas', 'Estatísticas', 'bars', 'estatisticas.html'],
    ['hud', 'HUD Studio', 'hud', 'hud_biblioteca.html'],
    ['estudo', 'Estudo', 'book', 'caderno.html'],
    ['importacoes', 'Importações', 'down', 'importacoes.html'],
    ['config', 'Configurações', 'gear', 'config.html']
  ];
  const svg = (n) => '<svg viewBox="0 0 24 24">' + ICON[n] + '</svg>';

  function navHTML(active) {
    const items = NAV.map(([k, label, ic, file]) =>
      `<a class="item${k === active ? ' active' : ''}" href="${file}">${svg(ic)}${label}</a>`).join('');
    return `<aside class="nav">
      <div class="brand"><img src="nvt_logo.png" alt="NVT">
        <div><div class="bt">NVT <span>TRACKER</span></div>
        <div class="bs">Análise · Resultados · Estudo</div></div></div>
      ${items}<div class="spacer"></div><div class="motto">NADA VENCE O TRABALHO</div></aside>`;
  }
  function crumbHTML(crumbs) {
    const parts = crumbs.map((c, i) =>
      i === crumbs.length - 1 ? `<span class="cur">${c}</span>` : `<span>${c}</span>`);
    return `<div class="crumb">${svg('home')}<span class="sep">›</span>` +
      parts.join('<span class="sep">›</span>') + `</div>`;
  }
  window.NVT = {
    shell(opts) {
      document.body.insertAdjacentHTML('afterbegin', navHTML(opts.active));
      const bar = `<div class="topbar">${crumbHTML(opts.crumb || ['Visão geral'])}
        <div class="right">
          <div class="pill">${svg('cal')}Últimos 30 dias ${svg('chev')}</div>
          <div class="pill"><span class="av"></span>Eduardo ${svg('chev')}</div>
        </div></div>`;
      document.querySelector('.main').insertAdjacentHTML('afterbegin', bar);
      // autorização: só jogadores do NVT (e-mail cadastrado). Senão, vai pro login.
      fetch('/api/auth/status').then(function (r) { return r.json(); }).then(function (s) {
        if (!s.authorized) { location.replace('login.html'); return; }
        if (s.name) {
          var pills = document.querySelectorAll('.topbar .right .pill');
          var up = pills[pills.length - 1];
          if (up) { up.lastChild.textContent = ' ' + s.name + ' '; up.title = s.email || ''; up.style.cursor = 'pointer';
            up.onclick = function () { if (confirm('Sair da conta ' + (s.email || '') + '?'))
              fetch('/api/auth/logout', { method: 'POST' }).then(function () { location.href = 'login.html'; }); }; }
        }
      }).catch(function () {});
      // banner de nova versão (auto-update)
      fetch('/api/version').then(function (r) { return r.json(); }).then(function (v) {
        if (!v || !v.update_available) return;
        var b = document.createElement('div');
        b.style.cssText = 'background:linear-gradient(90deg,#f2b50d,#8a6a12);color:#17130a;font-weight:800;' +
          'padding:9px 18px;display:flex;align-items:center;gap:12px;font-family:Arial,sans-serif';
        b.innerHTML = '✨ Nova versão <b>' + v.latest + '</b> disponível' +
          (v.notes ? ' — ' + v.notes : '') +
          ' &nbsp;·&nbsp; será aplicada automaticamente ao reabrir o NVT Tracker.' +
          '<span style="margin-left:auto;cursor:pointer;opacity:.7" onclick="this.parentNode.remove()">✕</span>';
        document.querySelector('.main').insertAdjacentHTML('afterbegin', '');
        document.querySelector('.topbar').insertAdjacentElement('afterend', b);
      }).catch(function () {});
    }
  };
})();
