"""NvtTracker: importação de históricos de mãos NLHE e cálculo de stats do time NVT."""

__version__ = "0.1.0"

# pasta padrão dos históricos .txt no Windows (nome da pasta no disco; ajustável em hh_folder)
DEFAULT_HH_FOLDER = r"C:\Hand2Note4Hh"
