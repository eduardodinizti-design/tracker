"""Administração de jogadores: um usuário de banco por membro do time (grupo ``nvt_player``).

A senha é gerada aqui e só o verificador SCRAM-SHA-256 vai para o banco; o texto da senha existe apenas no
``nvt_config.ini`` gerado para o jogador.
"""
from __future__ import annotations

import base64
import configparser
import hashlib
import hmac
import os
import re
import secrets
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote, urlencode

import psycopg
from psycopg import sql
from psycopg.conninfo import conninfo_to_dict

from . import DEFAULT_HH_FOLDER
from .ingest.discovery import MEMBER_ID

PLAYER_GROUP = "nvt_player"
ADMIN_CONFIG = Path(os.path.expandvars(r"%USERPROFILE%\.nvttracker\nvt_admin.ini")) if os.name == "nt" \
    else Path.home() / ".nvttracker" / "nvt_admin.ini"


def admin_dsn(explicit: str | None = None, config: Path | None = None) -> str:
    """DSN do admin: argumento, ``NVT_ADMIN_DATABASE_URL`` ou ``[nvt] database_url`` do nvt_admin.ini."""
    if explicit:
        return explicit
    if os.environ.get("NVT_ADMIN_DATABASE_URL"):
        return os.environ["NVT_ADMIN_DATABASE_URL"]
    path = config or ADMIN_CONFIG
    if path.exists():
        cfg = configparser.ConfigParser()
        cfg.read(path, encoding="utf-8-sig")
        if cfg.has_option("nvt", "database_url") and cfg["nvt"]["database_url"].strip():
            return cfg["nvt"]["database_url"].strip()
    raise RuntimeError(f"URL do admin não encontrada (use --dsn, NVT_ADMIN_DATABASE_URL ou {path})")


def role_name(member_id: str) -> str:
    if not MEMBER_ID.match(member_id):
        raise ValueError(f"member_id inválido: {member_id!r}")
    return "nvt_" + re.sub(r"[^a-z0-9_]", "_", member_id.lower())


def scram_verifier(password: str, iterations: int = 4096) -> str:
    """Verificador no formato que o PostgreSQL aceita em ``PASSWORD '...'`` (o banco nunca vê a senha)."""
    salt = os.urandom(16)
    salted = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    stored = hashlib.sha256(hmac.new(salted, b"Client Key", "sha256").digest()).digest()
    server = hmac.new(salted, b"Server Key", "sha256").digest()
    b64 = lambda x: base64.b64encode(x).decode()  # noqa: E731
    return f"SCRAM-SHA-256${iterations}:{b64(salt)}${b64(stored)}:{b64(server)}"


def player_dsn(admin: str, role: str, password: str) -> str:
    """URL do jogador no mesmo servidor do admin. No pooler do Supabase o usuário leva o sufixo ``.<projeto>``."""
    p = conninfo_to_dict(admin)
    user = p.get("user", "")
    login = f"{role}.{user.split('.', 1)[1]}" if "." in user else role
    query = {k: p[k] for k in ("sslmode",) if k in p}
    port = f":{p['port']}" if p.get("port") else ""
    url = f"postgresql://{quote(login, safe='')}:{quote(password, safe='')}@{p.get('host', 'localhost')}{port}/" \
          f"{p.get('dbname', 'postgres')}"
    return url + (f"?{urlencode(query)}" if query else "")


@dataclass(frozen=True)
class PlayerCredentials:
    member_id: str
    role: str
    dsn: str          # contém a senha: grave no .ini, não exiba


def add_player(conn: psycopg.Connection, admin: str, member_id: str, name: str | None = None) -> PlayerCredentials:
    """Cria (ou reativa com senha nova) o usuário do membro, no grupo ``nvt_player``."""
    role = role_name(member_id)
    password = secrets.token_urlsafe(24)
    verifier = scram_verifier(password)
    schema = conn.execute("SELECT current_schema()").fetchone()[0]
    with conn.transaction():
        exists = conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,)).fetchone()
        if exists:
            conn.execute(sql.SQL("ALTER ROLE {} LOGIN PASSWORD {}").format(sql.Identifier(role), sql.Literal(verifier)))
        else:
            conn.execute(sql.SQL("CREATE ROLE {} LOGIN PASSWORD {} IN ROLE {}").format(
                sql.Identifier(role), sql.Literal(verifier), sql.Identifier(PLAYER_GROUP)))
        conn.execute(sql.SQL("ALTER ROLE {} SET search_path = {}").format(sql.Identifier(role), sql.Identifier(schema)))
        conn.execute("""
            INSERT INTO nvt_members (member_id, name, db_user) VALUES (%s, %s, %s)
            ON CONFLICT (member_id) DO UPDATE SET db_user = EXCLUDED.db_user,
                name = COALESCE(%s, nvt_members.name)""", (member_id, name or member_id, role, name))
    return PlayerCredentials(member_id, role, player_dsn(admin, role, password))


def remove_player(conn: psycopg.Connection, member_id: str) -> str:
    """Bloqueia o login do jogador (as mãos e o histórico dele continuam no banco)."""
    role = role_name(member_id)
    if not conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,)).fetchone():
        raise ValueError(f"usuário {role} não existe")
    conn.execute(sql.SQL("ALTER ROLE {} NOLOGIN").format(sql.Identifier(role)))
    return role


def list_players(conn: psycopg.Connection) -> list[tuple]:
    return conn.execute("""
        SELECT m.member_id, m.db_user, coalesce(r.rolcanlogin, false) AS ativo,
               (SELECT count(*) FROM hand_sources s WHERE s.member_id = m.member_id) AS maos_enviadas
        FROM nvt_members m LEFT JOIN pg_roles r ON r.rolname = m.db_user ORDER BY m.member_id""").fetchall()


def write_player_config(path: Path, creds: PlayerCredentials, hh_folder: str = DEFAULT_HH_FOLDER) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"""[nvt]
; NvtTracker do membro {creds.member_id} (usuário de banco {creds.role}). Não compartilhe este arquivo.
database_url = {creds.dsn}
member = {creds.member_id}
; pasta de historicos de mao (.txt) monitorada (vazio = padrao do programa)
hh_folder = {'' if hh_folder == DEFAULT_HH_FOLDER else hh_folder}
; maos dos OUTROS membros do time gravadas em .txt (formato padrao de historico)
export_enabled = true
export_folder = C:\\NvtTimeHH
; so exporta maos terminadas ha pelo menos N minutos
export_delay_min = 30
port = 8501
""", encoding="utf-8")
    return path
