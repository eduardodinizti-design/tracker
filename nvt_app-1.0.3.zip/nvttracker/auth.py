"""Autorização do NVT Tracker: só entra quem é jogador do NVT (e-mail cadastrado e ativo em
nvt_members). O e-mail logado fica guardado por máquina (user.json em %LOCALAPPDATA%); a cada
abertura o servidor reverifica no banco (assim dá pra revogar acesso)."""
from __future__ import annotations

import json
import os
from pathlib import Path

import psycopg


def config_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = Path(base) / "NvtTracker"
    d.mkdir(parents=True, exist_ok=True)
    return d / "user.json"


def load_email() -> str | None:
    try:
        return json.loads(config_path().read_text(encoding="utf-8")).get("email") or None
    except Exception:
        return None


def save_email(email: str) -> None:
    try:
        config_path().write_text(json.dumps({"email": email.strip()}), encoding="utf-8")
    except Exception:
        pass


def clear_email() -> None:
    try:
        config_path().unlink()
    except Exception:
        pass


def authorize(conn: psycopg.Connection, email: str | None) -> dict | None:
    """Devolve {member_id, name, email} se o e-mail é de um membro ATIVO; senão None."""
    if not email or not email.strip():
        return None
    r = conn.execute(
        "SELECT member_id, name, email FROM nvt_members WHERE lower(email)=lower(%s) AND active",
        (email.strip(),)).fetchone()
    return {"member_id": r[0], "name": r[1], "email": r[2]} if r else None
