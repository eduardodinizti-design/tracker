"""Linha de comando: ``nvt-validate <pasta>`` roda o parser sobre uma pasta de históricos e mostra o relatório."""
from __future__ import annotations

import argparse
import sys
import time
from collections import Counter
from pathlib import Path

from . import DEFAULT_HH_FOLDER
from .parser import parse_file


def validate(folder: Path, show_errors: int = 5) -> dict:
    files = sorted(folder.rglob("*.txt"))
    totals: Counter = Counter()
    reasons: Counter = Counter()
    warnings: Counter = Counter()
    samples: list[str] = []
    t0 = time.perf_counter()
    for f in files:
        r = parse_file(f, final=True)
        totals["arquivos"] += 1
        totals["maos_ok"] += len(r.hands)
        totals["quarentena"] += len(r.errors)
        for h in r.hands:
            totals[f"{h.room}/{h.format.value}"] += 1
            totals["com_hero"] += h.hero is not None
            for w in h.warnings:
                warnings[w[:60]] += 1
        for b, e in r.errors:
            reasons[e.reason] += 1
            if len(samples) < show_errors:
                samples.append(f"{f.name} @ {b.offset}: {e}")
    elapsed = time.perf_counter() - t0
    total = totals["maos_ok"] + totals["quarentena"]
    return {"totais": dict(totals), "quarentena_por_motivo": dict(reasons), "exemplos_erro": samples,
            "avisos_mais_comuns": warnings.most_common(5), "segundos": round(elapsed, 2),
            "maos_por_segundo": round(total / elapsed) if elapsed else None}


def validate_main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="nvt-validate", description=__doc__)
    ap.add_argument("folder", type=Path, help="pasta com históricos (ex.: C:\\HandHistory)")
    a = ap.parse_args(argv)
    rep = validate(a.folder)
    for k, v in rep.items():
        print(f"{k}: {v}")
    return 0 if not rep["quarentena_por_motivo"] else 1


def import_main(argv: list[str] | None = None) -> int:
    """``nvt-import <pasta> --member <id>``: importa a pasta de um membro para o PostgreSQL (NVT_DATABASE_URL)."""
    from .db import connect, ensure_member, finish_batch, import_file, migrate, start_batch

    ap = argparse.ArgumentParser(prog="nvt-import", description=import_main.__doc__)
    ap.add_argument("folder", type=Path)
    ap.add_argument("--member", required=True, help="id do membro (nome da pasta sincronizada)")
    ap.add_argument("--dsn", help="padrão: NVT_DATABASE_URL")
    a = ap.parse_args(argv)

    conn = connect(a.dsn)
    migrate(conn)
    ensure_member(conn, a.member)
    batch = start_batch(conn, root_path=str(a.folder.absolute()), kind="import", member_id=a.member)
    totals: Counter = Counter()
    t0 = time.perf_counter()
    for f in sorted(a.folder.rglob("*.txt")):
        r = import_file(conn, f, a.member, batch)
        totals["arquivos_pulados" if r.skipped else "arquivos_lidos"] += 1
        totals.update(r.counts)
    report = {**totals, "segundos": round(time.perf_counter() - t0, 1)}
    finish_batch(conn, batch, report, hands_new=totals["new"])
    print(f"lote {batch}: {report}")
    return 0


EXIT_OK, EXIT_PARTIAL, EXIT_ALREADY_RUNNING = 0, 1, 2


def ingest_main(argv: list[str] | None = None) -> int:
    """``nvt-ingest <raiz_nuvem>``: lote diário sobre todas as pastas de membros (C:/NvtNuvem/<member_id>/...).

    Códigos de saída: 0 ok · 1 lote com erros de arquivo · 2 outra instância já está rodando.
    """
    import logging

    from .ingest import JobAlreadyRunning, run_daily_ingest

    ap = argparse.ArgumentParser(prog="nvt-ingest", description=ingest_main.__doc__)
    ap.add_argument("root", type=Path, help="raiz da nuvem, com uma subpasta por membro")
    ap.add_argument("--dsn", help="padrão: NVT_DATABASE_URL")
    ap.add_argument("--member", action="append", help="processar só este membro (pode repetir)")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO if a.verbose else logging.WARNING, format="%(asctime)s %(message)s")

    try:
        r = run_daily_ingest(a.root, a.dsn, only_members=set(a.member) if a.member else None)
    except JobAlreadyRunning as e:
        print(f"abortado: {e}", file=sys.stderr)
        return EXIT_ALREADY_RUNNING

    print(f"lote {r.batch_id}: status={r.status}, {len(r.members)} membro(s), {r.hands_new} mãos novas, "
          f"{r.file_errors} erro(s) de arquivo, {r.seconds}s")
    print(f"{'membro':<20}{'arquivos':>9}{'lidos':>7}{'pulados':>8}{'novas':>8}{'outra_fonte':>12}"
          f"{'repetidas':>10}{'quarentena':>11}{'erros':>6}")
    for m in r.members:
        c = m.counts
        print(f"{m.member_id:<20}{m.files_found:>9}{c['files_read']:>7}{c['files_skipped']:>8}{c['new']:>8}"
              f"{c['new_source']:>12}{c['duplicate']:>10}{m.quarantined:>11}{len(m.errors):>6}")
    if r.ignored_dirs:
        print(f"pastas ignoradas (nome inválido para member_id): {', '.join(r.ignored_dirs)}")
    print(f"stats: {r.stats}")
    return EXIT_OK if r.status == "ok" else EXIT_PARTIAL


def stats_main(argv: list[str] | None = None) -> int:
    """``nvt-stats``: calcular, consultar e validar os stats contra um tracker de referência.

    compute            conta as mãos pendentes em stat_acc
    recompute          zera e recalcula tudo a partir das mãos gravadas
    report             relatório por jogador (CSV com --csv)
    template ARQ.csv   planilha para preencher com os valores de referência (top jogadores por formato)
    validate ARQ.csv   compara a planilha preenchida com o NvtTracker (tolerância 0,5 p.p.)
    """
    from .db import connect, migrate
    from .stats.report import TOLERANCE_PP, compare_with_reference, player_report, write_csv, write_reference_template
    from .stats.store import compute_pending, recompute_all

    ap = argparse.ArgumentParser(prog="nvt-stats", description=stats_main.__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["compute", "recompute", "report", "template", "validate"])
    ap.add_argument("file", nargs="?", type=Path)
    ap.add_argument("--dsn")
    ap.add_argument("--room")
    ap.add_argument("--format", choices=["cash", "tournament"])
    ap.add_argument("--player")
    ap.add_argument("--min-hands", type=int, default=0, help="amostra mínima de VPIP no relatório")
    ap.add_argument("--members-only", action="store_true", help="só jogadores vinculados a membros do NVT")
    ap.add_argument("--csv", type=Path)
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--from", dest="date_from", help="validate: início do período (AAAA-MM-DD, UTC), como o filtro de período da referência")
    ap.add_argument("--to", dest="date_to", help="validate: fim do período, exclusivo (AAAA-MM-DD, UTC)")
    a = ap.parse_args(argv)

    conn = connect(a.dsn)
    migrate(conn)
    if a.command in ("compute", "recompute"):
        t0 = time.perf_counter()
        r = (recompute_all if a.command == "recompute" else compute_pending)(conn)
        print(f"{r.hands} mãos contadas, {r.keys_updated} acumuladores atualizados, recálculo={r.recomputed}, "
              f"{time.perf_counter() - t0:.1f}s")
    elif a.command == "report":
        rows = player_report(conn, room=a.room, fmt=a.format, player_id=a.player, min_vpip_sample=a.min_hands,
                             members_only=a.members_only)
        if a.csv:
            write_csv(rows, a.csv)
            print(f"{len(rows)} linhas em {a.csv}")
        else:
            print(f"{'sala':<13}{'jogador':<12}{'formato':<11}{'mãos':>7}{'VPIP':>7}{'PFR':>7}{'3Bet':>7}"
                  f"{'F3B':>7}{'Steal':>7}{'CBet':>7}")
            for r in sorted(rows, key=lambda r: -r.get("vpip_n", 0))[:40]:
                v = lambda s: "-" if r.get(s) is None else f"{r[s]:.1f}"  # noqa: E731
                print(f"{r['room']:<13}{r['player_id']:<12}{r['format']:<11}{r.get('vpip_n', 0):>7}{v('vpip'):>7}"
                      f"{v('pfr'):>7}{v('three_bet'):>7}{v('fold_to_3bet'):>7}{v('steal'):>7}{v('cbet_flop'):>7}")
    elif a.command == "template":
        if not a.file:
            ap.error("informe o arquivo de saída")
        n = write_reference_template(conn, a.file, top=a.top)
        print(f"{n} jogador(es) × 6 stats em {a.file}; preencha ref_value (e ref_sample) com os números de referência")
    elif a.command == "validate":
        if not a.file:
            ap.error("informe a planilha preenchida")
        if bool(a.date_from) != bool(a.date_to):
            ap.error("--from e --to vão juntos")
        from datetime import datetime, timezone
        day = lambda s: datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)  # noqa: E731
        res = compare_with_reference(conn, a.file, start=day(a.date_from) if a.date_from else None,
                               end=day(a.date_to) if a.date_to else None)
        for c in res:
            flag = "ok " if c.ok else "DIF"
            nvt = "-" if c.nvt_value is None else f"{c.nvt_value:.2f}"
            diff = "-" if c.diff_pp is None else f"{c.diff_pp + 0.0:+.2f}"  # + 0.0 evita "-0.00"
            print(f"{flag} {c.room:<13}{c.player_id:<12}{c.format:<11}{c.stat_id:<13}"
                  f"ref={c.ref_value:>6.2f} (n={c.ref_sample})  nvt={nvt:>6} (n={c.nvt_sample})  Δ={diff}")
        bad = [c for c in res if not c.ok]
        print(f"{len(res) - len(bad)}/{len(res)} dentro de ±{TOLERANCE_PP} p.p.")
        return 0 if not bad else 1
    return 0


def watch_main(argv: list[str] | None = None) -> int:
    """``nvt-watch <pasta> --member <id>``: monitora a pasta de históricos e grava cada mão concluída no banco.

    Ctrl+C encerra (a sessão fica registrada em ``batches`` com kind='watch'). Código 2: já existe um watcher
    para este membro.
    """
    import logging
    import signal
    import threading

    from .db import resolve_dsn
    from .ingest import JobAlreadyRunning
    from .ingest.session import watch_session

    ap = argparse.ArgumentParser(prog="nvt-watch", description=watch_main.__doc__)
    ap.add_argument("folder", type=Path, help="pasta de históricos de mão monitorada (ex.: C:/HandHistory)")
    ap.add_argument("--member", required=True, help="id do membro dono desta máquina")
    ap.add_argument("--dsn", help="padrão: NVT_DATABASE_URL")
    ap.add_argument("--poll", type=float, default=1.0, help="intervalo entre ciclos, em segundos (padrão 1)")
    ap.add_argument("--debounce", type=float, default=1.0, help="espera sem alteração antes de ler (padrão 1 s)")
    ap.add_argument("--rescan", type=float, default=30.0, help="varredura completa por arquivos novos (padrão 30 s)")
    ap.add_argument("-v", "--verbose", action="store_true", help="lista também as mãos da sincronização inicial")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(levelname)s %(message)s")
    if not a.folder.is_dir():
        print(f"pasta não encontrada: {a.folder}", file=sys.stderr)
        return 3

    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    try:
        status = watch_session(a.folder, a.member, resolve_dsn(a.dsn), stop, poll=a.poll, debounce=a.debounce,
                               rescan=a.rescan, verbose=a.verbose)
    except JobAlreadyRunning as e:
        print(f"abortado: já existe um watcher para o membro {a.member} ({e.holder})", file=sys.stderr)
        return EXIT_ALREADY_RUNNING
    return EXIT_OK if status == "ok" else EXIT_PARTIAL


def admin_main(argv: list[str] | None = None) -> int:
    """``nvt-admin``: tarefas do admin com o usuário dono das tabelas (URL em NVT_ADMIN_DATABASE_URL ou
    %USERPROFILE%\\.nvttracker\\nvt_admin.ini; nunca na pasta distribuída aos jogadores).

    migrate                  aplica migrações pendentes
    recompute                recalcula todos os stats (necessário após mudar RULES_VERSION)
    add-player <membro>      cria/renova o usuário do jogador e gera o nvt_config.ini dele
    remove-player <membro>   bloqueia o login do jogador (dados preservados)
    list-players             lista membros, usuários e se estão ativos
    """
    from . import admin
    from .db import connect, migrate
    from .stats.store import compute_pending, recompute_all

    ap = argparse.ArgumentParser(prog="nvt-admin", description=admin_main.__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["migrate", "recompute", "add-player", "remove-player",
                                        "list-players", "register-email"])
    ap.add_argument("member", nargs="?")
    ap.add_argument("--email", help="register-email: e-mail autorizado do jogador")
    ap.add_argument("--dsn", help="URL do admin (padrão: NVT_ADMIN_DATABASE_URL ou nvt_admin.ini)")
    ap.add_argument("--config", type=Path, help=f"arquivo do admin (padrão {admin.ADMIN_CONFIG})")
    ap.add_argument("--name", help="add-player: nome de exibição")
    ap.add_argument("--out", type=Path, help="add-player: onde gravar o nvt_config.ini do jogador")
    ap.add_argument("--hh-folder", default=DEFAULT_HH_FOLDER, help="add-player: pasta de históricos do jogador")
    a = ap.parse_args(argv)
    if a.command in ("add-player", "remove-player", "register-email") and not a.member:
        ap.error("informe o membro")
    if a.command == "register-email" and not a.email:
        ap.error("informe --email")

    dsn = admin.admin_dsn(a.dsn, a.config)
    conn = connect(dsn)
    if a.command == "migrate":
        print("migrações aplicadas:", migrate(conn) or "nenhuma (banco já atualizado)")
    elif a.command == "recompute":
        migrate(conn)
        r = recompute_all(conn)
        print(f"{r.hands} mãos recalculadas, {r.keys_updated} acumuladores")
    elif a.command == "add-player":
        migrate(conn)
        creds = admin.add_player(conn, dsn, a.member, a.name)
        out = a.out or admin.ADMIN_CONFIG.parent / "players" / a.member / "nvt_config.ini"
        admin.write_player_config(out, creds, a.hh_folder)
        compute_pending(conn)  # deixa stats_meta/stat_acc prontos para o jogador só somar
        print(f"usuário {creds.role} pronto para o membro {creds.member_id}")
        print(f"configuração do jogador (contém a senha, entregue só a ele): {out}")
    elif a.command == "remove-player":
        print(f"login bloqueado: {admin.remove_player(conn, a.member)} (mãos e histórico preservados)")
    elif a.command == "register-email":
        migrate(conn)
        conn.execute("""INSERT INTO nvt_members (member_id, name, email, active) VALUES (%s, %s, %s, TRUE)
                        ON CONFLICT (member_id) DO UPDATE SET email=EXCLUDED.email,
                        name=COALESCE(EXCLUDED.name, nvt_members.name), active=TRUE""",
                     (a.member, a.name or a.member, a.email.strip()))
        print(f"e-mail autorizado: {a.email} -> membro {a.member} (pode entrar no NVT Tracker)")
    else:
        print(f"{'membro':<16}{'usuário':<22}{'ativo':<7}{'mãos enviadas':>14}")
        for member_id, db_user, ativo, n in admin.list_players(conn):
            print(f"{member_id:<16}{db_user or '-':<22}{'sim' if ativo else 'não':<7}{n:>14}")
    return 0


def analise_main(argv: list[str] | None = None) -> int:
    """``nvt-analise``: abre o PAINEL DE ANÁLISE offline (Streamlit) — stats e bb/100 por posição
    e replay das mãos. Lê NVT_DATABASE_URL."""
    import subprocess
    app = Path(__file__).resolve().parent / "viz" / "analise.py"
    return subprocess.call([sys.executable, "-m", "streamlit", "run", str(app), *(argv or sys.argv[1:])])


if __name__ == "__main__":
    commands = {"import": import_main, "ingest": ingest_main, "stats": stats_main,
                "watch": watch_main, "nvt-watch": watch_main, "admin": admin_main, "nvt-admin": admin_main,
                "analise": analise_main, "nvt-analise": analise_main}
    if sys.argv[1:2] and sys.argv[1] in commands:
        sys.exit(commands[sys.argv[1]](sys.argv[2:]))
    sys.exit(validate_main())
