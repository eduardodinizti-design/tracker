"""Persistência PostgreSQL: migrações, gravação idempotente, quarentena e importação de arquivos."""
from __future__ import annotations

import os

import psycopg

from .importer import FileImportReport, import_file, import_text
from .migrate import migrate
from .repository import (SaveOutcome, Source, ensure_member, finish_batch, link_player, quarantine, save_hand,
                         start_batch)

__all__ = ["connect", "resolve_dsn", "migrate", "import_file", "import_text", "FileImportReport", "save_hand", "quarantine", "SaveOutcome",
           "Source", "ensure_member", "link_player", "start_batch", "finish_batch"]


def resolve_dsn(dsn: str | None = None) -> str:
    """DSN: argumento, ou a variável de ambiente ``NVT_DATABASE_URL`` (ex.: postgresql://user:senha@host/nvt)."""
    dsn = dsn or os.environ.get("NVT_DATABASE_URL")
    if not dsn:
        raise RuntimeError("defina NVT_DATABASE_URL ou passe o DSN")
    return dsn


def connect(dsn: str | None = None) -> psycopg.Connection:
    """Abre uma conexão em autocommit; as funções que gravam abrem a própria transação (``conn.transaction()``)."""
    return psycopg.connect(resolve_dsn(dsn), autocommit=True)
