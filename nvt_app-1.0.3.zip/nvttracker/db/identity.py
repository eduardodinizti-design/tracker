"""Identificadores estáveis de mãos e textos (base da idempotência)."""
from __future__ import annotations

import hashlib

from ..models import Hand


def hand_uid(hand: Hand) -> bytes:
    """sha256 de ``sala|nº da mão|início UTC``, campos do cabeçalho que todos os membros veem iguais.

    Não usa o texto bruto: na mesma mão cada membro tem um ``Dealt to`` diferente, e o texto também pode mudar com a
    versão do exportador. O início UTC evita colisão se uma sala reutilizar numeração.
    """
    key = f"{hand.room}|{hand.hand_no}|{hand.started_utc.isoformat()}"
    return hashlib.sha256(key.encode("utf-8")).digest()


def raw_sha256(text: str) -> bytes:
    """sha256 do texto do bloco normalizado (fins de linha e espaços nas pontas)."""
    norm = "\n".join(line.rstrip() for line in text.strip().splitlines())
    return hashlib.sha256(norm.encode("utf-8")).digest()
