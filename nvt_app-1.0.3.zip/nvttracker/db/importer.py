"""Importa um arquivo de histórico para o banco numa única transação (mãos + quarentena + offset)."""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

import psycopg

from ..fs import io_path
from ..parser import ParseError, parse_file, parse_hand, split_hands
from .repository import Source, quarantine, save_hand

# arquivo sem alteração há este tempo é considerado fechado: o último bloco pode ser aceito sem linha em branco
SETTLED_AFTER = timedelta(minutes=30)
_HEAD = re.compile(r"^(\S+) Hand #(\d+)")


@dataclass(frozen=True)
class HandEvent:
    room: str | None
    hand_no: str | None
    outcome: str          # new | new_source | duplicate | quarantine
    detail: str = ""      # motivo da quarentena


@dataclass
class FileImportReport:
    path: str
    skipped: bool = False
    counts: Counter = field(default_factory=Counter)
    events: list[HandEvent] = field(default_factory=list)  # uma entrada por mão/bloco, na ordem do arquivo


def import_file(conn: psycopg.Connection, path: str | Path, member_id: str, batch_id: int | None = None,
                *, now: datetime | None = None) -> FileImportReport:
    """Lê só o conteúdo novo de ``path`` e grava tudo de forma atômica.

    O offset só avança se as mãos e a quarentena forem gravadas, e mesmo que o offset se perca, a releitura não duplica
    nada (``hand_uid`` + ``ON CONFLICT``).
    """
    path = Path(path)
    key = str(path.absolute())  # sem resolve(): a pasta do membro faz parte da chave, mesmo se for um link
    st = io_path(path).stat()
    mtime = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
    now = now or datetime.now(timezone.utc)
    rep = FileImportReport(path=key)
    source = Source(member_id=member_id, file_path=key, batch_id=batch_id)

    with conn.transaction():
        row = conn.execute("SELECT size, mtime, char_offset FROM ingest_files WHERE file_path = %s FOR UPDATE",
                           (key,)).fetchone()
        offset = 0
        if row is not None:
            size, old_mtime, offset = row
            if size == st.st_size and old_mtime == mtime:
                rep.skipped = True
                return rep
            if st.st_size < size:
                offset = 0  # arquivo reescrito/truncado: relê tudo (a deduplicação protege)

        result = parse_file(path, start=offset, final=(now - mtime) >= SETTLED_AFTER)
        for hand in result.hands:
            outcome = save_hand(conn, hand, source).value
            rep.counts[outcome] += 1
            rep.events.append(HandEvent(hand.room, hand.hand_no, outcome))
        for block, err in result.errors:
            first = quarantine(conn, block.text, err.reason, err.detail, source, offset + block.offset)
            rep.counts["quarantine_new" if first else "quarantine_again"] += 1
            head = _HEAD.match(block.text)
            rep.events.append(HandEvent(head and head[1], head and head[2], "quarantine", err.reason))

        conn.execute("""
            INSERT INTO ingest_files (file_path, member_id, size, mtime, char_offset, last_batch)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (file_path) DO UPDATE SET size = EXCLUDED.size, mtime = EXCLUDED.mtime,
                char_offset = EXCLUDED.char_offset, last_batch = EXCLUDED.last_batch, updated_at = now()""",
            (key, member_id, st.st_size, mtime, offset + result.consumed, batch_id))
    return rep


def import_text(conn: psycopg.Connection, text: str, member_id: str, name: str,
                batch_id: int | None = None) -> FileImportReport:
    """Importa um histórico enviado pelo painel (upload), inteiro e numa transação.

    Não usa ``ingest_files``: o arquivo é lido uma vez só, e reenviar o mesmo arquivo não duplica nada
    (``hand_uid`` + ``ON CONFLICT``). A origem fica registrada como ``upload:<nome>``.
    """
    key = f"upload:{name}"
    rep = FileImportReport(path=key)
    source = Source(member_id=member_id, file_path=key, batch_id=batch_id)
    blocks, _ = split_hands(text.lstrip("﻿"), final=True)
    with conn.transaction():
        for b in blocks:
            try:
                hand = parse_hand(b.text)
            except ParseError as err:
                first = quarantine(conn, b.text, err.reason, err.detail, source, b.offset)
                rep.counts["quarantine_new" if first else "quarantine_again"] += 1
                head = _HEAD.match(b.text)
                rep.events.append(HandEvent(head and head[1], head and head[2], "quarantine", err.reason))
                continue
            outcome = save_hand(conn, hand, source).value
            rep.counts[outcome] += 1
            rep.events.append(HandEvent(hand.room, hand.hand_no, outcome))
    return rep
