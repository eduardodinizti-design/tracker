"""Aplica as migrações SQL de ``db/migrations`` em ordem, uma vez cada, com checagem de checksum."""
from __future__ import annotations

import hashlib
from importlib import resources

import psycopg

_TABLE = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version     TEXT PRIMARY KEY,
    checksum    TEXT NOT NULL,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT now()
)"""


class MigrationRequired(RuntimeError):
    """O banco está desatualizado e o usuário atual (jogador) não tem permissão para migrar."""


def _migrations() -> list[tuple[str, str]]:
    files = resources.files("nvttracker.db") / "migrations"
    out = [(f.name.removesuffix(".sql"), f.read_text(encoding="utf-8"))
           for f in files.iterdir() if f.name.endswith(".sql")]
    return sorted(out)


def _applied(conn: psycopg.Connection) -> dict[str, str] | None:
    """Versões aplicadas, sem nenhum DDL; None se a tabela de controle ainda não existe."""
    if conn.execute("SELECT to_regclass('schema_migrations')").fetchone()[0] is None:
        return None
    return dict(conn.execute("SELECT version, checksum FROM schema_migrations").fetchall())


def pending(conn: psycopg.Connection) -> list[str]:
    done = _applied(conn) or {}
    return [v for v, _ in _migrations() if v not in done]


def migrate(conn: psycopg.Connection) -> list[str]:
    """Aplica as migrações pendentes; devolve as versões aplicadas agora.

    Banco já atualizado: não executa DDL nenhum, o que permite rodar com um usuário de jogador (sem CREATE).
    Pendente e sem permissão: levanta ``MigrationRequired`` (o admin roda ``nvt-admin migrate``).
    Uma migração já aplicada cujo arquivo mudou gera erro: migrações publicadas não se editam, cria-se outra.
    """
    done = _applied(conn)
    if done is not None and all(v in done for v, _ in _migrations()):
        for version, sql in _migrations():
            if done[version] != hashlib.sha256(sql.encode()).hexdigest():
                raise RuntimeError(f"migração {version} foi alterada depois de aplicada")
        return []
    applied_now: list[str] = []
    try:
        with conn.transaction():
            conn.execute(_TABLE)
            conn.execute("SELECT pg_advisory_xact_lock(hashtext('nvttracker_migrate'))")
            done = dict(conn.execute("SELECT version, checksum FROM schema_migrations").fetchall())
            for version, sql in _migrations():
                checksum = hashlib.sha256(sql.encode()).hexdigest()
                if version in done:
                    if done[version] != checksum:
                        raise RuntimeError(f"migração {version} foi alterada depois de aplicada")
                    continue
                conn.execute(sql)
                conn.execute("INSERT INTO schema_migrations (version, checksum) VALUES (%s, %s)",
                             (version, checksum))
                applied_now.append(version)
    except psycopg.errors.InsufficientPrivilege as e:
        raise MigrationRequired("o banco precisa de atualização (migrações pendentes) e este usuário não pode "
                                "aplicá-las; o admin deve rodar: nvt-admin migrate") from e
    return applied_now
