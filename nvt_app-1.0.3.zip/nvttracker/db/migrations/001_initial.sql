-- NvtTracker v1 — esquema inicial (PostgreSQL 15+)
-- Identidade da mão: hand_uid = sha256("<sala>|<nº da mão>|<início UTC ISO>"), derivado só do CABEÇALHO.
-- O texto bruto NÃO entra no hand_uid porque cada membro vê a mesma mão com um texto diferente ("Dealt to").
-- Cada texto distinto fica em hand_raw (raw_sha256), ligado à mão.

CREATE TABLE nvt_members (
    member_id   TEXT PRIMARY KEY,                  -- = nome da pasta sincronizada do membro
    name        TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- D5: vínculo manual "ID na sala -> membro do NVT"
CREATE TABLE player_links (
    room        TEXT NOT NULL,
    player_id   TEXT NOT NULL,
    member_id   TEXT NOT NULL REFERENCES nvt_members ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (room, player_id)
);
CREATE INDEX player_links_member ON player_links (member_id);

CREATE TABLE batches (
    batch_id     BIGSERIAL PRIMARY KEY,
    started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ,
    report       JSONB
);

CREATE TABLE hands (
    hand_pk        BIGSERIAL PRIMARY KEY,
    hand_uid       BYTEA NOT NULL UNIQUE CHECK (length(hand_uid) = 32),
    room           TEXT NOT NULL,
    hand_no        TEXT NOT NULL,
    format         TEXT NOT NULL CHECK (format IN ('cash', 'tournament')),
    game           TEXT NOT NULL DEFAULT 'NLHE',
    started_utc    TIMESTAMPTZ NOT NULL,
    tournament_id  TEXT,
    buyin_text     TEXT,
    club_id        TEXT,
    table_id       TEXT,
    max_seats      SMALLINT,
    button_seat    SMALLINT,
    sb             NUMERIC(18, 2) NOT NULL,
    bb             NUMERIC(18, 2) NOT NULL,
    ante           NUMERIC(18, 2) NOT NULL DEFAULT 0,
    currency       TEXT,
    board          TEXT[] NOT NULL DEFAULT '{}',
    pot            NUMERIC(18, 2),
    rake           NUMERIC(18, 2) NOT NULL DEFAULT 0,
    first_batch    BIGINT REFERENCES batches,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- (sala, nº) NÃO é único: a PPPoker já gerou o mesmo nº para mãos diferentes do mesmo torneio
-- (ex.: #…0000000 em níveis distintos). A identidade é o hand_uid, que inclui o horário de início.
CREATE INDEX hands_room_no ON hands (room, hand_no);
CREATE INDEX hands_room_format_time ON hands (room, format, started_utc);
CREATE INDEX hands_tournament ON hands (room, tournament_id) WHERE tournament_id IS NOT NULL;

-- D7: texto bruto; uma linha por texto distinto (perspectiva) da mesma mão
CREATE TABLE hand_raw (
    raw_sha256  BYTEA PRIMARY KEY CHECK (length(raw_sha256) = 32),
    hand_pk     BIGINT NOT NULL REFERENCES hands ON DELETE CASCADE,
    raw_text    TEXT NOT NULL
);
CREATE INDEX hand_raw_hand ON hand_raw (hand_pk);

-- RF7: quem enviou cada mão e de qual arquivo
CREATE TABLE hand_sources (
    hand_pk     BIGINT NOT NULL REFERENCES hands ON DELETE CASCADE,
    member_id   TEXT NOT NULL REFERENCES nvt_members,
    raw_sha256  BYTEA NOT NULL REFERENCES hand_raw,
    file_path   TEXT NOT NULL,
    batch_id    BIGINT REFERENCES batches,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (hand_pk, member_id)
);

CREATE TABLE hand_players (
    hand_pk      BIGINT NOT NULL REFERENCES hands ON DELETE CASCADE,
    seat         SMALLINT NOT NULL,
    player_id    TEXT NOT NULL,
    position     TEXT,
    stack_start  NUMERIC(18, 2) NOT NULL,
    cards        TEXT[],                             -- preenchido por qualquer perspectiva que conheça as cartas
    sitting_out  BOOLEAN NOT NULL DEFAULT FALSE,
    invested     NUMERIC(18, 2) NOT NULL,
    collected    NUMERIC(18, 2) NOT NULL,
    returned     NUMERIC(18, 2) NOT NULL,
    net          NUMERIC(18, 2) NOT NULL,
    net_bb       NUMERIC(12, 4) NOT NULL,
    went_sd      BOOLEAN NOT NULL,
    won_sd       BOOLEAN NOT NULL,
    PRIMARY KEY (hand_pk, seat)
);
CREATE INDEX hand_players_player ON hand_players (player_id, hand_pk);

CREATE TABLE actions (
    hand_pk    BIGINT NOT NULL REFERENCES hands ON DELETE CASCADE,
    seq        SMALLINT NOT NULL,
    street     TEXT NOT NULL CHECK (street IN ('preflop', 'flop', 'turn', 'river')),
    seat       SMALLINT NOT NULL,
    type       TEXT NOT NULL,
    amount     NUMERIC(18, 2) NOT NULL,
    amount_to  NUMERIC(18, 2),
    is_allin   BOOLEAN NOT NULL,
    PRIMARY KEY (hand_pk, seq)
);

-- RF9: blocos que falharam (parse, conservação de fichas, jogo não suportado...)
CREATE TABLE quarantine (
    quarantine_id  BIGSERIAL PRIMARY KEY,
    raw_sha256     BYTEA NOT NULL CHECK (length(raw_sha256) = 32),
    reason         TEXT NOT NULL,                    -- ex.: chip_imbalance, bad_header, unsupported_game
    detail         TEXT,
    raw_text       TEXT NOT NULL,
    member_id      TEXT REFERENCES nvt_members,
    file_path      TEXT NOT NULL,
    file_offset    BIGINT NOT NULL,
    batch_id       BIGINT REFERENCES batches,
    first_seen     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    times_seen     INTEGER NOT NULL DEFAULT 1,
    resolved_at    TIMESTAMPTZ,                      -- preenchido quando reprocessado com sucesso
    UNIQUE (raw_sha256, reason)                      -- mesmo bloco ruim lido 2x = 1 registro
);
CREATE INDEX quarantine_open ON quarantine (reason) WHERE resolved_at IS NULL;

-- RF1/RF2: progresso de leitura por arquivo
CREATE TABLE ingest_files (
    file_path   TEXT PRIMARY KEY,
    member_id   TEXT NOT NULL REFERENCES nvt_members,
    size        BIGINT NOT NULL,
    mtime       TIMESTAMPTZ NOT NULL,
    char_offset BIGINT NOT NULL,                     -- caracteres já consumidos (blocos completos)
    last_batch  BIGINT REFERENCES batches,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RF10 (passo 4)
CREATE TABLE stat_acc (
    room       TEXT NOT NULL,
    player_id  TEXT NOT NULL,
    format     TEXT NOT NULL CHECK (format IN ('cash', 'tournament')),
    stat_id    TEXT NOT NULL,
    opps       BIGINT NOT NULL DEFAULT 0,
    cases      BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (room, player_id, format, stat_id)
);
