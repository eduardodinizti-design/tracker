-- Passo 3: controle do job diário de ingestão

ALTER TABLE batches
    ADD COLUMN status     TEXT NOT NULL DEFAULT 'running'
        CHECK (status IN ('running', 'ok', 'partial', 'failed', 'aborted')),
    ADD COLUMN root_path  TEXT,
    ADD COLUMN host       TEXT,
    ADD COLUMN hands_new  INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN errors     INTEGER NOT NULL DEFAULT 0;

-- lotes antigos (criados antes desta migração) já terminaram
UPDATE batches SET status = 'ok' WHERE finished_at IS NOT NULL;

-- resultado do lote por membro (RF13): mãos processadas e erros de cada jogador do time
CREATE TABLE batch_members (
    batch_id          BIGINT NOT NULL REFERENCES batches ON DELETE CASCADE,
    member_id         TEXT NOT NULL REFERENCES nvt_members,
    started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at       TIMESTAMPTZ,
    files_found       INTEGER NOT NULL DEFAULT 0,
    files_read        INTEGER NOT NULL DEFAULT 0,
    files_skipped     INTEGER NOT NULL DEFAULT 0,
    hands_new         INTEGER NOT NULL DEFAULT 0,
    hands_new_source  INTEGER NOT NULL DEFAULT 0,
    hands_duplicate   INTEGER NOT NULL DEFAULT 0,
    quarantined       INTEGER NOT NULL DEFAULT 0,       -- blocos que entraram (ou voltaram) para a quarentena
    file_errors       INTEGER NOT NULL DEFAULT 0,       -- arquivos que falharam inteiros (I/O, banco...)
    error_detail      JSONB NOT NULL DEFAULT '[]',      -- [{file, error}]
    PRIMARY KEY (batch_id, member_id)
);
CREATE INDEX batch_members_member ON batch_members (member_id, batch_id DESC);
