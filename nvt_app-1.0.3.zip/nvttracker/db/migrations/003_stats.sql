-- Passo 4: controle incremental do motor de stats

-- versão das regras já aplicada a cada mão (0 = ainda não contada em stat_acc)
ALTER TABLE hands ADD COLUMN stats_version SMALLINT NOT NULL DEFAULT 0;
CREATE INDEX hands_stats_pending ON hands (hand_pk) WHERE stats_version = 0;

-- versão das regras com que stat_acc foi montada; se o código tiver outra, o motor recalcula tudo
CREATE TABLE stats_meta (
    id             BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK (id),
    rules_version  SMALLINT NOT NULL,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE stat_acc ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
CREATE INDEX stat_acc_stat ON stat_acc (stat_id, format, room);
