-- Watcher em tempo real: distingue as sessões do watcher dos lotes diários.
-- O job diário marca como 'aborted' só lotes diários órfãos; uma sessão de watch ativa não é afetada.

ALTER TABLE batches
    ADD COLUMN kind       TEXT NOT NULL DEFAULT 'daily' CHECK (kind IN ('daily', 'import', 'watch')),
    ADD COLUMN member_id  TEXT REFERENCES nvt_members;
CREATE INDEX batches_running ON batches (kind, status) WHERE status = 'running';
