-- NvtDashboard: notas estruturadas por jogador (aba Pós-Flop)

CREATE TABLE player_notes (
    note_id     BIGSERIAL PRIMARY KEY,
    room        TEXT NOT NULL,
    player_id   TEXT NOT NULL,
    category    TEXT NOT NULL CHECK (category IN ('fish', 'reg', 'nit', 'maniac', 'lag', 'tag', 'outro')),
    street      TEXT NOT NULL DEFAULT 'geral' CHECK (street IN ('geral', 'preflop', 'flop', 'turn', 'river')),
    tags        TEXT[] NOT NULL DEFAULT '{}',          -- ex.: {"overfold_vs_3bet", "cbet_alto"}
    note        TEXT NOT NULL DEFAULT '',
    author      TEXT,                                  -- member_id de quem escreveu
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX player_notes_player ON player_notes (room, player_id, created_at DESC);

-- "mesa ativa": jogadores das mãos capturadas recentemente (watcher grava created_at na hora da captura)
CREATE INDEX hands_created ON hands (created_at DESC);
