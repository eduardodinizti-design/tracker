-- Um usuário de banco por jogador. Roda com o usuário admin (dono das tabelas).
-- nvt_player: grupo sem login com as permissões do dia a dia (ler tudo; inserir mãos; atualizar só o necessário).
-- Jogadores (nvt_<membro>) entram no grupo via `nvt-admin add-player`.

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'nvt_player') THEN
        CREATE ROLE nvt_player NOLOGIN;
    END IF;
END $$;

-- quem gravou (usuário de banco), para auditoria
ALTER TABLE hand_sources ADD COLUMN db_user TEXT NOT NULL DEFAULT current_user;
ALTER TABLE batches ADD COLUMN db_user TEXT DEFAULT current_user;
ALTER TABLE player_notes ALTER COLUMN author SET DEFAULT current_user;

-- vínculo membro do time <-> usuário de banco
ALTER TABLE nvt_members ADD COLUMN db_user TEXT UNIQUE;

-- ---------------------------------------------------------------- permissões do grupo
-- schema atual (nvttracker no Supabase, public num banco local)
DO $$
BEGIN
    EXECUTE format('GRANT USAGE ON SCHEMA %I TO nvt_player', current_schema());
    EXECUTE format('GRANT SELECT ON ALL TABLES IN SCHEMA %I TO nvt_player', current_schema());
    EXECUTE format('GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA %I TO nvt_player', current_schema());
    -- tabelas criadas por migrações futuras já nascem legíveis pelo grupo
    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT SELECT ON TABLES TO nvt_player', current_schema());
END $$;

GRANT INSERT ON hands, hand_raw, hand_sources, hand_players, actions, quarantine, ingest_files, batches,
                batch_members, stat_acc, player_notes TO nvt_player;

GRANT UPDATE (stats_version) ON hands TO nvt_player;
GRANT UPDATE (cards) ON hand_players TO nvt_player;
GRANT UPDATE (last_seen, times_seen, batch_id, resolved_at) ON quarantine TO nvt_player;
GRANT UPDATE (member_id, size, mtime, char_offset, last_batch, updated_at) ON ingest_files TO nvt_player;
GRANT UPDATE (opps, cases, updated_at) ON stat_acc TO nvt_player;
GRANT UPDATE (finished_at, report, status, hands_new, errors) ON batches TO nvt_player;
GRANT UPDATE (finished_at, files_found, files_read, files_skipped, hands_new, hands_new_source, hands_duplicate,
              quarantined, file_errors, error_detail) ON batch_members TO nvt_player;
-- sem DELETE, TRUNCATE, DROP, ALTER; nvt_members, player_links, stats_meta e schema_migrations: só leitura

-- ---------------------------------------------------------------- jogador só grava como o próprio membro
CREATE FUNCTION nvt_check_member() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.member_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM pg_auth_members m
            JOIN pg_roles g ON g.oid = m.roleid AND g.rolname = 'nvt_player'
            JOIN pg_roles u ON u.oid = m.member AND u.rolname = current_user)
       AND NOT EXISTS (SELECT 1 FROM nvt_members WHERE member_id = NEW.member_id AND db_user = current_user) THEN
        RAISE EXCEPTION 'usuário % não pode gravar como o membro %', current_user, NEW.member_id
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN NEW;
END $$;

CREATE TRIGGER nvt_check_member BEFORE INSERT OR UPDATE OF member_id ON hand_sources
    FOR EACH ROW EXECUTE FUNCTION nvt_check_member();
CREATE TRIGGER nvt_check_member BEFORE INSERT OR UPDATE OF member_id ON ingest_files
    FOR EACH ROW EXECUTE FUNCTION nvt_check_member();
CREATE TRIGGER nvt_check_member BEFORE INSERT OR UPDATE OF member_id ON batches
    FOR EACH ROW EXECUTE FUNCTION nvt_check_member();
CREATE TRIGGER nvt_check_member BEFORE INSERT OR UPDATE OF member_id ON batch_members
    FOR EACH ROW EXECUTE FUNCTION nvt_check_member();
