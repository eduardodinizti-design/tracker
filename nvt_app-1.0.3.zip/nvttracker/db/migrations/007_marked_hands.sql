-- NvtTracker: mãos marcadas para estudo (aba "Marked Hands" do H2N), com tags e nota.
-- Uma marcação por mão por autor (usuário de banco); re-marcar atualiza tags/nota.

CREATE TABLE marked_hands (
    hand_pk     BIGINT NOT NULL REFERENCES hands (hand_pk) ON DELETE CASCADE,
    author      TEXT NOT NULL DEFAULT current_user,     -- quem marcou (usuário de banco)
    tags        TEXT[] NOT NULL DEFAULT '{}',           -- ex.: {"cooler", "revisar_turn"}
    note        TEXT NOT NULL DEFAULT '',
    marked_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (hand_pk, author)
);
CREATE INDEX marked_hands_recent ON marked_hands (author, marked_at DESC);

-- estudo do próprio jogador: pode marcar, re-marcar e desmarcar as suas mãos
GRANT INSERT, UPDATE (tags, note, marked_at), DELETE ON marked_hands TO nvt_player;
