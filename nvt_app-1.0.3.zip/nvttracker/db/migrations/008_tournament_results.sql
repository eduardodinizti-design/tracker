-- NVT Tracker: CONTROLE DE TORNEIOS (o "pulo do gato").
-- O histórico (.txt) já dá: buy-in, hora de entrada/queda, duração, mãos.
-- Esta tabela guarda a ECONOMIA que NÃO está no histórico e vem da captura ao vivo do lobby
-- (field, reentradas, rebuys, colocação, prêmio) ou de entrada manual. Uma linha por
-- (sala, torneio, jogador) — cada membro do time tem o seu resultado.

CREATE TABLE tournament_results (
    room          TEXT NOT NULL,
    tournament_id TEXT NOT NULL,
    player_id     TEXT NOT NULL,
    name          TEXT,                       -- nome do torneio (do lobby)
    my_entries    INT  NOT NULL DEFAULT 1,    -- entradas (1 + reentradas) do jogador
    rebuys        INT  NOT NULL DEFAULT 0,
    addons        INT  NOT NULL DEFAULT 0,
    field_size    INT,                         -- total de entradas no torneio
    position      INT,                         -- colocação final
    prize         NUMERIC(18,2),               -- premiação recebida
    itm           BOOLEAN,                     -- bateu o dinheiro
    extra_cost    NUMERIC(18,2) NOT NULL DEFAULT 0,  -- custo de rebuys/addons (quando o buy-in não cobre)
    note          TEXT NOT NULL DEFAULT '',
    source        TEXT NOT NULL DEFAULT 'capture' CHECK (source IN ('capture','manual','hh')),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (room, tournament_id, player_id)
);
CREATE INDEX tournament_results_player ON tournament_results (player_id, room);

GRANT INSERT, UPDATE (name, my_entries, rebuys, addons, field_size, position, prize, itm,
                      extra_cost, note, source, updated_at), DELETE ON tournament_results TO nvt_player;
