-- NVT Tracker: login autorizado só para jogadores do NVT (e-mail cadastrado).
-- Reaproveita nvt_members (o registro de membros do time): adiciona e-mail e flag de ativo.
-- Quem não tiver e-mail autorizado e ativo não entra no tracker.

ALTER TABLE nvt_members ADD COLUMN email  TEXT;
ALTER TABLE nvt_members ADD COLUMN active BOOLEAN NOT NULL DEFAULT TRUE;

-- um e-mail por membro (case-insensitive)
CREATE UNIQUE INDEX nvt_members_email ON nvt_members (lower(email)) WHERE email IS NOT NULL;
