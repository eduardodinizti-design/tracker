"""Gravação idempotente de mãos, quarentena e controle de lotes (RF7–RF9, RF13)."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

import psycopg
from psycopg.types.json import Jsonb

from ..models import Hand
from .identity import hand_uid, raw_sha256


class SaveOutcome(str, Enum):
    NEW = "new"                    # mão inserida agora
    NEW_SOURCE = "new_source"      # mão já existia; outro membro também a enviou
    DUPLICATE = "duplicate"        # mesma mão do mesmo membro (releitura do arquivo)


@dataclass(frozen=True)
class Source:
    member_id: str
    file_path: str
    batch_id: int | None = None


# ---------------------------------------------------------------- membros e lotes

def ensure_member(conn: psycopg.Connection, member_id: str, name: str | None = None) -> None:
    """Cadastra o membro se não existir. Consulta antes de inserir: um usuário de jogador só tem leitura em
    ``nvt_members`` (quem cadastra é o admin via ``nvt-admin add-player``)."""
    if conn.execute("SELECT 1 FROM nvt_members WHERE member_id = %s", (member_id,)).fetchone():
        return
    conn.execute("INSERT INTO nvt_members (member_id, name) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                 (member_id, name or member_id))


def link_player(conn: psycopg.Connection, room: str, player_id: str, member_id: str) -> None:
    """Cadastro manual (D5): associa o ID do jogador na sala a um membro do NVT."""
    conn.execute(
        "INSERT INTO player_links (room, player_id, member_id) VALUES (%s, %s, %s) "
        "ON CONFLICT (room, player_id) DO UPDATE SET member_id = EXCLUDED.member_id",
        (room, player_id, member_id))


def start_batch(conn: psycopg.Connection, root_path: str | None = None, host: str | None = None, *,
                kind: str = "daily", member_id: str | None = None) -> int:
    return conn.execute("INSERT INTO batches (root_path, host, kind, member_id) VALUES (%s, %s, %s, %s) "
                        "RETURNING batch_id", (root_path, host, kind, member_id)).fetchone()[0]


def finish_batch(conn: psycopg.Connection, batch_id: int, report: dict, *, status: str = "ok",
                 hands_new: int = 0, errors: int = 0) -> None:
    conn.execute("UPDATE batches SET finished_at = now(), report = %s, status = %s, hands_new = %s, errors = %s "
                 "WHERE batch_id = %s", (Jsonb(report), status, hands_new, errors, batch_id))


# ---------------------------------------------------------------- mãos

_INSERT_HAND = """
INSERT INTO hands (hand_uid, room, hand_no, format, game, started_utc, tournament_id, buyin_text, club_id,
                   table_id, max_seats, button_seat, sb, bb, ante, currency, board, pot, rake, first_batch)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT (hand_uid) DO NOTHING
RETURNING hand_pk"""

_INSERT_PLAYER = """
INSERT INTO hand_players (hand_pk, seat, player_id, position, stack_start, cards, sitting_out, invested,
                          collected, returned, net, net_bb, went_sd, won_sd)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

_INSERT_ACTION = """
INSERT INTO actions (hand_pk, seq, street, seat, type, amount, amount_to, is_allin)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"""


def save_hand(conn: psycopg.Connection, hand: Hand, source: Source) -> SaveOutcome:
    """Grava a mão de forma idempotente. Deve rodar dentro de uma transação do chamador."""
    uid = hand_uid(hand)
    raw_hash = raw_sha256(hand.raw_text)
    row = conn.execute(_INSERT_HAND, (
        uid, hand.room, hand.hand_no, hand.format.value, hand.game, hand.started_utc, hand.tournament_id,
        hand.buyin_text, hand.club_id, hand.table_id, hand.max_seats, hand.button_seat, hand.sb, hand.bb,
        hand.ante, hand.currency, hand.board, hand.pot, hand.rake, source.batch_id)).fetchone()

    if row is not None:
        hand_pk = row[0]
        seat_of = {p.name: p.seat for p in hand.players}
        bb = hand.bb or Decimal(1)
        with conn.cursor() as cur:
            cur.executemany(_INSERT_PLAYER, [
                (hand_pk, p.seat, p.name, p.position, p.stack, p.cards, p.sitting_out, p.invested, p.collected,
                 p.returned, p.net, (p.net / bb).quantize(Decimal("0.0001")), p.went_to_showdown, p.won_at_showdown)
                for p in hand.players])
            cur.executemany(_INSERT_ACTION, [
                (hand_pk, a.seq, a.street.value, seat_of[a.player], a.type.value, a.amount, a.amount_to, a.is_allin)
                for a in hand.actions])
        outcome = SaveOutcome.NEW
    else:
        hand_pk = conn.execute("SELECT hand_pk FROM hands WHERE hand_uid = %s", (uid,)).fetchone()[0]
        # outra perspectiva pode revelar cartas que a primeira não tinha
        with conn.cursor() as cur:
            cur.executemany(
                "UPDATE hand_players SET cards = %s WHERE hand_pk = %s AND seat = %s AND cards IS NULL",
                [(p.cards, hand_pk, p.seat) for p in hand.players if p.cards])
        outcome = None

    conn.execute("INSERT INTO hand_raw (raw_sha256, hand_pk, raw_text) VALUES (%s, %s, %s) ON CONFLICT DO NOTHING",
                 (raw_hash, hand_pk, hand.raw_text))
    src = conn.execute(
        "INSERT INTO hand_sources (hand_pk, member_id, raw_sha256, file_path, batch_id) VALUES (%s, %s, %s, %s, %s) "
        "ON CONFLICT DO NOTHING", (hand_pk, source.member_id, raw_hash, source.file_path, source.batch_id))
    # um bloco que antes falhou e agora passou (regra corrigida) sai da quarentena
    conn.execute("UPDATE quarantine SET resolved_at = now() WHERE raw_sha256 = %s AND resolved_at IS NULL",
                 (raw_hash,))
    if outcome is None:
        outcome = SaveOutcome.NEW_SOURCE if src.rowcount else SaveOutcome.DUPLICATE
    return outcome


# ---------------------------------------------------------------- quarentena

def quarantine(conn: psycopg.Connection, raw_text: str, reason: str, detail: str, source: Source,
               file_offset: int) -> bool:
    """Guarda um bloco que falhou. Devolve True se é a primeira vez que ele aparece com esse motivo."""
    row = conn.execute("""
        INSERT INTO quarantine (raw_sha256, reason, detail, raw_text, member_id, file_path, file_offset, batch_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (raw_sha256, reason) DO UPDATE
            SET last_seen = now(), times_seen = quarantine.times_seen + 1, batch_id = EXCLUDED.batch_id
        RETURNING (xmax = 0) AS inserted""",
        (raw_sha256(raw_text), reason, detail[:2000], raw_text, source.member_id, source.file_path, file_offset,
         source.batch_id)).fetchone()
    return bool(row[0])
