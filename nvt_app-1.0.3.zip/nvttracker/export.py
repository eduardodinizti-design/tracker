"""Exporta as mãos dos OUTROS membros do time para .txt, no formato padrão de histórico, organizadas por sala/ano/mês/dia:

    <pasta>\\<Sala>\\AAAA\\MM\\DD\\<Sala>_AAAA_M_D_<mesa>.txt     (mãos separadas por uma linha em branco)

As mãos do próprio membro ficam de fora (já estão na pasta de históricos dele). Só exporta mãos concluídas há
pelo menos ``delay_minutes`` (padrão 30): quem está na mesma mesa que um colega não recebe as mãos dele em jogo.
O progresso fica num arquivo de estado local; exportar de novo nunca duplica uma mão.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import psycopg

from .fs import io_path

ROOM_FOLDER = {"X-Poker": "Xpoker"}     # nomes de pasta por sala
RECENT_WINDOW = 20000                    # hand_pks recentes lembrados (transações que gravaram fora de ordem)
STATE_FILE = ".nvt_export_state.json"


@dataclass
class ExportReport:
    hands: int = 0
    files: set[str] = field(default_factory=set)


def hand_file(root: Path, room: str, started, table_id: str | None) -> Path:
    d = started
    name = f"{room}_{d.year}_{d.month}_{d.day}_{table_id or 'mesa'}.txt"
    return root / ROOM_FOLDER.get(room, room) / f"{d.year:04d}" / f"{d.month:02d}" / f"{d.day:02d}" / name


def _load_state(path: Path) -> dict:
    try:
        return json.loads(io_path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"cursor": 0, "recent": []}


def _save_state(path: Path, state: dict) -> None:
    tmp = io_path(path.with_suffix(".tmp"))
    tmp.write_text(json.dumps(state), encoding="utf-8")
    tmp.replace(io_path(path))


def export_team_hands(conn: psycopg.Connection, root: str | Path, member_id: str, *, delay_minutes: int = 30,
                      batch: int = 2000) -> ExportReport:
    """Grava as mãos novas dos outros membros. Pode ser chamado em laço; cada chamada exporta até ``batch`` mãos."""
    root = Path(root)
    io_path(root).mkdir(parents=True, exist_ok=True)
    state_path = root / STATE_FILE
    state = _load_state(state_path)
    recent = set(state.get("recent", []))
    floor = max(0, state.get("cursor", 0) - RECENT_WINDOW)
    rows = conn.execute("""
        SELECT DISTINCT ON (h.hand_pk) h.hand_pk, h.room, h.started_utc, h.table_id, r.raw_text
        FROM hands h
        JOIN hand_sources s ON s.hand_pk = h.hand_pk
        JOIN hand_raw r ON r.raw_sha256 = s.raw_sha256
        WHERE h.hand_pk > %(floor)s
          AND NOT (h.hand_pk = ANY(%(recent)s))
          AND h.created_at <= now() - make_interval(mins => %(delay)s)
          AND NOT EXISTS (SELECT 1 FROM hand_sources me WHERE me.hand_pk = h.hand_pk AND me.member_id = %(member)s)
        ORDER BY h.hand_pk, length(r.raw_text) DESC      -- a perspectiva com mais informação (cartas mostradas)
        LIMIT %(lim)s""",
        {"floor": floor, "recent": sorted(recent), "delay": delay_minutes, "member": member_id,
         "lim": batch}).fetchall()

    rep = ExportReport()
    handles: dict[Path, object] = {}
    try:
        for pk, room, started, table_id, raw in rows:
            path = hand_file(root, room, started, table_id)
            fh = handles.get(path)
            if fh is None:
                p = io_path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                fh = handles[path] = open(p, "a", encoding="utf-8", newline="\n")
                if p.stat().st_size:
                    fh.write("\n\n")
            else:
                fh.write("\n\n")
            fh.write(raw.strip())
            recent.add(pk)
            rep.hands += 1
            rep.files.add(str(path))
    finally:
        for fh in handles.values():
            fh.close()
    if rep.hands:
        cursor = max(recent)
        state = {"cursor": cursor, "recent": sorted(p for p in recent if p > cursor - RECENT_WINDOW)}
        _save_state(state_path, state)
    return rep
