"""Acesso a arquivos tolerante a caminhos longos no Windows (> 260 caracteres)."""
from __future__ import annotations

import os
from pathlib import Path


def io_path(path: str | Path) -> Path:
    """Caminho para abrir/stat. No Windows usa o prefixo ``\\\\?\\``, que dispensa o limite MAX_PATH.

    Use só para operações de E/S; para exibir ou gravar no banco use o caminho normal.
    """
    p = Path(path).absolute()
    if os.name != "nt":
        return p
    s = str(p)
    if s.startswith("\\\\?\\"):
        return p
    if s.startswith("\\\\"):  # compartilhamento de rede: \\servidor\pasta -> \\?\UNC\servidor\pasta
        return Path("\\\\?\\UNC\\" + s[2:])
    return Path("\\\\?\\" + s)
