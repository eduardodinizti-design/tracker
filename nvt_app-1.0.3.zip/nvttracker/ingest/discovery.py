"""Descoberta de membros (subpastas da raiz da nuvem) e de arquivos de histórico válidos."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

from ..fs import io_path

# nome da subpasta = member_id; letras, números, "_", "-" e "."
MEMBER_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
# primeira linha de um histórico suportado: "<Sala> Hand #<nº>:"
HAND_HEADER = re.compile(rb"^(?:\xef\xbb\xbf)?\s*\S+ Hand #\d+:")
# arquivos temporários/conflito de sincronização que nunca devem ser lidos
_IGNORED_NAME = re.compile(r"^(~\$|\.)|\.(tmp|partial|crdownload)$", re.IGNORECASE)


@dataclass(frozen=True)
class MemberFolder:
    member_id: str
    path: Path


@dataclass(frozen=True)
class Discovery:
    members: list[MemberFolder]
    ignored_dirs: list[str]          # subpastas cujo nome não é um member_id válido


def discover_members(root: str | Path) -> Discovery:
    root = Path(root)
    if not root.is_dir():
        raise FileNotFoundError(f"raiz da nuvem não encontrada: {root}")
    members, ignored = [], []
    for d in sorted(p for p in root.iterdir() if p.is_dir()):
        if MEMBER_ID.match(d.name):
            members.append(MemberFolder(d.name, d))
        else:
            ignored.append(d.name)
    return Discovery(members, ignored)


def is_hand_history(path: Path) -> bool:
    """Arquivo .txt cuja primeira linha não vazia é um cabeçalho de mão. Lê só os primeiros bytes.

    Um .txt que não pode ser lido conta como candidato: o import vai falhar e o erro fica registrado no lote,
    em vez de o arquivo sumir em silêncio.
    """
    if path.suffix.lower() != ".txt" or _IGNORED_NAME.search(path.name):
        return False
    try:
        with io_path(path).open("rb") as f:
            head = f.read(512)
    except OSError:
        return True
    return bool(HAND_HEADER.match(head))


def discover_files(member: MemberFolder) -> list[Path]:
    """Todos os históricos válidos do membro, em qualquer profundidade (ex.: <Sala>/AAAA/MM/DD/*.txt).

    Usa ``os.walk(followlinks=True)`` em vez de ``Path.rglob``: no Windows, ``rglob`` não percorre direito pastas que
    são reparse points (junções, OneDrive sob demanda). Ciclos de links são evitados pelo caminho real já visitado.
    """
    found: list[Path] = []
    seen: set[str] = set()
    def walk_error(err: OSError) -> None:
        raise err  # pasta ilegível derruba a descoberta do membro e vira erro registrado no lote

    for dirpath, dirnames, filenames in os.walk(member.path, followlinks=True, onerror=walk_error):
        real = os.path.realpath(dirpath)
        if real in seen:
            dirnames[:] = []
            continue
        seen.add(real)
        for name in filenames:
            p = Path(dirpath, name)
            if is_hand_history(p):
                found.append(p)
    return sorted(found)
