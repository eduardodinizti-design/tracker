"""Job diário: varre a raiz da nuvem, importa os arquivos de cada membro e registra o lote no banco."""
from __future__ import annotations

import logging
import socket
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import psycopg
from psycopg.types.json import Jsonb

from ..db import connect, ensure_member, finish_batch, import_file, migrate, resolve_dsn, start_batch
from ..stats.store import compute_pending
from .discovery import MemberFolder, discover_files, discover_members
from .lock import ingest_lock

log = logging.getLogger(__name__)


@dataclass
class MemberResult:
    member_id: str
    files_found: int = 0
    counts: Counter = field(default_factory=Counter)
    errors: list[dict] = field(default_factory=list)

    @property
    def quarantined(self) -> int:
        return self.counts["quarantine_new"] + self.counts["quarantine_again"]


@dataclass
class BatchResult:
    batch_id: int
    status: str
    members: list[MemberResult]
    ignored_dirs: list[str]
    seconds: float
    stats: dict = field(default_factory=dict)

    @property
    def hands_new(self) -> int:
        return sum(m.counts["new"] for m in self.members)

    @property
    def file_errors(self) -> int:
        return sum(len(m.errors) for m in self.members)


def _abort_stale_batches(conn: psycopg.Connection) -> int:
    """Com a trava em mãos, qualquer lote ainda 'running' é de um processo que morreu."""
    return conn.execute("UPDATE batches SET status = 'aborted', finished_at = now() "
                        "WHERE status = 'running' AND kind = 'daily'").rowcount


def _import_member(conn: psycopg.Connection, batch_id: int, member: MemberFolder) -> MemberResult:
    res = MemberResult(member.member_id)
    ensure_member(conn, member.member_id)
    conn.execute("INSERT INTO batch_members (batch_id, member_id) VALUES (%s, %s)", (batch_id, member.member_id))
    try:
        files = discover_files(member)
    except OSError as e:
        log.exception("falha ao varrer a pasta de %s", member.member_id)
        res.errors.append({"file": str(member.path), "error": f"varredura: {type(e).__name__}: {e}"[:500]})
        files = []
    res.files_found = len(files)
    for f in files:
        try:
            r = import_file(conn, f, member.member_id, batch_id)
        except (OSError, psycopg.Error, ValueError) as e:
            # a transação do arquivo já foi desfeita; o lote segue com os demais arquivos
            log.exception("falha ao importar %s", f)
            res.errors.append({"file": str(f), "error": f"{type(e).__name__}: {e}"[:500]})
            continue
        res.counts["files_skipped" if r.skipped else "files_read"] += 1
        res.counts.update(r.counts)
    conn.execute("""
        UPDATE batch_members SET finished_at = now(), files_found = %s, files_read = %s, files_skipped = %s,
            hands_new = %s, hands_new_source = %s, hands_duplicate = %s, quarantined = %s,
            file_errors = %s, error_detail = %s
        WHERE batch_id = %s AND member_id = %s""",
        (res.files_found, res.counts["files_read"], res.counts["files_skipped"], res.counts["new"],
         res.counts["new_source"], res.counts["duplicate"], res.quarantined, len(res.errors), Jsonb(res.errors),
         batch_id, member.member_id))
    return res


def run_daily_ingest(root: str | Path, dsn: str | None = None, *, only_members: set[str] | None = None) -> BatchResult:
    """Executa o lote completo. Levanta ``JobAlreadyRunning`` se outra instância estiver rodando."""
    root = Path(root)
    dsn = resolve_dsn(dsn)
    conn = connect(dsn)
    try:
        with ingest_lock(dsn):
            migrate(conn)
            stale = _abort_stale_batches(conn)
            if stale:
                log.warning("%d lote(s) interrompido(s) anteriormente marcados como 'aborted'", stale)
            discovery = discover_members(root)
            members = [m for m in discovery.members if not only_members or m.member_id in only_members]
            batch_id = start_batch(conn, root_path=str(root.absolute()), host=socket.gethostname())
            t0 = time.perf_counter()
            results: list[MemberResult] = []
            try:
                for m in members:
                    log.info("membro %s: importando", m.member_id)
                    results.append(_import_member(conn, batch_id, m))
            except BaseException:
                finish_batch(conn, batch_id, {"erro": "lote interrompido"}, status="failed")
                raise
            errors = sum(len(r.errors) for r in results)
            # passo 4: conta as mãos novas em stat_acc (incremental; recalcula tudo se as regras mudaram)
            stats_info: dict = {}
            try:
                s = compute_pending(conn)
                stats_info = {"maos_contadas": s.hands, "chaves": s.keys_updated, "recalculo": s.recomputed}
            except psycopg.Error as e:
                log.exception("falha ao calcular stats")
                stats_info = {"erro": f"{type(e).__name__}: {e}"[:500]}
                errors += 1
            seconds = round(time.perf_counter() - t0, 1)
            status = "ok" if errors == 0 else "partial"
            result = BatchResult(batch_id, status, results, discovery.ignored_dirs, seconds, stats_info)
            report = {
                "membros": {r.member_id: {"arquivos": r.files_found, **r.counts, "erros": len(r.errors)}
                            for r in results},
                "pastas_ignoradas": discovery.ignored_dirs,
                "stats": stats_info,
                "segundos": seconds,
            }
            finish_batch(conn, batch_id, report, status=status, hands_new=result.hands_new, errors=errors)
            return result
    finally:
        conn.close()
