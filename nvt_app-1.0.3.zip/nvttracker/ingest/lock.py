"""Trava para impedir duas execuções simultâneas do job diário.

Usa um *advisory lock* de sessão do PostgreSQL numa conexão dedicada:
- vale entre processos e entre máquinas que usam o mesmo banco;
- se o processo morrer, a conexão cai e o PostgreSQL libera a trava sozinho (não sobra arquivo .lock órfão).
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import psycopg

LOCK_NAME = "nvttracker_daily_ingest"


class JobAlreadyRunning(RuntimeError):
    def __init__(self, holder: str | None):
        super().__init__(f"já existe um job de ingestão rodando ({holder or 'processo desconhecido'})")
        self.holder = holder


def _holder(conn: psycopg.Connection, name: str) -> str | None:
    row = conn.execute("""
        SELECT a.pid || ' em ' || coalesce(a.client_addr::text, 'local') || ' desde ' || to_char(a.backend_start, 'HH24:MI:SS')
        FROM pg_locks l JOIN pg_stat_activity a USING (pid)
        WHERE l.locktype = 'advisory' AND l.granted AND l.objid = hashtext(%s)::oid""", (name,)).fetchone()
    return row[0] if row else None


@contextmanager
def ingest_lock(dsn: str, name: str = LOCK_NAME) -> Iterator[psycopg.Connection]:
    """Segura a trava ``name`` enquanto o bloco ``with`` roda; levanta ``JobAlreadyRunning`` se outra instância a tem."""
    conn = psycopg.connect(dsn, autocommit=True, application_name="nvttracker-lock")
    try:
        got = conn.execute("SELECT pg_try_advisory_lock(hashtext(%s))", (name,)).fetchone()[0]
        if not got:
            raise JobAlreadyRunning(_holder(conn, name))
        try:
            yield conn
        finally:
            conn.execute("SELECT pg_advisory_unlock(hashtext(%s))", (name,))
    finally:
        conn.close()
