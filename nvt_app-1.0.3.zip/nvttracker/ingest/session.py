"""Sessão completa do watcher (trava do membro, lote kind='watch', sincronização inicial e laço até ``stop``).

Usada pelo comando ``nvt-watch`` e pelo inicializador unificado ``run_nvt.py``.
"""
from __future__ import annotations

import socket
import threading
import time
from pathlib import Path
from typing import Callable

from ..db import connect, ensure_member, finish_batch, migrate, start_batch
from ..db.importer import HandEvent
from .lock import ingest_lock
from .watcher import Watcher


def describe(ev: HandEvent) -> str | None:
    """Linha de log de uma mão processada (repetidas não geram linha)."""
    room = ev.room or "?"
    if ev.outcome == "new":
        return f"[{room}] Mão #{ev.hand_no} importada com sucesso."
    if ev.outcome == "new_source":
        return f"[{room}] Mão #{ev.hand_no} já estava no banco (outro membro); origem registrada."
    if ev.outcome == "quarantine":
        return f"[{room}] Mão #{ev.hand_no} enviada para a quarentena ({ev.detail})."
    return None


def watch_session(folder: Path, member: str, dsn: str, stop: threading.Event, *, poll: float = 1.0,
                  debounce: float = 1.0, rescan: float = 30.0, verbose: bool = False,
                  out: Callable[[str], None] = lambda s: print(s, flush=True),
                  on_watcher: Callable[[Watcher], None] | None = None) -> str:
    """Roda até ``stop`` e devolve o status do lote ('ok', 'partial' ou 'failed').

    Levanta ``JobAlreadyRunning`` se já houver um watcher para o membro.
    """
    live = False

    def show(ev: HandEvent) -> None:
        if (live or verbose) and (line := describe(ev)):
            out(line)

    with ingest_lock(dsn, name=f"nvttracker_watch:{member}"):
        conn = connect(dsn)
        migrate(conn)
        ensure_member(conn, member)
        # com a trava do membro em mãos, sessões de watch ainda 'running' deste membro são órfãs
        conn.execute("UPDATE batches SET status='aborted', finished_at=now() "
                     "WHERE kind='watch' AND member_id=%s AND status='running'", (member,))
        batch = start_batch(conn, root_path=str(folder.absolute()), host=socket.gethostname(), kind="watch",
                            member_id=member)
        w = Watcher(conn, folder, member, batch_id=batch, on_event=show, debounce=debounce, rescan_every=rescan)
        if on_watcher:
            on_watcher(w)
        out(f"NvtTracker watch · membro {member} · {folder} · sessão {batch}")
        t0 = time.perf_counter()
        w.tick()  # sincronização inicial (backlog)
        s = w.stats
        out(f"Sincronização inicial: {s.files} arquivo(s), {s.hands_new} mão(s) nova(s), "
            f"{s.hands_duplicate + s.hands_new_source} já no banco, {s.quarantined} em quarentena "
            f"({time.perf_counter() - t0:.1f}s). Aguardando novas mãos…")
        live = True
        status = "ok"
        try:
            w.run(stop, poll=poll, reconnect=lambda: connect(dsn))
        except Exception:
            status = "failed"
            raise
        finally:
            s = w.stats
            if s.errors and status == "ok":
                status = "partial"
            finish_batch(w.conn, batch, {"watch": s.as_report()}, status=status, hands_new=s.hands_new,
                         errors=s.errors)
            out(f"Sessão {batch} encerrada: {s.hands_new} mão(s) nova(s), {s.quarantined} em quarentena, "
                f"{s.errors} erro(s).")
    return status
