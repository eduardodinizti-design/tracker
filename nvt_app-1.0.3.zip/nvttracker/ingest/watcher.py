"""Monitoramento contínuo da pasta de históricos de mão: cada mão concluída vai para o banco em segundos.

Abordagem: *polling* com *debounce*, sem dependências e com todo acesso a disco via ``io_path`` (caminhos longos).
- Varredura completa a cada ``rescan_every`` s para achar arquivos novos (uma mesa nova cria um arquivo novo).
- A cada ``poll`` s, só os arquivos "quentes" (alterados nos últimos ``hot_window`` s) recebem ``stat``.
- Arquivo alterado só é importado depois de ``debounce`` s sem nova alteração (evita ler no meio de uma escrita).
- A importação usa ``import_file``: retoma do offset salvo e o ``splitter`` só entrega mãos completas; a mão em
  andamento nunca é lida pela metade.
Só mãos já terminadas entram no banco.
"""
from __future__ import annotations

import logging
import math
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import psycopg

from ..db import import_file
from ..db.importer import HandEvent
from ..fs import io_path
from ..stats.store import compute_pending
from .discovery import MemberFolder, discover_files

log = logging.getLogger(__name__)

EventHandler = Callable[[HandEvent], None]


@dataclass
class _FileState:
    size: int = -1
    mtime_ns: int = -1
    changed_at: float = -math.inf   # momento (relógio do watcher) da última alteração vista
    hot_until: float = -math.inf    # até quando recebe stat a cada ciclo (fora disso, só na varredura completa)
    pending: bool = True            # precisa importar
    failures: int = 0               # erros seguidos de importação (backoff)


@dataclass
class WatchStats:
    ticks: int = 0
    files: int = 0
    hands_new: int = 0
    hands_new_source: int = 0
    hands_duplicate: int = 0
    quarantined: int = 0
    errors: int = 0
    last_error: str | None = None
    stats_hands: int = 0
    by_room: dict[str, int] = field(default_factory=dict)

    def as_report(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v not in (None, {}, 0) or k == "hands_new"}


class Watcher:
    def __init__(self, conn: psycopg.Connection, root: str | Path, member_id: str, *, batch_id: int | None = None,
                 on_event: EventHandler | None = None, debounce: float = 1.0, rescan_every: float = 30.0,
                 hot_window: float = 600.0, compute_stats: bool = True,
                 clock: Callable[[], float] = time.monotonic):
        self.conn = conn
        self.folder = MemberFolder(member_id, Path(root))
        self.member_id = member_id
        self.batch_id = batch_id
        self.on_event = on_event or (lambda e: None)
        self.debounce = debounce
        self.rescan_every = rescan_every
        self.hot_window = hot_window
        self.compute_stats = compute_stats
        self.clock = clock
        self.files: dict[Path, _FileState] = {}
        self.stats = WatchStats()
        self._next_rescan = -math.inf
        self._warned_rules = False

    # ------------------------------------------------------------------ um ciclo

    def _candidates(self, now: float) -> list[Path]:
        if now >= self._next_rescan:
            self._next_rescan = now + self.rescan_every
            for f in discover_files(self.folder):
                self.files.setdefault(f, _FileState())
            self.stats.files = len(self.files)
            return list(self.files)
        return [f for f, s in self.files.items() if s.pending or now <= s.hot_until]

    def _refresh(self, path: Path, now: float) -> None:
        st = self.files[path]
        try:
            s = io_path(path).stat()
        except FileNotFoundError:
            del self.files[path]   # arquivo removido/renomeado pela sincronização
            return
        if (s.st_size, s.st_mtime_ns) != (st.size, st.mtime_ns):
            if st.size >= 0:       # alteração vista ao vivo: espera o debounce
                st.changed_at = now
                st.hot_until = now + self.hot_window
            elif time.time() - s.st_mtime < self.hot_window:
                # 1ª vez que vemos o arquivo e ele foi gravado há pouco: mesa em andamento, vigiar a cada ciclo.
                # changed_at fica -inf, então o conteúdo já existente (backlog) importa na hora.
                st.hot_until = now + self.hot_window
            st.size, st.mtime_ns, st.pending = s.st_size, s.st_mtime_ns, True

    def _import(self, path: Path) -> list[HandEvent]:
        st = self.files[path]
        try:
            rep = import_file(self.conn, path, self.member_id, self.batch_id)
        except psycopg.OperationalError:
            raise                  # conexão caiu: quem chama decide reconectar
        except (OSError, psycopg.Error, ValueError) as e:
            st.failures += 1
            self.stats.errors += 1
            self.stats.last_error = f"{path.name}: {type(e).__name__}: {e}"[:300]
            log.warning("falha ao importar %s (tentativa %d): %s", path, st.failures, e)
            return []
        st.pending, st.failures = False, 0
        for ev in rep.events:
            if ev.outcome == "new":
                self.stats.hands_new += 1
                self.stats.by_room[ev.room or "?"] = self.stats.by_room.get(ev.room or "?", 0) + 1
            elif ev.outcome == "new_source":
                self.stats.hands_new_source += 1
            elif ev.outcome == "duplicate":
                self.stats.hands_duplicate += 1
            else:
                self.stats.quarantined += 1
        return rep.events

    def tick(self) -> list[HandEvent]:
        """Um ciclo: detecta alterações, importa o que estabilizou e atualiza os stats. Devolve os eventos."""
        now = self.clock()
        self.stats.ticks += 1
        for f in self._candidates(now):
            self._refresh(f, now)
        events: list[HandEvent] = []
        for f, st in list(self.files.items()):
            backoff = min(60.0, self.debounce * (2 ** st.failures)) if st.failures else self.debounce
            if st.pending and now - st.changed_at >= backoff:
                events.extend(self._import(f))
        for ev in events:
            self.on_event(ev)
        if self.compute_stats and any(e.outcome in ("new", "new_source") for e in events):
            rep = compute_pending(self.conn)
            self.stats.stats_hands += rep.hands
            if rep.blocked and not self._warned_rules:
                self._warned_rules = True
                log.warning("regras de stats mudaram: as mãos continuam sendo gravadas, mas os stats esperam o "
                            "admin rodar 'nvt-admin recompute'")
        return events

    # ------------------------------------------------------------------ laço

    def run(self, stop: threading.Event, poll: float = 1.0,
            reconnect: Callable[[], psycopg.Connection] | None = None) -> None:
        """Roda até ``stop`` ser sinalizado. Se a conexão cair, reconecta (com espera crescente) e continua."""
        wait = poll
        while not stop.is_set():
            try:
                self.tick()
                wait = poll
            except psycopg.OperationalError as e:
                if reconnect is None:
                    raise
                log.warning("conexão com o banco perdida (%s); nova tentativa em %.0fs", e, wait)
                stop.wait(wait)
                wait = min(60.0, wait * 2)
                try:
                    self.conn = reconnect()
                except psycopg.OperationalError:
                    continue
            stop.wait(poll)
