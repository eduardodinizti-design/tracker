"""NVT Tracker — ABERTURA. Mostra a tela de loading (radar + logo), sobe o backend (nvt-server)
e abre a UI no navegador. Entry point do .exe: `nvt-tracker`.

    python -m nvttracker.launcher
    nvt-tracker

A splash (viz/splash.html) expõe window.NVTTracker.setProgress(0..100, msg) e .stop(); o launcher
dirige o progresso enquanto o servidor sobe. Sem pywebview/WebView2, só pula a splash."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

SPLASH_FILE = Path(__file__).resolve().parent / "viz" / "splash.html"
PORT = 8750
HOME = f"http://127.0.0.1:{PORT}/nvt_app.html"

PROGRESS_STEPS = [
    (12, "Iniciando o NVT Tracker…"),
    (35, "Subindo o servidor…"),
    (62, "Conectando ao banco de mãos…"),
    (85, "Carregando a base…"),
    (100, "Pronto!"),
]


def splash_html() -> str:
    try:
        return SPLASH_FILE.read_text(encoding="utf-8")
    except Exception:
        return ("<!doctype html><title>NVT Tracker</title>"
                "<body style='background:#08090b;color:#ffb511;font-family:Arial;"
                "display:grid;place-items:center;height:100vh'><h1>NVT TRACKER</h1>"
                "<script>window.NVTTracker={setProgress(){},stop(){}}</script>")


def start_server(port: int = PORT) -> subprocess.Popen:
    """Sobe o nvt-server (backend + telas) como processo próprio, com o DSN resolvido."""
    env = dict(os.environ)
    if not env.get("NVT_DATABASE_URL"):
        try:
            from nvttracker.viz.hud import resolve_dsn
            env["NVT_DATABASE_URL"] = resolve_dsn(None)
        except Exception:
            pass
    return subprocess.Popen([sys.executable, "-m", "nvttracker.viz.server", "--port", str(port)], env=env)


def wait_server(port: int = PORT, timeout: float = 20.0) -> bool:
    """Espera o servidor responder em /api/overview."""
    url = f"http://127.0.0.1:{port}/api/overview"
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2):
                return True
        except Exception:
            time.sleep(0.4)
    return False


def show_splash(seconds: float = 5.0) -> bool:
    """Abre a splash numa janela nativa (pywebview) e dirige o progresso por ~`seconds`."""
    try:
        import webview
    except Exception:
        return False
    window = webview.create_window("NVT Tracker", html=splash_html(),
                                   width=1120, height=680, resizable=False, background_color="#08090b")

    def drive():
        per = max(seconds / len(PROGRESS_STEPS), 0.4)
        for value, msg in PROGRESS_STEPS:
            try:
                window.evaluate_js(f"window.NVTTracker&&window.NVTTracker.setProgress({value},{json.dumps(msg)})")
            except Exception:
                pass
            time.sleep(per)
        try:
            window.evaluate_js("window.NVTTracker&&window.NVTTracker.stop()")
            window.destroy()
        except Exception:
            pass

    try:
        webview.start(drive)
    except Exception:
        return False
    return True


def main(argv: list[str] | None = None) -> int:
    server = start_server(PORT)                 # sobe o backend já
    if not show_splash(5.0):                     # splash enquanto sobe (ou pula sem pywebview)
        time.sleep(1.0)
    wait_server(PORT, timeout=20.0)              # garante que respondeu antes de abrir
    try:
        webbrowser.open(HOME)
    except Exception:
        pass
    print(f"NVT Tracker aberto em {HOME}  (feche esta janela para encerrar)")
    try:
        server.wait()                            # mantém o app vivo enquanto o servidor roda
    except KeyboardInterrupt:
        server.terminate()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
