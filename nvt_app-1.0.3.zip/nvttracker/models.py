"""Modelo normalizado de uma mão NLHE (independente da sala de origem)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum


class Street(str, Enum):
    PREFLOP = "preflop"
    FLOP = "flop"
    TURN = "turn"
    RIVER = "river"


class ActionType(str, Enum):
    POST_ANTE = "post_ante"
    POST_SB = "post_sb"
    POST_BB = "post_bb"
    POST_OTHER = "post_other"  # straddle, dead blind, etc.
    FOLD = "fold"
    CHECK = "check"
    CALL = "call"
    BET = "bet"
    RAISE = "raise"

    @property
    def is_post(self) -> bool:
        return self.value.startswith("post_")

    @property
    def is_voluntary(self) -> bool:
        return self in (ActionType.CALL, ActionType.BET, ActionType.RAISE)

    @property
    def is_aggressive(self) -> bool:
        return self in (ActionType.BET, ActionType.RAISE)


class GameFormat(str, Enum):
    CASH = "cash"
    TOURNAMENT = "tournament"


@dataclass
class Action:
    seq: int
    street: Street
    player: str
    type: ActionType
    amount: Decimal = Decimal(0)        # fichas adicionadas ao pote nesta ação
    amount_to: Decimal | None = None    # total na rua após um raise ("raises X to Y" -> Y)
    is_allin: bool = False


@dataclass
class Player:
    seat: int
    name: str                           # nas salas v1 é o ID numérico do jogador na sala
    stack: Decimal
    sitting_out: bool = False
    position: str | None = None         # BTN, SB, BB, UTG, UTG1, UTG2, LJ, HJ, CO
    cards: list[str] | None = None
    is_hero: bool = False
    invested: Decimal = Decimal(0)
    collected: Decimal = Decimal(0)
    returned: Decimal = Decimal(0)
    went_to_showdown: bool = False
    won_at_showdown: bool = False

    @property
    def net(self) -> Decimal:
        return self.collected + self.returned - self.invested


@dataclass
class Hand:
    room: str
    hand_no: str
    format: GameFormat
    game: str                           # "NLHE" na v1
    started_utc: datetime
    sb: Decimal
    bb: Decimal
    ante: Decimal = Decimal(0)
    currency: str | None = None
    tournament_id: str | None = None
    buyin_text: str | None = None
    club_id: str | None = None
    table_id: str | None = None
    max_seats: int | None = None
    button_seat: int | None = None
    players: list[Player] = field(default_factory=list)
    actions: list[Action] = field(default_factory=list)
    board: list[str] = field(default_factory=list)
    pot: Decimal | None = None
    rake: Decimal = Decimal(0)
    raw_text: str = ""
    warnings: list[str] = field(default_factory=list)  # linhas não reconhecidas (não bloqueiam a mão)

    def player(self, name: str) -> Player:
        for p in self.players:
            if p.name == name:
                return p
        raise KeyError(name)

    @property
    def hero(self) -> Player | None:
        return next((p for p in self.players if p.is_hero), None)

    def actions_on(self, street: Street) -> list[Action]:
        return [a for a in self.actions if a.street == street]

    def chip_balance(self) -> Decimal:
        """Σ net + rake; deve ser 0 numa mão consistente (RF6)."""
        return sum((p.net for p in self.players), Decimal(0)) + self.rake
