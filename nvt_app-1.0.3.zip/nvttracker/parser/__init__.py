"""Leitura de arquivos de histórico: separação em blocos, parsing NLHE e posições."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ..fs import io_path
from ..models import Hand
from .nlhe_text import ParseError, parse_hand
from .splitter import HandBlock, split_hands

__all__ = ["ParseError", "parse_hand", "split_hands", "HandBlock", "FileResult", "parse_file"]


@dataclass
class FileResult:
    path: Path
    hands: list[Hand] = field(default_factory=list)
    errors: list[tuple[HandBlock, ParseError]] = field(default_factory=list)
    consumed: int = 0  # caracteres consumidos a partir de ``start``; o chamador soma ao offset salvo


def parse_file(path: str | Path, *, start: int = 0, final: bool = False) -> FileResult:
    """Lê ``path`` a partir do caractere ``start`` e converte os blocos completos.

    Erros por mão não interrompem o arquivo: vão para ``errors`` (quarentena, RF9).
    """
    path = Path(path)
    text = io_path(path).read_text(encoding="utf-8-sig", errors="replace")[start:]
    blocks, consumed = split_hands(text, final=final)
    result = FileResult(path=path, consumed=consumed)
    for b in blocks:
        try:
            result.hands.append(parse_hand(b.text))
        except ParseError as e:
            result.errors.append((b, e))
    return result
