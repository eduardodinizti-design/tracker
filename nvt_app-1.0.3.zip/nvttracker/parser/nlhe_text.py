"""Parser de históricos NLHE em texto no formato estilo PokerStars (PPPoker, SupremaPoker, X-Poker).

Implementação independente, escrita a partir do formato dos arquivos de histórico (.txt).
"""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from ..models import Action, ActionType, GameFormat, Hand, Player, Street
from .positions import assign_positions

_AMT = r"\$?([\d.,]+)"

HEADER = re.compile(
    r"^(?P<room>\S+) Hand #(?P<no>\d+):\s+"
    r"(?:Tournament #(?P<tid>\d+), )?(?P<desc>.*?)\s*"
    r"\(\D*?(?P<sb>[\d.,]+)\/\D*?(?P<bb>[\d.,]+)(?: - Ante \D*?(?P<ante>[\d.,]+))?[^)]*\)"
    r" - (?P<ts>\d{4}/\d\d/\d\d \d+:\d\d:\d\d)"
)
GAME = re.compile(r"Hold'em No Limit|Hold'em Pot Limit|Hold'em Limit|Omaha[^-(]*|Short Deck[^-(]*")
TABLE = re.compile(r"^Table '(?:ClubId:(?P<club>\d+),)?(?:Table:)?(?P<table>[^' ]+)[^']*' (?P<max>\d+)-max Seat #(?P<btn>\d+) is the button")
SEAT = re.compile(r"^Seat (?P<seat>\d+): (?P<name>.+?) \(" + _AMT + r" in chips\)(?P<rest>.*)$")
STREET = re.compile(r"^\*\*\* (?P<name>HOLE CARDS|FLOP|TURN|RIVER|SHOW ?DOWN|SUMMARY) \*\*\*(?P<cards>.*)$")
CARDS = re.compile(r"\[([^\]]*)\]")
TOTAL_POT = re.compile(r"^Total pot " + _AMT + r".*?\| Rake " + _AMT)

# partes das linhas depois de "<jogador>: "
POST = re.compile(r"^posts (?P<kind>the ante|small blind|big blind|.+?) " + _AMT + r"(?P<allin> and is all-in)?$")
ACTION = re.compile(r"^(?P<verb>folds|checks|calls|bets|raises)(?: " + _AMT + r")?(?: to " + _AMT + r")?(?P<allin> and is all-in)?$")
SHOWS = re.compile(r"^shows \[(?P<cards>[^\]]*)\]")
# linhas que começam com o nome sem ":"
COLLECTED = re.compile(r"^collected " + _AMT + r" from (?:the )?(?:main |side )?pot")
UNCALLED = re.compile(r"^Uncalled bet \(" + _AMT + r"\) returned to (?P<name>.+)$")
DEALT = re.compile(r"^Dealt to (?P<name>.+?) \[(?P<cards>[^\]]*)\]")

_STREET_BY_HEADER = {"FLOP": Street.FLOP, "TURN": Street.TURN, "RIVER": Street.RIVER}
_POST_KIND = {"the ante": ActionType.POST_ANTE, "small blind": ActionType.POST_SB, "big blind": ActionType.POST_BB}
_VERB = {"folds": ActionType.FOLD, "checks": ActionType.CHECK, "calls": ActionType.CALL,
         "bets": ActionType.BET, "raises": ActionType.RAISE}
_CURRENCY = re.compile(r"\b(USD|CNY|EUR|BRL|GBP|INR|RMB)\b")


class ParseError(ValueError):
    """Bloco que não pôde ser convertido; ``reason`` é um código curto para a quarentena (RF9)."""

    def __init__(self, reason: str, detail: str = ""):
        super().__init__(f"{reason}: {detail}" if detail else reason)
        self.reason = reason
        self.detail = detail


def _dec(s: str | None) -> Decimal:
    if not s:
        return Decimal(0)
    try:
        return Decimal(s.replace(",", ""))
    except InvalidOperation as e:
        raise ParseError("bad_amount", s) from e


def _cards(s: str) -> list[str]:
    return [c for c in s.split() if c]


def parse_hand(block: str, *, check_chips: bool = True) -> Hand:
    lines = [ln.rstrip() for ln in block.strip().splitlines() if ln.strip()]
    if not lines:
        raise ParseError("empty_block")

    m = HEADER.match(lines[0])
    if not m:
        raise ParseError("bad_header", lines[0][:120])
    g = GAME.search(m["desc"])
    if g is None or g.group(0) != "Hold'em No Limit":
        raise ParseError("unsupported_game", g.group(0).strip() if g else m["desc"])
    buyin = m["desc"][: g.start()].strip() or None
    cur = _CURRENCY.search(lines[0])
    hand = Hand(
        room=m["room"],
        hand_no=m["no"],
        format=GameFormat.TOURNAMENT if m["tid"] else GameFormat.CASH,
        game="NLHE",
        started_utc=datetime.strptime(m["ts"], "%Y/%m/%d %H:%M:%S").replace(tzinfo=timezone.utc),
        sb=_dec(m["sb"]),
        bb=_dec(m["bb"]),
        ante=_dec(m["ante"]),
        currency=cur.group(1) if cur else None,
        tournament_id=m["tid"],
        buyin_text=buyin if m["tid"] else None,
        raw_text=block.strip(),
    )

    i = 1
    if i < len(lines) and (t := TABLE.match(lines[i])):
        hand.club_id, hand.table_id = t["club"], t["table"]
        hand.max_seats, hand.button_seat = int(t["max"]), int(t["btn"])
        i += 1

    while i < len(lines) and (s := SEAT.match(lines[i])):
        hand.players.append(Player(seat=int(s["seat"]), name=s["name"], stack=_dec(s[3]),
                                   sitting_out="sitting out" in s["rest"]))
        i += 1
    if not hand.players:
        raise ParseError("no_seats")

    names = sorted((p.name for p in hand.players), key=len, reverse=True)
    by_name = {p.name: p for p in hand.players}
    committed: dict[Street, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    street = Street.PREFLOP
    in_showdown = in_summary = False
    seq = 0

    def add_action(player: str, kind: ActionType, amount: Decimal = Decimal(0),
                   amount_to: Decimal | None = None, allin: bool = False) -> None:
        nonlocal seq
        seq += 1
        hand.actions.append(Action(seq, street, player, kind, amount, amount_to, allin))

    for line in lines[i:]:
        if st := STREET.match(line):
            name = st["name"].replace(" ", "")
            if name in _STREET_BY_HEADER:
                street = _STREET_BY_HEADER[name]
                groups = CARDS.findall(st["cards"])
                hand.board = [c for g in groups for c in _cards(g)]
            elif name == "SHOWDOWN":
                in_showdown = True
            elif name == "SUMMARY":
                in_summary = True
            continue

        if in_summary:
            if tp := TOTAL_POT.match(line):
                hand.pot, hand.rake = _dec(tp[1]), _dec(tp[2])
            elif line.startswith("Board ["):
                hand.board = _cards(CARDS.search(line).group(1))
            continue  # linhas "Seat N: ..." do resumo são redundantes com as ações

        if d := DEALT.match(line):
            p = by_name.get(d["name"])
            if p is None:
                raise ParseError("unknown_player", line)
            p.cards, p.is_hero = _cards(d["cards"]), True
            continue
        if u := UNCALLED.match(line):
            p = by_name.get(u["name"].strip())
            if p is None:
                raise ParseError("unknown_player", line)
            p.returned += _dec(u[1])
            continue

        actor = next((n for n in names if line.startswith(n + ": ") or line.startswith(n + " ")), None)
        if actor is None:
            if not line.startswith("Hand ended at"):
                hand.warnings.append(line)
            continue
        p = by_name[actor]
        rest = line[len(actor):].lstrip(":").strip()

        if c := COLLECTED.match(rest):
            p.collected += _dec(c[1])
        elif pm := POST.match(rest):
            amt = _dec(pm[2])
            kind = _POST_KIND.get(pm["kind"], ActionType.POST_OTHER)
            p.invested += amt
            if kind != ActionType.POST_ANTE:
                committed[street][actor] += amt
            add_action(actor, kind, amt, allin=bool(pm["allin"]))
        elif am := ACTION.match(rest):
            kind = _VERB[am["verb"]]
            allin = bool(am["allin"])
            if kind == ActionType.RAISE:
                to = _dec(am[3])
                amt = to - committed[street][actor]
                committed[street][actor] = to
                add_action(actor, kind, amt, to, allin)
            elif kind in (ActionType.CALL, ActionType.BET):
                amt = _dec(am[2])
                committed[street][actor] += amt
                add_action(actor, kind, amt, allin=allin)
            else:
                add_action(actor, kind)
                continue
            p.invested += amt
        elif sh := SHOWS.match(rest):
            p.cards = _cards(sh["cards"])
            if in_showdown:
                p.went_to_showdown = True
        elif rest.startswith("mucks"):
            if in_showdown:
                p.went_to_showdown = True
        else:
            hand.warnings.append(line)

    for p in hand.players:
        p.won_at_showdown = p.went_to_showdown and p.collected > 0
    assign_positions(hand)

    if check_chips and abs(hand.chip_balance()) > Decimal(1):
        raise ParseError("chip_imbalance", f"{hand.room} #{hand.hand_no}: saldo {hand.chip_balance()}")
    return hand
