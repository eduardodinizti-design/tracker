"""Atribui posições (BTN, SB, BB, UTG…CO) aos jogadores de uma mão."""
from __future__ import annotations

from ..models import ActionType, Hand

_EARLY = ["UTG", "UTG1", "UTG2", "UTG3"]
_LATE = ["LJ", "HJ", "CO"]


def middle_positions(k: int) -> list[str]:
    """Nomes das k posições entre o BB e o BTN, na ordem de ação."""
    if k <= 0:
        return []
    if k <= 3:
        return (["UTG"] + _LATE[1:])[-k:]  # 1: CO · 2: HJ CO · 3: UTG HJ CO
    return _EARLY[: k - 3] + _LATE        # 4: UTG LJ HJ CO · 6: UTG UTG1 UTG2 LJ HJ CO


def assign_positions(hand: Hand) -> None:
    active = sorted((p for p in hand.players if not p.sitting_out), key=lambda p: p.seat)
    if not active:
        return
    n = len(active)
    if n < 2:
        return      # mão degenerada (1 jogador) — não atribui posição; nunca crasha o watcher
    btn = hand.button_seat
    # ordem horária começando no primeiro assento depois do botão; o botão fica por último
    after = [p for p in active if btn is None or p.seat > btn] + [p for p in active if btn is not None and p.seat <= btn]
    posters = {a.player: a.type for a in hand.actions if a.type in (ActionType.POST_SB, ActionType.POST_BB)}

    if n == 2:
        # heads-up: o botão posta o SB e age primeiro no pré-flop
        bb, button = after[0], after[1]
        button.position, bb.position = "BTN", "BB"
        return

    sb_name = next((name for name, t in posters.items() if t == ActionType.POST_SB), None)
    order = list(after)
    if sb_name is None and posters.get(order[0].name) == ActionType.POST_BB:
        # SB morto: o primeiro depois do botão é o BB
        order[0].position = "BB"
        rest = order[1:-1]
        order[-1].position = "BTN"
    else:
        order[0].position = "SB"
        order[1].position = "BB"
        rest = order[2:-1]
        order[-1].position = "BTN"
    for p, name in zip(rest, middle_positions(len(rest))):
        p.position = name
