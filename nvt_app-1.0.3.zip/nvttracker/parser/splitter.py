"""Separa o texto de um arquivo de histórico em blocos de mão completos (RF2)."""
from __future__ import annotations

import re
from dataclasses import dataclass

_HAND_START = re.compile(r"^\S+ Hand #\d+:", re.MULTILINE)
_SUMMARY = "*** SUMMARY ***"
# última linha de uma mão gravada em tempo real; o separador "\n\n" só vem ANTES da mão seguinte
_HAND_ENDED = re.compile(r"\nHand ended at \d{4}/\d\d/\d\d \d{1,2}:\d\d:\d\d\s*$")


@dataclass(frozen=True)
class HandBlock:
    text: str
    offset: int  # posição (em caracteres) do início do bloco no texto recebido


def split_hands(text: str, *, final: bool = False) -> tuple[list[HandBlock], int]:
    """Devolve os blocos completos e quantos caracteres foram consumidos.

    Um bloco é completo quando tem ``*** SUMMARY ***`` e é seguido por outra mão. O último bloco do texto (o arquivo
    pode estar sendo escrito) só é aceito se ``final=True``, se termina com linha em branco, ou se termina com a
    linha ``Hand ended at <data hora>`` completa, que é como cada mão é fechada no arquivo em tempo real.
    O chamador salva ``offset_anterior + consumido`` e retoma dali no próximo lote.
    """
    starts = [m.start() for m in _HAND_START.finditer(text)]
    blocks: list[HandBlock] = []
    consumed = 0
    for i, start in enumerate(starts):
        end = starts[i + 1] if i + 1 < len(starts) else len(text)
        chunk = text[start:end]
        is_last = i + 1 == len(starts)
        if is_last and not final and not chunk.endswith(("\n\n", "\r\n\r\n")) \
                and not (_SUMMARY in chunk and _HAND_ENDED.search(chunk)):
            break
        if _SUMMARY not in chunk:
            if is_last:
                break  # ainda incompleto; fica para o próximo lote
        blocks.append(HandBlock(chunk.strip(), start))
        consumed = end
    return blocks, consumed
