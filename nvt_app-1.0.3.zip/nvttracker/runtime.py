"""Serviços em segundo plano do app (watcher + exportador) e o estado que a interface mostra.

Tudo roda no mesmo processo do painel: a interface lê ``RUNTIME`` para exibir status e eventos, no lugar do
terminal.
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

log = logging.getLogger("nvttracker")


@dataclass
class Runtime:
    member: str = ""
    hh_folder: str = ""
    export_folder: str = ""
    export_enabled: bool = False
    export_delay_min: int = 30
    watcher_state: str = "parado"           # iniciando | ativo | parado | erro | duplicado
    watcher_detail: str = ""
    watcher: object | None = None            # Watcher em execução (stats ao vivo)
    session_hands: int = 0                   # mãos novas desde que o app abriu
    last_hand_at: datetime | None = None
    export_state: str = "desligado"
    export_total: int = 0
    export_last: datetime | None = None
    export_error: str = ""
    events: deque = field(default_factory=lambda: deque(maxlen=300))
    lock: threading.Lock = field(default_factory=threading.Lock)

    def event(self, msg: str, level: str = "info") -> None:
        with self.lock:
            self.events.appendleft((datetime.now(), level, msg))
        getattr(log, "warning" if level == "warn" else level if level in ("info", "error") else "info")(msg)


RUNTIME = Runtime()


def _watch_loop(cfg: dict, stop: threading.Event) -> None:
    from .ingest import JobAlreadyRunning
    from .ingest.session import watch_session

    def out(line: str) -> None:
        if "importada com sucesso" in line or "já estava no banco" in line:
            RUNTIME.session_hands += 1
            RUNTIME.last_hand_at = datetime.now()
        RUNTIME.event(line, "warn" if "enviada para a quarentena" in line else "info")

    def on_watcher(w) -> None:
        RUNTIME.watcher = w
        RUNTIME.watcher_state = "ativo"

    while not stop.is_set():
        RUNTIME.watcher_state, RUNTIME.watcher_detail = "iniciando", ""
        try:
            watch_session(Path(cfg["hh_folder"]), cfg["member"], cfg["database_url"], stop, out=out,
                          on_watcher=on_watcher)
            RUNTIME.watcher_state = "parado"
            return
        except JobAlreadyRunning as e:
            RUNTIME.watcher_state = "duplicado"
            RUNTIME.watcher_detail = f"o NvtTracker já está capturando as mãos de {cfg['member']} em outro lugar"
            RUNTIME.event(RUNTIME.watcher_detail + f" ({e.holder}); nova tentativa em 60 s", "warn")
        except Exception as e:  # noqa: BLE001 - mostrado na interface; tenta de novo
            RUNTIME.watcher_state, RUNTIME.watcher_detail = "erro", f"{type(e).__name__}: {e}"
            RUNTIME.event(f"captura parou: {RUNTIME.watcher_detail}; nova tentativa em 60 s", "error")
        stop.wait(60)


def _export_loop(cfg: dict, stop: threading.Event, every: float = 60.0) -> None:
    from .db import connect
    from .export import export_team_hands

    conn = None
    while not stop.is_set():
        try:
            conn = conn or connect(cfg["database_url"])
            RUNTIME.export_state = "exportando"
            total = 0
            while not stop.is_set():
                rep = export_team_hands(conn, cfg["export_folder"], cfg["member"],
                                        delay_minutes=int(cfg["export_delay_min"]))
                total += rep.hands
                if rep.hands == 0:
                    break
            if total:
                RUNTIME.export_total += total
                RUNTIME.event(f"{total} mão(s) do time gravada(s) em {cfg['export_folder']}")
            RUNTIME.export_state, RUNTIME.export_error = "ativo", ""
            RUNTIME.export_last = datetime.now()
        except Exception as e:  # noqa: BLE001
            RUNTIME.export_state, RUNTIME.export_error = "erro", f"{type(e).__name__}: {e}"
            RUNTIME.event(f"exportação: {RUNTIME.export_error}", "error")
            try:
                conn and conn.close()
            except Exception:  # noqa: BLE001
                pass
            conn = None
        stop.wait(every)


def start_services(cfg: dict) -> threading.Event:
    """Inicia watcher e exportador em threads; devolve o evento que as encerra."""
    RUNTIME.member, RUNTIME.hh_folder = cfg["member"], cfg["hh_folder"]
    RUNTIME.export_folder = cfg.get("export_folder", "")
    RUNTIME.export_enabled = str(cfg.get("export_enabled", "true")).lower() in ("1", "true", "sim", "yes")
    RUNTIME.export_delay_min = int(cfg.get("export_delay_min", 30))
    stop = threading.Event()
    threading.Thread(target=_watch_loop, args=(cfg, stop), name="nvt-watch", daemon=True).start()
    if RUNTIME.export_enabled and RUNTIME.export_folder:
        threading.Thread(target=_export_loop, args=(cfg, stop), name="nvt-export", daemon=True).start()
    RUNTIME.event(f"NvtTracker iniciado · membro {cfg['member']}")
    return stop


def wait_stopped(stop: threading.Event, timeout: float = 15) -> None:
    stop.set()
    deadline = time.monotonic() + timeout
    for t in threading.enumerate():
        if t.name in ("nvt-watch", "nvt-export"):
            t.join(max(0.1, deadline - time.monotonic()))
