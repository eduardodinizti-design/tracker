"""Motor de stats v1: regras (definitions), agregação incremental em stat_acc (engine), relatório e validação."""
from .context import HandContext, build_context
from .definitions import RULES_VERSION, STATS, Outcome
from .engine import Accumulator, evaluate_hand

__all__ = ["STATS", "RULES_VERSION", "Outcome", "HandContext", "build_context", "evaluate_hand", "Accumulator"]
