"""Análise OFFLINE por POSIÇÃO (estilo H2N): agrega as stats de um jogador por posição
(EP/MP/LJ/HJ/CO/BTN/SB/BB) e o winrate em bb/100. PURO: recebe mãos (Hand) + o net em BB
por mão; não toca no banco (o viz carrega os dados e chama aqui). Reusa o motor de stats."""
from __future__ import annotations

from collections import defaultdict

from ..models import Hand
from .definitions import Outcome
from .engine import evaluate_hand

# ordem de exibição das posições (da mais early p/ os blinds)
POSITION_ORDER = ["UTG", "UTG1", "UTG2", "UTG3", "LJ", "HJ", "CO", "BTN", "SB", "BB"]


def position_stats(hands: list[Hand], player_id: str) -> dict[str, dict[str, tuple[int, int]]]:
    """{posição: {stat_id: (oportunidades, casos)}} agregando as mãos do jogador por posição."""
    acc: dict[str, dict[str, list[int]]] = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    for h in hands:
        p = next((pl for pl in h.players if pl.name == player_id), None)
        if p is None or not p.position:
            continue
        for who, stat, outcome in evaluate_hand(h):      # (jogador, stat, outcome)
            if who != player_id or outcome == Outcome.NONE:
                continue
            acc[p.position][stat][0] += 1
            if outcome == Outcome.CASE:
                acc[p.position][stat][1] += 1
    return {pos: {s: (o, c) for s, (o, c) in d.items()} for pos, d in acc.items()}


def position_winrate(net_bb_by_pos: dict[str, list[float]]) -> dict[str, dict[str, float]]:
    """{posição: {hands, bb_per_100, total_bb}} a partir dos nets (em BB) por posição.
    net_bb = ganho/perda da mão em big blinds (coluna hand_players.net_bb)."""
    out = {}
    for pos, nets in net_bb_by_pos.items():
        n = len(nets)
        total = sum(nets)
        out[pos] = {"hands": n, "total_bb": total, "bb_per_100": (100.0 * total / n) if n else 0.0}
    return out


def ordered_positions(positions) -> list[str]:
    """Posições na ordem canônica (early -> blinds); desconhecidas ao fim."""
    known = [p for p in POSITION_ORDER if p in positions]
    extra = [p for p in positions if p not in POSITION_ORDER]
    return known + sorted(extra)


def position_report(hands: list[Hand], player_id: str, with_ev: bool = True) -> dict[str, dict]:
    """Relatório COMPLETO por posição a partir de mãos PARSEADAS (com cartas/fichas): por posição
    {hands, net_bb, ev_bb, stats:{stat:(opps,cases)}}. net_bb = resultado real; ev_bb = EV
    all-in ajustado (equity). with_ev=False pula a equity (rápido; ev_bb vira = net_bb)."""
    from collections import defaultdict

    from .ev import hand_ev

    agg: dict[str, dict] = defaultdict(lambda: {"hands": 0, "net_bb": 0.0, "ev_bb": 0.0,
                                                "stats": defaultdict(lambda: [0, 0])})
    for h in hands:
        p = next((pl for pl in h.players if pl.name == player_id), None)
        if p is None or not p.position:
            continue
        bb = float(h.bb or 0) or 1.0
        a = agg[p.position]
        a["hands"] += 1
        net = float(p.collected or 0) + float(p.returned or 0) - float(p.invested or 0)
        a["net_bb"] += net / bb
        a["ev_bb"] += (hand_ev(h).get(player_id, net) / bb) if with_ev else (net / bb)
        for who, stat, outcome in evaluate_hand(h):
            if who == player_id and outcome != Outcome.NONE:
                a["stats"][stat][0] += 1
                if outcome == Outcome.CASE:
                    a["stats"][stat][1] += 1
    return {pos: {"hands": d["hands"], "net_bb": d["net_bb"], "ev_bb": d["ev_bb"],
                  "stats": {s: (o, c) for s, (o, c) in d["stats"].items()}} for pos, d in agg.items()}
