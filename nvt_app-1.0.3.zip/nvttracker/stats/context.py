"""Leitura estruturada da ação de uma mão: decisões pré-flop com o nível de raise que cada jogador enfrentou."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal

from ..models import Action, ActionType, Hand, Street


@dataclass(frozen=True)
class Decision:
    """Uma ação voluntária (não post) com o contexto do momento em que foi tomada."""
    action: Action
    raises_before: int       # quantos raises pré-flop já tinham acontecido (o BB postado não conta)
    callers_before: int      # quantos calls (limps/cold-calls) já tinham acontecido
    index: int               # posição da decisão na sequência pré-flop
    can_raise: bool = True   # tinha fichas além do valor a pagar e algum oponente ainda com fichas para agir

    @property
    def type(self) -> ActionType:
        return self.action.type


@dataclass
class HandContext:
    hand: Hand
    preflop: list[Decision] = field(default_factory=list)
    by_player: dict[str, list[Decision]] = field(default_factory=dict)
    raisers: list[str] = field(default_factory=list)   # quem fez o 1º, 2º, 3º... raise pré-flop
    folded_preflop: set[str] = field(default_factory=set)

    @property
    def opener(self) -> str | None:
        """Quem fez o 1º raise pré-flop (open raise ou iso-raise)."""
        return self.raisers[0] if self.raisers else None

    @property
    def last_aggressor(self) -> str | None:
        return self.raisers[-1] if self.raisers else None

    def decisions(self, player: str) -> list[Decision]:
        return self.by_player.get(player, [])

    def saw_flop(self, player: str) -> bool:
        return len(self.hand.board) >= 3 and player not in self.folded_preflop

    def flop_actions(self) -> list[Action]:
        return [a for a in self.hand.actions if a.street == Street.FLOP and not a.type.is_post]

    def actions_on(self, street: Street) -> list[Action]:
        return [a for a in self.hand.actions if a.street == street and not a.type.is_post]


def build_context(hand: Hand) -> HandContext:
    """Percorre o pré-flop acompanhando, por jogador, o investido e o que já pôs na rua. Assim cada decisão sabe se
    havia opção real de raise: fichas restantes > valor a pagar e algum oponente ativo que não esteja all-in.
    Ex.: o BB curto diante de um shove maior que o stack dele só pode pagar ou foldar."""
    ctx = HandContext(hand)
    raises = calls = 0
    stack = {p.name: p.stack for p in hand.players}
    invested: dict[str, Decimal] = defaultdict(Decimal)   # total investido na mão (antes e blinds inclusive)
    on_street: dict[str, Decimal] = defaultdict(Decimal)  # posto na rua pré-flop (sem ante)
    level = Decimal(0)
    gone: set[str] = {p.name for p in hand.players if p.sitting_out}   # foldaram ou estão all-in
    for a in hand.actions:
        if a.street != Street.PREFLOP:
            continue
        if not a.type.is_post:
            to_call = level - on_street[a.player]
            remaining = stack.get(a.player, Decimal(0)) - invested[a.player]
            rivals = any(p.name != a.player and p.name not in gone for p in hand.players)
            d = Decision(a, raises, calls, len(ctx.preflop), can_raise=remaining > to_call and rivals)
            ctx.preflop.append(d)
            ctx.by_player.setdefault(a.player, []).append(d)
        invested[a.player] += a.amount
        if a.type != ActionType.POST_ANTE:
            on_street[a.player] = a.amount_to if a.amount_to is not None else on_street[a.player] + a.amount
            level = max(level, on_street[a.player])
        if a.type == ActionType.FOLD or a.is_allin or invested[a.player] >= stack.get(a.player, Decimal(0)):
            gone.add(a.player)
        if a.type.is_post:
            continue
        if a.type == ActionType.RAISE:
            raises += 1
            ctx.raisers.append(a.player)
        elif a.type == ActionType.CALL:
            calls += 1
        elif a.type == ActionType.FOLD:
            ctx.folded_preflop.add(a.player)
    return ctx
