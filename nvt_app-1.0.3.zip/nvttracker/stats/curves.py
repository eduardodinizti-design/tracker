"""Curva de ganhos (estilo 'Graph' do H2N): acumulado mão a mão de Won / All-in EV /
Won at Showdown / Won without Showdown, em big blinds. PURO (recebe mãos parseadas)."""
from __future__ import annotations

from ..models import Hand
from .ev import hand_ev


def _net_bb(p, bb: float) -> float:
    return (float(p.collected or 0) + float(p.returned or 0) - float(p.invested or 0)) / bb


def winnings_curve(hands: list[Hand], player_id: str, with_ev: bool = True) -> list[dict]:
    """Lista de pontos acumulados (um por mão do jogador, na ordem recebida):
    {n, won, ev, won_sd, won_nosd} — tudo em bb. 'won' = resultado real; 'ev' = all-in ajustado;
    as linhas SD/noSD andam só nas mãos do seu tipo (degraus), como no H2N.
    with_ev=False pula o cálculo de equity (rápido; 'ev' vira = 'won')."""
    pts: list[dict] = []
    won = ev = won_sd = won_nosd = 0.0
    n = 0
    for h in hands:
        p = next((pl for pl in h.players if pl.name == player_id), None)
        if p is None:
            continue
        bb = float(h.bb or 0) or 1.0
        net = _net_bb(p, bb)
        won += net
        ev += (hand_ev(h).get(player_id, net * bb) / bb) if with_ev else net
        if p.went_to_showdown:
            won_sd += net
        else:
            won_nosd += net
        n += 1
        pts.append({"n": n, "won": round(won, 2), "ev": round(ev, 2),
                    "won_sd": round(won_sd, 2), "won_nosd": round(won_nosd, 2)})
    return pts
