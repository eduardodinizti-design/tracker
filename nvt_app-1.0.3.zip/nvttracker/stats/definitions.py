"""Regras dos stats v1: para cada (mão, jogador) decide NONE (não conta), OPP (oportunidade) ou CASE (fez a ação).

Valor exibido = 100 × casos / oportunidades. Todo CASE também é uma OPP.
"""
from __future__ import annotations

from enum import Enum
from typing import Callable

from ..models import ActionType, Street
from .context import HandContext

# Versão das regras. Mudou alguma regra? Incremente: o motor recalcula tudo a partir das mãos gravadas (RF11).
# v2: PFR, 3Bet e Steal só contam oportunidade quando havia opção real de raise (homologação, out/2026).
# v3: Steal só BTN e SB; C-Bet Flop só em pote de 1 raise (definição padrão de mercado: 52 e 74 na homologação).
# v4: +Check-Raise (flop), +Fold to C-Bet (flop), +WTSD, +W$SD — p/ o HUD estilo PPPoker VIP.
# v5: +WWSF, +Squeeze, +4Bet, +Fold to 4Bet, +Fold to Steal, +C-Bet Turn (stats de HUD padrão).
RULES_VERSION = 5


class Outcome(int, Enum):
    NONE = 0
    OPP = 1
    CASE = 2


Rule = Callable[[HandContext, str], Outcome]
STEAL_POSITIONS = {"BTN", "SB"}  # definição padrão; o CO não entra no Steal


def _case_if(cond: bool) -> Outcome:
    return Outcome.CASE if cond else Outcome.OPP


def vpip(ctx: HandContext, p: str) -> Outcome:
    """OPP: teve ao menos uma decisão pré-flop (exclui o walk do BB e quem ficou all-in só com o blind).
    CASE: colocou dinheiro voluntariamente (call ou raise). Postar blind/ante não conta."""
    ds = ctx.decisions(p)
    if not ds:
        return Outcome.NONE
    return _case_if(any(d.type in (ActionType.CALL, ActionType.RAISE) for d in ds))


def pfr(ctx: HandContext, p: str) -> Outcome:
    """OPP: ao menos uma decisão pré-flop COM opção de raise (ex.: o BB curto diante de um shove que o cobre não tem
    oportunidade). CASE: deu qualquer raise pré-flop."""
    ds = ctx.decisions(p)
    if not any(d.can_raise for d in ds):
        return Outcome.NONE
    return _case_if(any(d.type == ActionType.RAISE for d in ds))


def three_bet(ctx: HandContext, p: str) -> Outcome:
    """OPP: o jogador chega a uma decisão enfrentando EXATAMENTE 1 raise feito por outro jogador
    (inclui quem limpou antes e agora enfrenta o raise), com opção real de re-raise. CASE: dá raise nessa decisão."""
    if ctx.opener == p:
        return Outcome.NONE
    d = next((d for d in ctx.decisions(p) if d.raises_before == 1), None)
    if d is None or not d.can_raise:
        return Outcome.NONE
    return _case_if(d.type == ActionType.RAISE)


def fold_to_3bet(ctx: HandContext, p: str) -> Outcome:
    """OPP: o jogador fez o 1º raise e depois decide enfrentando EXATAMENTE 1 re-raise (3bet), sem 4bet no meio.
    CASE: fold nessa decisão."""
    if ctx.opener != p:
        return Outcome.NONE
    ds = ctx.decisions(p)
    open_idx = next(i for i, d in enumerate(ds) if d.type == ActionType.RAISE and d.raises_before == 0)
    d = next((d for d in ds[open_idx + 1:] if d.raises_before >= 2), None)
    if d is None or d.raises_before != 2:
        return Outcome.NONE
    return _case_if(d.type == ActionType.FOLD)


def steal(ctx: HandContext, p: str) -> Outcome:
    """OPP: jogador no BTN ou SB e todos antes dele deram fold (first in: sem raise e sem limp), com opção de raise.
    CASE: open raise nessa decisão. Limp não é steal."""
    player = ctx.hand.player(p)
    if player.position not in STEAL_POSITIONS:
        return Outcome.NONE
    ds = ctx.decisions(p)
    if not ds:
        return Outcome.NONE
    d = ds[0]
    if d.raises_before != 0 or d.callers_before != 0 or not d.can_raise:
        return Outcome.NONE
    return _case_if(d.type == ActionType.RAISE)


def cbet_flop(ctx: HandContext, p: str) -> Outcome:
    """OPP: pote de 1 raise em que o jogador foi o raiser (pote de 3bet não conta), viu o flop, age no flop e
    ninguém apostou antes dele (nem donk bet). CASE: aposta (bet) na 1ª ação dele no flop."""
    if ctx.raisers != [p] or not ctx.saw_flop(p):
        return Outcome.NONE
    for a in ctx.flop_actions():
        if a.player == p:
            return _case_if(a.type == ActionType.BET)
        if a.type.is_aggressive:
            return Outcome.NONE  # alguém apostou antes: não é oportunidade de c-bet
    return Outcome.NONE          # não agiu no flop (ex.: all-in pré-flop / todos all-in)


def fold_to_cbet(ctx: HandContext, p: str) -> Outcome:
    """OPP: pote de 1 raise (o único raiser pré-flop NÃO é p), p viu o flop e ENFRENTA a c-bet
    (o raiser apostou no flop e p age depois). CASE: p dá fold diante dessa aposta."""
    if len(ctx.raisers) != 1 or ctx.opener == p or not ctx.saw_flop(p):
        return Outcome.NONE
    opener = ctx.opener
    bet_seen = False
    for a in ctx.flop_actions():
        if a.player == opener and a.type == ActionType.BET:
            bet_seen = True
            continue
        if bet_seen and a.player == p:
            return _case_if(a.type == ActionType.FOLD)
    return Outcome.NONE


def check_raise(ctx: HandContext, p: str) -> Outcome:
    """Check-raise de FLOP. OPP: p deu CHECK no flop e DEPOIS enfrentou uma aposta (teve 2ª
    decisão no flop). CASE: essa 2ª ação foi RAISE (deu check-raise). (Aprox.: não checa fichas.)"""
    if not ctx.saw_flop(p):
        return Outcome.NONE
    mine = [a for a in ctx.flop_actions() if a.player == p]
    if not mine or mine[0].type != ActionType.CHECK or len(mine) < 2:
        return Outcome.NONE          # não checou, ou checou e ninguém apostou -> sem oportunidade
    return _case_if(mine[1].type == ActionType.RAISE)


def wtsd(ctx: HandContext, p: str) -> Outcome:
    """Went To ShowDown. OPP: p viu o flop. CASE: p foi ao showdown."""
    if not ctx.saw_flop(p):
        return Outcome.NONE
    return _case_if(ctx.hand.player(p).went_to_showdown)


def wsd(ctx: HandContext, p: str) -> Outcome:
    """Won money at ShowDown (W$SD). OPP: p foi ao showdown. CASE: p ganhou no showdown."""
    pl = ctx.hand.player(p)
    if not pl.went_to_showdown:
        return Outcome.NONE
    return _case_if(pl.won_at_showdown)


def wwsf(ctx: HandContext, p: str) -> Outcome:
    """Won When Saw Flop. OPP: viu o flop. CASE: ganhou a mão (collected > 0)."""
    if not ctx.saw_flop(p):
        return Outcome.NONE
    return _case_if(ctx.hand.player(p).collected > 0)


def squeeze(ctx: HandContext, p: str) -> Outcome:
    """OPP: decide enfrentando EXATAMENTE 1 raise E ao menos 1 caller (limp/cold-call) antes,
    com opção de re-raise, e não é o opener. CASE: raise (squeeze)."""
    if ctx.opener == p:
        return Outcome.NONE
    d = next((d for d in ctx.decisions(p) if d.raises_before == 1 and d.callers_before >= 1), None)
    if d is None or not d.can_raise:
        return Outcome.NONE
    return _case_if(d.type == ActionType.RAISE)


def four_bet(ctx: HandContext, p: str) -> Outcome:
    """OPP: decide enfrentando EXATAMENTE 2 raises (um 3bet), com opção de re-raise. CASE: raise."""
    d = next((d for d in ctx.decisions(p) if d.raises_before == 2), None)
    if d is None or not d.can_raise:
        return Outcome.NONE
    return _case_if(d.type == ActionType.RAISE)


def fold_to_4bet(ctx: HandContext, p: str) -> Outcome:
    """OPP: p deu o 3bet (raise enfrentando 1 raise) e depois decide enfrentando um 4bet
    (raises_before == 3). CASE: fold."""
    ds = ctx.decisions(p)
    tbet = next((i for i, d in enumerate(ds) if d.type == ActionType.RAISE and d.raises_before == 1), None)
    if tbet is None:
        return Outcome.NONE
    d = next((d for d in ds[tbet + 1:] if d.raises_before >= 3), None)
    if d is None or d.raises_before != 3:
        return Outcome.NONE
    return _case_if(d.type == ActionType.FOLD)


def fold_to_steal(ctx: HandContext, p: str) -> Outcome:
    """Defesa do BB contra roubo. OPP: p no BB enfrentando um STEAL (open único de BTN/SB),
    primeira decisão, sem caller, com opção. CASE: fold."""
    if ctx.hand.player(p).position != "BB":
        return Outcome.NONE
    opener = ctx.opener
    if opener is None or ctx.hand.player(opener).position not in STEAL_POSITIONS:
        return Outcome.NONE
    d = next((d for d in ctx.decisions(p) if d.raises_before == 1), None)
    if d is None or d.callers_before != 0 or not d.can_raise:
        return Outcome.NONE
    return _case_if(d.type == ActionType.FOLD)


def cbet_turn(ctx: HandContext, p: str) -> Outcome:
    """2º barril. OPP: p foi o c-bettor do flop (único raiser pré-flop que apostou no flop), a
    mão chegou ao TURN, e p age no turn sem aposta antes dele. CASE: aposta no turn."""
    if ctx.raisers != [p] or len(ctx.hand.board) < 4:
        return Outcome.NONE
    flop = ctx.flop_actions()
    bet_i = next((i for i, a in enumerate(flop) if a.player == p and a.type == ActionType.BET), None)
    if bet_i is None or bet_i != next((i for i, a in enumerate(flop) if a.player == p), -1):
        return Outcome.NONE                 # p não deu c-bet (1ª ação dele no flop)
    if any(a.type.is_aggressive for a in flop[bet_i + 1:]):
        return Outcome.NONE                 # a c-bet LEVOU raise -> p perdeu a iniciativa
    for a in ctx.actions_on(Street.TURN):
        if a.player == p:
            return _case_if(a.type == ActionType.BET)
        if a.type.is_aggressive:
            return Outcome.NONE             # alguém apostou/raise antes de p no turn
    return Outcome.NONE


STATS: dict[str, Rule] = {
    "vpip": vpip,
    "pfr": pfr,
    "three_bet": three_bet,
    "fold_to_3bet": fold_to_3bet,
    "steal": steal,
    "cbet_flop": cbet_flop,
    "check_raise": check_raise,
    "fold_to_cbet": fold_to_cbet,
    "wtsd": wtsd,
    "wsd": wsd,
    "wwsf": wwsf,
    "squeeze": squeeze,
    "four_bet": four_bet,
    "fold_to_4bet": fold_to_4bet,
    "fold_to_steal": fold_to_steal,
    "cbet_turn": cbet_turn,
}
