"""Avaliação pura (sem banco): mão → resultados por jogador e stat; acumulador separado por formato."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable

from ..models import Hand
from .context import build_context
from .definitions import STATS, Outcome

# chave de agregação: formato faz parte da chave, então cash e torneio nunca se misturam (D2)
Key = tuple[str, str, str, str]  # (room, player_id, format, stat_id)


def evaluate_hand(hand: Hand) -> list[tuple[str, str, Outcome]]:
    """[(player_id, stat_id, outcome)] para todos os jogadores da mão, sem os NONE."""
    ctx = build_context(hand)
    out = []
    for p in hand.players:
        if p.sitting_out:
            continue
        for stat_id, rule in STATS.items():
            r = rule(ctx, p.name)
            if r is not Outcome.NONE:
                out.append((p.name, stat_id, r))
    return out


@dataclass
class Accumulator:
    counts: dict[Key, list[int]] = field(default_factory=lambda: defaultdict(lambda: [0, 0]))  # [opps, cases]
    hands: int = 0

    def add(self, hand: Hand) -> None:
        self.hands += 1
        for player, stat_id, outcome in evaluate_hand(hand):
            c = self.counts[(hand.room, player, hand.format.value, stat_id)]
            c[0] += 1
            if outcome is Outcome.CASE:
                c[1] += 1

    def add_all(self, hands: Iterable[Hand]) -> "Accumulator":
        for h in hands:
            self.add(h)
        return self

    def value(self, key: Key) -> float | None:
        opps, cases = self.counts.get(key, (0, 0))
        return 100.0 * cases / opps if opps else None
