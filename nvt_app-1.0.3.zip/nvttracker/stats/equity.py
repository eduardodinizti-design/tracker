"""Equity de Texas Hold'em (p/ o EV bb/100 ajustado, estilo H2N). Avaliador de 7 cartas +
enumeração do board (exata quando faltam ≤2 cartas; Monte-Carlo determinístico no pré-flop).
PURO, sem dependências. Cartas em texto 'As','Td','7h'..."""
from __future__ import annotations

import random
from collections import Counter
from itertools import combinations
from math import comb

_RANKS = {r: i for i, r in enumerate("..23456789TJQKA")}   # '2'->2 ... 'A'->14
_SUITS = {"s": 0, "h": 1, "d": 2, "c": 3}


def parse_card(c: str) -> tuple[int, int]:
    """'As' -> (14, 0). Levanta ValueError se inválida."""
    c = c.strip()
    return (_RANKS[c[0].upper()], _SUITS[c[1].lower()])


def _straight_high(rank_set: set[int]) -> int | None:
    rs = set(rank_set)
    if {14, 2, 3, 4, 5} <= rs:                 # roda (A-5): a maior é o 5
        best = 5
    else:
        best = None
    for hi in range(14, 5, -1):
        if all((hi - i) in rs for i in range(5)):
            return hi
    return best


def rank5(cards: list[tuple[int, int]]) -> tuple:
    """Força de 5 cartas como tupla COMPARÁVEL (maior = melhor)."""
    ranks = sorted((c[0] for c in cards), reverse=True)
    cnt = Counter(ranks)
    ordered = sorted(cnt, key=lambda r: (cnt[r], r), reverse=True)   # por (frequência, rank)
    counts = sorted(cnt.values(), reverse=True)
    flush = len({c[1] for c in cards}) == 1
    sh = _straight_high(set(ranks))
    if sh and flush:
        return (8, sh)
    if counts[0] == 4:
        return (7, tuple(ordered))
    if counts == [3, 2]:
        return (6, tuple(ordered))
    if flush:
        return (5, tuple(ranks))
    if sh:
        return (4, sh)
    if counts[0] == 3:
        return (3, tuple(ordered))
    if counts[:2] == [2, 2]:
        return (2, tuple(ordered))
    if counts[0] == 2:
        return (1, tuple(ordered))
    return (0, tuple(ranks))


def best7(cards: list[tuple[int, int]]) -> tuple:
    """Melhor mão de 5 entre 5..7 cartas."""
    if len(cards) <= 5:
        return rank5(cards)
    return max(rank5(list(c)) for c in combinations(cards, 5))


_FULL_DECK = [(r, s) for r in range(2, 15) for s in range(4)]


def equity(holes: list[list[tuple[int, int]]], board: list[tuple[int, int]],
           iters: int = 4000, seed: int = 1, exact_limit: int = 3000) -> list[float]:
    """Fração de equity por jogador. `holes` = [[c,c], ...] (cartas conhecidas); `board` 0..5
    cartas. Enumera o board faltante (exato se as combinações ≤ exact_limit; senão Monte-Carlo)."""
    known = set(board) | {c for h in holes for c in h}
    deck = [c for c in _FULL_DECK if c not in known]
    need = 5 - len(board)
    res = [0.0] * len(holes)
    if need <= 0:
        combos = [()]
    elif comb(len(deck), need) <= exact_limit:
        combos = combinations(deck, need)
    else:
        rng = random.Random(seed)
        combos = (tuple(rng.sample(deck, need)) for _ in range(iters))
    total = 0
    for extra in combos:
        full = board + list(extra)
        scores = [best7(h + full) for h in holes]
        top = max(scores)
        win = [i for i, s in enumerate(scores) if s == top]
        for i in win:
            res[i] += 1.0 / len(win)
        total += 1
    return [r / total for r in res] if total else [0.0] * len(holes)
