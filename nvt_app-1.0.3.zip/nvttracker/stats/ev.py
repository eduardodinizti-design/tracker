"""EV por mão (all-in ajustado, estilo H2N). Quando houve ALL-IN que foi ao SHOWDOWN (cartas
conhecidas) ANTES do river, o resultado dos jogadores do showdown é trocado pela EQUITY no
board do momento do all-in (tira a variância do runout). Caso contrário, usa o resultado REAL.
Hoje ajusta o caso HEADS-UP (2 jogadores no showdown); multiway cai no resultado real (limite)."""
from __future__ import annotations

from ..models import ActionType, Hand, Street
from .equity import equity, parse_card

_BOARD_N = {Street.PREFLOP: 0, Street.FLOP: 3, Street.TURN: 4, Street.RIVER: 5}
_STREET_IDX = {Street.PREFLOP: 0, Street.FLOP: 1, Street.TURN: 2, Street.RIVER: 3}


def _contrib(p) -> float:
    """Fichas que o jogador deixou no pote (investido − devolvido)."""
    return float(p.invested or 0) - float(p.returned or 0)


def _actual_net(p) -> float:
    return float(p.collected or 0) + float(p.returned or 0) - float(p.invested or 0)


def hand_ev(hand: Hand) -> dict[str, float]:
    """{jogador: EV líquido em FICHAS}. = resultado real, exceto no all-in HU ao showdown onde
    o EV = equity × pote − contribuição."""
    net = {p.name: _actual_net(p) for p in hand.players}
    # rua do all-in mais TARDIO (antes do river); None se não houve all-in que corre o board
    allin_street = None
    for a in hand.actions:
        if a.is_allin and a.street != Street.RIVER:
            if allin_street is None or _STREET_IDX[a.street] > _STREET_IDX[allin_street]:
                allin_street = a.street
    showdown = [p for p in hand.players if p.went_to_showdown and len(p.cards or []) == 2]
    if allin_street is None or len(showdown) != 2:
        return net                        # sem ajuste (ou multiway: usa o real)
    try:
        holes = [[parse_card(c) for c in p.cards] for p in showdown]
        board = [parse_card(c) for c in (hand.board or [])][: _BOARD_N[allin_street]]
        eq = equity(holes, board)
    except Exception:
        return net
    pot = sum(_contrib(p) for p in hand.players)      # pote casado (inclui dead money dos que foldaram)
    ev = dict(net)
    for i, p in enumerate(showdown):
        ev[p.name] = eq[i] * pot - _contrib(p)
    return ev
