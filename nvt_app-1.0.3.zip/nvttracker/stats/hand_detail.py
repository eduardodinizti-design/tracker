"""Detalhe de uma mão no estilo tracker: cartas + lances por rua (pré-flop/flop/turn/river)
com código compacto (R/C/B/X/F + tamanho em bb), board e pote por rua. PURO."""
from __future__ import annotations

from ..models import ActionType, Hand, Street

_SMAP = {Street.PREFLOP: "preflop", Street.FLOP: "flop", Street.TURN: "turn", Street.RIVER: "river"}
_POSTS = {ActionType.POST_SB, ActionType.POST_BB, ActionType.POST_ANTE, ActionType.POST_OTHER}
_BOARD_N = {"preflop": 0, "flop": 3, "turn": 4, "river": 5}


def _fmt(x: float) -> str:
    """2.5 -> '2.5', 4.0 -> '4' (bb)."""
    return (f"{x:.1f}".rstrip("0").rstrip(".")) if x else "0"


def hand_detail(hand: Hand, player_id: str) -> dict:
    """{cards, pos, result_bb, streets:{<rua>:{board, pot, acts:[{code,kind,hero}]}}}.
    `code` ex.: 'R2.5' (raise p/ 2.5bb), 'C1', 'B13', 'X', 'F'. `kind` p/ cor."""
    p = next((pl for pl in hand.players if pl.name == player_id), None)
    bb = float(hand.bb or 0) or 1.0
    board = [str(c) for c in (hand.board or [])]
    streets = {s: {"board": board[:_BOARD_N[s]], "pot": 0.0, "acts": []}
               for s in ("preflop", "flop", "turn", "river")}
    committed: dict[str, float] = {}
    pot = 0.0
    for a in hand.actions:
        s = _SMAP.get(a.street)
        if s is None:
            continue
        amt = float(a.amount or 0)
        kind = None
        code = None
        if a.type in _POSTS:
            committed[a.player] = committed.get(a.player, 0) + amt
            pot += amt
        elif a.type == ActionType.FOLD:
            kind, code = "fold", "F"
        elif a.type == ActionType.CHECK:
            kind, code = "check", "X"
        elif a.type == ActionType.CALL:
            committed[a.player] = committed.get(a.player, 0) + amt
            pot += amt
            kind, code = "call", "C" + _fmt(amt / bb)
        elif a.type == ActionType.BET:
            committed[a.player] = committed.get(a.player, 0) + amt
            pot += amt
            kind, code = "bet", "B" + _fmt(amt / bb)
        elif a.type == ActionType.RAISE:
            to = float(a.amount_to or (committed.get(a.player, 0) + amt))
            inc = to - committed.get(a.player, 0)
            committed[a.player] = to
            pot += inc
            kind, code = "raise", "R" + _fmt(to / bb)
        if code is not None:
            streets[s]["acts"].append({"code": code, "kind": kind, "hero": a.player == player_id})
        streets[s]["pot"] = round(pot / bb, 1)
    net = (float(p.collected or 0) + float(p.returned or 0) - float(p.invested or 0)) / bb if p else 0.0
    return {"cards": (p.cards if p else []) or [], "pos": (p.position if p else None),
            "result_bb": round(net, 1), "streets": streets}
