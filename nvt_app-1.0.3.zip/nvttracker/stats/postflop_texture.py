"""Pós-flop por TEXTURA do board: frequência de uma ação (ex.: c-bet no flop) separada por
tipo de flop (Rainbow / Two-tone / Monotone / Pareado). PURO (recebe mãos parseadas)."""
from __future__ import annotations

from ..models import Hand
from .definitions import Outcome
from .engine import evaluate_hand

TEXTURES = ["Rainbow", "Two-tone", "Monotone", "Pareado"]


def flop_texture(board: list[str]) -> str | None:
    """Classifica o flop (3 primeiras cartas). None se não há flop."""
    flop = (board or [])[:3]
    if len(flop) < 3 or any(len(c) < 2 for c in flop):
        return None
    ranks = [c[0] for c in flop]
    suits = [c[1] for c in flop]
    if len(set(ranks)) < 3:
        return "Pareado"
    s = len(set(suits))
    if s == 1:
        return "Monotone"
    if s == 2:
        return "Two-tone"
    return "Rainbow"


def texture_report(hands: list[Hand], player_id: str, stat: str = "cbet_flop") -> dict[str, list[int]]:
    """{textura: [oportunidades, casos]} para uma stat pós-flop, só nas mãos que viram flop."""
    agg: dict[str, list[int]] = {}
    for h in hands:
        p = next((pl for pl in h.players if pl.name == player_id), None)
        if p is None:
            continue
        tex = flop_texture(h.board or [])
        if tex is None:
            continue
        for who, s, outcome in evaluate_hand(h):
            if who == player_id and s == stat and outcome != Outcome.NONE:
                a = agg.setdefault(tex, [0, 0])
                a[0] += 1
                if outcome == Outcome.CASE:
                    a[1] += 1
                break
    return agg
