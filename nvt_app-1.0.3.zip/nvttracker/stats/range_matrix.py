"""Matriz de ranges 13×13: por mão inicial (AA..22, suited/offsuit), a frequência com que o
jogador faz uma ação (VPIP/PFR/3-bet…). PURO (recebe mãos parseadas + o motor de stats)."""
from __future__ import annotations

from ..models import Hand
from .definitions import Outcome
from .engine import evaluate_hand

_ORDER = "AKQJT98765432"


def combo_label(cards: list[str]) -> str | None:
    """['Ah','Kd'] -> 'AKo' · ['Ah','Ks'](naipe igual? não) · ['Ah','As']->'AA' · suited='AKs'."""
    if not cards or len(cards) != 2 or len(cards[0]) < 2 or len(cards[1]) < 2:
        return None
    r1, s1 = cards[0][0].upper(), cards[0][1].lower()
    r2, s2 = cards[1][0].upper(), cards[1][1].lower()
    if r1 not in _ORDER or r2 not in _ORDER:
        return None
    if _ORDER.index(r1) <= _ORDER.index(r2):
        hi, lo, shi, slo = r1, r2, s1, s2
    else:
        hi, lo, shi, slo = r2, r1, s2, s1
    if hi == lo:
        return hi + lo
    return hi + lo + ("s" if shi == slo else "o")


def range_matrix(hands: list[Hand], player_id: str, stat: str) -> dict[str, list[int]]:
    """{combo: [oportunidades, casos]} para uma stat (ex.: 'pfr'). Só conta mãos onde o jogador
    teve a oportunidade da ação E cujas cartas são conhecidas."""
    grid: dict[str, list[int]] = {}
    for h in hands:
        p = next((pl for pl in h.players if pl.name == player_id), None)
        if p is None:
            continue
        combo = combo_label(p.cards or [])
        if combo is None:
            continue
        for who, s, outcome in evaluate_hand(h):
            if who == player_id and s == stat and outcome != Outcome.NONE:
                g = grid.setdefault(combo, [0, 0])
                g[0] += 1
                if outcome == Outcome.CASE:
                    g[1] += 1
                break
    return grid


def all_combos() -> list[str]:
    """Os 169 rótulos na ordem da grade (linha i, coluna j de A..2)."""
    out = []
    for i, ri in enumerate(_ORDER):
        for j, rj in enumerate(_ORDER):
            if i == j:
                out.append(ri + ri)
            elif i < j:
                out.append(ri + rj + "s")
            else:
                out.append(rj + ri + "o")
    return out
