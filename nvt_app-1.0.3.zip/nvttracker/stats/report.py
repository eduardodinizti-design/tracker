"""Relatório consolidado por jogador e validação contra uma amostra de referência (tolerância de 0,5 p.p.)."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import psycopg

from .definitions import STATS
from .engine import Accumulator
from .store import load_hands

TOLERANCE_PP = 0.5
STAT_ORDER = list(STATS)


def player_report(conn: psycopg.Connection, *, room: str | None = None, fmt: str | None = None,
                  player_id: str | None = None, min_vpip_sample: int = 0, members_only: bool = False) -> list[dict]:
    """Uma linha por (sala, jogador, formato) com valor e amostra de cada stat."""
    sql = """
        SELECT a.room, a.player_id, a.format, a.stat_id, a.opps, a.cases, l.member_id
        FROM stat_acc a LEFT JOIN player_links l ON l.room = a.room AND l.player_id = a.player_id
        WHERE (%(room)s::text IS NULL OR a.room = %(room)s) AND (%(fmt)s::text IS NULL OR a.format = %(fmt)s)
          AND (%(pid)s::text IS NULL OR a.player_id = %(pid)s) AND (NOT %(members)s OR l.member_id IS NOT NULL)
        ORDER BY a.room, a.player_id, a.format"""
    rows: dict[tuple, dict] = {}
    for room_, pid, fmt_, stat, opps, cases, member in conn.execute(
            sql, {"room": room, "fmt": fmt, "pid": player_id, "members": members_only}):
        r = rows.setdefault((room_, pid, fmt_), {"room": room_, "player_id": pid, "format": fmt_, "member": member})
        r[stat] = round(100.0 * cases / opps, 1) if opps else None
        r[f"{stat}_n"] = opps
    return [r for r in rows.values() if r.get("vpip_n", 0) >= min_vpip_sample]


def write_csv(rows: list[dict], path: str | Path) -> None:
    cols = ["room", "player_id", "member", "format"] + [c for s in STAT_ORDER for c in (s, f"{s}_n")]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore", delimiter=";")
        w.writeheader()
        w.writerows(rows)


# ------------------------------------------------------------------ validação contra a referência

@dataclass
class Comparison:
    room: str
    player_id: str
    format: str
    stat_id: str
    ref_value: float
    ref_sample: int | None
    nvt_value: float | None
    nvt_sample: int

    @property
    def diff_pp(self) -> float | None:
        return None if self.nvt_value is None else round(self.nvt_value - self.ref_value, 2)

    @property
    def ok(self) -> bool:
        return self.diff_pp is not None and abs(self.diff_pp) <= TOLERANCE_PP


REFERENCE_HEADER = ["room", "player_id", "format", "stat_id", "ref_value", "ref_sample"]


def write_reference_template(conn: psycopg.Connection, path: str | Path, *, top: int = 5,
                             min_sample: int = 500) -> int:
    """Gera a planilha para preencher com os números de referência: os ``top`` jogadores com mais mãos por formato."""
    rows = conn.execute("""
        SELECT room, player_id, format FROM (
            SELECT room, player_id, format, opps,
                   row_number() OVER (PARTITION BY format ORDER BY opps DESC) AS rk
            FROM stat_acc WHERE stat_id = 'vpip' AND opps >= %s) t
        WHERE rk <= %s ORDER BY format, rk""", (min_sample, top)).fetchall()
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(REFERENCE_HEADER)
        for room, pid, fmt in rows:
            for stat in STAT_ORDER:
                w.writerow([room, pid, fmt, stat, "", ""])
    return len(rows)


def window_stats(conn: psycopg.Connection, room: str, player_id: str, fmt: str, start: datetime,
                 end: datetime) -> dict[str, tuple[int, int]]:
    """{stat: (opps, cases)} do jogador só nas mãos com início em [start, end), calculado direto das mãos.

    Serve para comparar com a referência quando ela está filtrada por período (ex.: "This Month"), já que
    ``stat_acc`` guarda o total acumulado.
    """
    pks = [r[0] for r in conn.execute("""
        SELECT h.hand_pk FROM hands h JOIN hand_players p USING (hand_pk)
        WHERE h.room = %s AND p.player_id = %s AND h.format = %s AND h.started_utc >= %s AND h.started_utc < %s""",
        (room, player_id, fmt, start, end))]
    acc = Accumulator().add_all(load_hands(conn, pks))
    return {stat: tuple(oc) for (r, pid, f, stat), oc in acc.counts.items() if pid == player_id}


def compare_with_reference(conn: psycopg.Connection, reference_csv: str | Path, *, start: datetime | None = None,
                     end: datetime | None = None) -> list[Comparison]:
    """Lê a planilha preenchida (valores de referência em %, vírgula ou ponto) e compara com o NvtTracker:
    ``stat_acc`` (total) ou, com ``start``/``end``, só as mãos do período."""
    out = []
    windows: dict[tuple, dict] = {}
    with open(reference_csv, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=";"):
            if not (r.get("ref_value") or "").strip():
                continue
            if start is not None and end is not None:
                key = (r["room"], r["player_id"], r["format"])
                if key not in windows:
                    windows[key] = window_stats(conn, *key, start, end)
                opps, cases = windows[key].get(r["stat_id"], (0, 0))
            else:
                opps, cases = conn.execute(
                    "SELECT opps, cases FROM stat_acc WHERE room=%s AND player_id=%s AND format=%s AND stat_id=%s",
                    (r["room"], r["player_id"], r["format"], r["stat_id"])).fetchone() or (0, 0)
            sample = (r.get("ref_sample") or "").strip()
            out.append(Comparison(r["room"], r["player_id"], r["format"], r["stat_id"],
                                  float(r["ref_value"].replace(",", ".")), int(sample) if sample else None,
                                  100.0 * cases / opps if opps else None, opps))
    return out
