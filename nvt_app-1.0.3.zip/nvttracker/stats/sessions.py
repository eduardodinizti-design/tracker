"""Sessões (aba 'Sessions' do H2N): agrupa as mãos do jogador em sessões por intervalo de
tempo e resume cada uma (mãos, ganho, EV, duração, VPIP/PFR). PURO (recebe mãos parseadas)."""
from __future__ import annotations

from ..models import Hand
from .definitions import Outcome
from .engine import evaluate_hand
from .ev import hand_ev


def split_sessions(hands: list[Hand], gap_minutes: int = 30) -> list[list[Hand]]:
    """Quebra as mãos (ordenadas por tempo) em sessões: nova sessão quando o intervalo entre
    uma mão e a anterior passa de `gap_minutes`."""
    out: list[list[Hand]] = []
    cur: list[Hand] = []
    for h in sorted(hands, key=lambda x: x.started_utc):
        if cur and (h.started_utc - cur[-1].started_utc).total_seconds() > gap_minutes * 60:
            out.append(cur)
            cur = []
        cur.append(h)
    if cur:
        out.append(cur)
    return out


def session_rows(hands: list[Hand], player_id: str, gap_minutes: int = 30,
                 with_ev: bool = True) -> list[dict]:
    """Uma linha por sessão (mais recente primeiro): {inicio, fim, duracao_min, maos, won_bb,
    ev_bb, bb100, ev_bb100, vpip, pfr}."""
    rows: list[dict] = []
    for sess in split_sessions(hands, gap_minutes):
        n = won = ev = 0.0
        opp = {"vpip": [0, 0], "pfr": [0, 0]}
        first = sess[0].started_utc
        last = sess[-1].started_utc
        for h in sess:
            p = next((pl for pl in h.players if pl.name == player_id), None)
            if p is None:
                continue
            bb = float(h.bb or 0) or 1.0
            net = (float(p.collected or 0) + float(p.returned or 0) - float(p.invested or 0)) / bb
            won += net
            ev += (hand_ev(h).get(player_id, net * bb) / bb) if with_ev else net
            n += 1
            for who, stat, out in evaluate_hand(h):
                if who == player_id and stat in opp and out != Outcome.NONE:
                    opp[stat][0] += 1
                    if out == Outcome.CASE:
                        opp[stat][1] += 1
        if not n:
            continue
        dur = (last - first).total_seconds() / 60.0
        rows.append({
            "inicio": first, "fim": last, "duracao_min": round(dur, 1), "maos": int(n),
            "won_bb": round(won, 1), "ev_bb": round(ev, 1),
            "bb100": round(100.0 * won / n, 1), "ev_bb100": round(100.0 * ev / n, 1),
            "vpip": round(100.0 * opp["vpip"][1] / opp["vpip"][0], 1) if opp["vpip"][0] else None,
            "pfr": round(100.0 * opp["pfr"][1] / opp["pfr"][0], 1) if opp["pfr"][0] else None,
        })
    rows.reverse()      # mais recente primeiro
    return rows
