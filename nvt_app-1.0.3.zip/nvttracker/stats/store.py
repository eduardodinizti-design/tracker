"""Agregação no banco: lê mãos pendentes, avalia as regras e soma em ``stat_acc`` (RF10, RF11)."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal

import psycopg

from ..models import Action, ActionType, GameFormat, Hand, Player, Street
from .definitions import RULES_VERSION
from .engine import Accumulator

CHUNK = 2000


@dataclass
class ComputeReport:
    hands: int = 0
    keys_updated: int = 0
    recomputed: bool = False
    blocked: bool = False   # regras mudaram e este usuário (jogador) não pode recalcular: aguarda o admin


def load_hands(conn: psycopg.Connection, hand_pks: list[int]) -> list[Hand]:
    """Reconstrói ``Hand`` a partir das tabelas relacionais (só os campos que as regras usam)."""
    if not hand_pks:
        return []
    hands: dict[int, Hand] = {}
    for pk, room, no, fmt, started, sb, bb, ante, board in conn.execute(
            "SELECT hand_pk, room, hand_no, format, started_utc, sb, bb, ante, board FROM hands "
            "WHERE hand_pk = ANY(%s)", (hand_pks,)):
        hands[pk] = Hand(room=room, hand_no=no, format=GameFormat(fmt), game="NLHE", started_utc=started,
                         sb=sb, bb=bb, ante=ante, board=list(board or []))
    seat_names: dict[int, dict[int, str]] = defaultdict(dict)
    for pk, seat, pid, pos, stack, out, went_sd, won_sd, collected in conn.execute(
            "SELECT hand_pk, seat, player_id, position, stack_start, sitting_out, went_sd, won_sd, collected "
            "FROM hand_players WHERE hand_pk = ANY(%s) ORDER BY hand_pk, seat", (hand_pks,)):
        hands[pk].players.append(Player(seat=seat, name=pid, stack=stack, sitting_out=out, position=pos,
                                        went_to_showdown=went_sd, won_at_showdown=won_sd, collected=collected))
        seat_names[pk][seat] = pid
    for pk, seq, street, seat, typ, amt, amt_to, allin in conn.execute(
            "SELECT hand_pk, seq, street, seat, type, amount, amount_to, is_allin FROM actions "
            "WHERE hand_pk = ANY(%s) ORDER BY hand_pk, seq", (hand_pks,)):
        hands[pk].actions.append(Action(seq, Street(street), seat_names[pk][seat], ActionType(typ),
                                        amt or Decimal(0), amt_to, allin))
    return [hands[pk] for pk in hand_pks if pk in hands]


def _flush(conn: psycopg.Connection, acc: Accumulator) -> int:
    rows = [(room, pid, fmt, stat, oc[0], oc[1]) for (room, pid, fmt, stat), oc in acc.counts.items()]
    with conn.cursor() as cur:
        cur.executemany("""
            INSERT INTO stat_acc (room, player_id, format, stat_id, opps, cases) VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (room, player_id, format, stat_id) DO UPDATE
                SET opps = stat_acc.opps + EXCLUDED.opps, cases = stat_acc.cases + EXCLUDED.cases,
                    updated_at = now()""", rows)
    return len(rows)


def _reset_if_rules_changed(conn: psycopg.Connection) -> bool:
    row = conn.execute("SELECT rules_version FROM stats_meta").fetchone()
    if row is not None and row[0] == RULES_VERSION:
        return False
    conn.execute("TRUNCATE stat_acc")
    conn.execute("UPDATE hands SET stats_version = 0 WHERE stats_version <> 0")
    conn.execute("INSERT INTO stats_meta (rules_version) VALUES (%s) "
                 "ON CONFLICT (id) DO UPDATE SET rules_version = EXCLUDED.rules_version, updated_at = now()",
                 (RULES_VERSION,))
    return row is not None


def compute_pending(conn: psycopg.Connection, *, chunk: int = CHUNK) -> ComputeReport:
    """Conta em ``stat_acc`` todas as mãos ainda não contadas.

    Cada lote de ``chunk`` mãos soma os acumuladores e marca as mãos como contadas na mesma transação; assim um
    erro no meio não conta nenhuma mão duas vezes. Se ``RULES_VERSION`` mudou, zera e recalcula tudo.
    """
    rep = ComputeReport()
    try:
        with conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(hashtext('nvttracker_stats'))")
            rep.recomputed = _reset_if_rules_changed(conn)
    except psycopg.errors.InsufficientPrivilege:
        # não somar mãos com regras diferentes das que montaram stat_acc: espera o admin (nvt-admin recompute)
        rep.blocked = True
        return rep
    while True:
        with conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(hashtext('nvttracker_stats'))")
            pks = [r[0] for r in conn.execute(
                "SELECT hand_pk FROM hands WHERE stats_version = 0 ORDER BY hand_pk LIMIT %s FOR UPDATE SKIP LOCKED",
                (chunk,))]
            if not pks:
                return rep
            acc = Accumulator().add_all(load_hands(conn, pks))
            rep.keys_updated += _flush(conn, acc)
            conn.execute("UPDATE hands SET stats_version = %s WHERE hand_pk = ANY(%s)", (RULES_VERSION, pks))
            rep.hands += len(pks)


def recompute_all(conn: psycopg.Connection) -> ComputeReport:
    """Zera ``stat_acc`` e recalcula a partir de todas as mãos gravadas (RF11)."""
    with conn.transaction():
        conn.execute("DELETE FROM stats_meta")
    rep = compute_pending(conn)
    rep.recomputed = True
    return rep
