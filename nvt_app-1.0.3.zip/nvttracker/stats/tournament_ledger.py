"""Ponte captura → ledger de torneios. No fim do torneio, a captura ao vivo (o bot lê
field/rank/ITM/prêmio do lobby) grava o resultado aqui; o controle de torneios então calcula
Lucro = prêmio − investido e ROI. Idempotente: regravar o mesmo torneio atualiza, não duplica."""
from __future__ import annotations

import psycopg


def upsert_result(conn: psycopg.Connection, room: str, tournament_id: str, player_id: str, *,
                  name: str | None = None, field_size: int | None = None, position: int | None = None,
                  prize: float | None = None, my_entries: int | None = None, rebuys: int | None = None,
                  addons: int | None = None, itm: bool | None = None, extra_cost: float | None = None,
                  note: str | None = None, source: str = "capture") -> None:
    """Grava/atualiza o resultado de UM torneio para UM jogador. Campos None são preservados
    (não sobrescrevem o que já existe). ITM é derivado do prêmio quando não informado."""
    if itm is None and prize is not None:
        itm = prize > 0
    conn.execute("""
        INSERT INTO tournament_results
            (room, tournament_id, player_id, name, my_entries, rebuys, addons, field_size,
             position, prize, itm, extra_cost, note, source, updated_at)
        VALUES (%s,%s,%s, %s, COALESCE(%s,1), COALESCE(%s,0), COALESCE(%s,0), %s, %s, %s, %s,
                COALESCE(%s,0), COALESCE(%s,''), %s, now())
        ON CONFLICT (room, tournament_id, player_id) DO UPDATE SET
            name       = COALESCE(EXCLUDED.name, tournament_results.name),
            my_entries = GREATEST(tournament_results.my_entries, EXCLUDED.my_entries),
            rebuys     = GREATEST(tournament_results.rebuys, EXCLUDED.rebuys),
            addons     = GREATEST(tournament_results.addons, EXCLUDED.addons),
            field_size = COALESCE(EXCLUDED.field_size, tournament_results.field_size),
            position   = COALESCE(EXCLUDED.position, tournament_results.position),
            prize      = COALESCE(EXCLUDED.prize, tournament_results.prize),
            itm        = COALESCE(EXCLUDED.itm, tournament_results.itm),
            extra_cost = GREATEST(tournament_results.extra_cost, EXCLUDED.extra_cost),
            note       = CASE WHEN EXCLUDED.note <> '' THEN EXCLUDED.note ELSE tournament_results.note END,
            source     = EXCLUDED.source,
            updated_at = now()
    """, (room, tournament_id, player_id, name, my_entries, rebuys, addons, field_size,
          position, prize, itm, extra_cost, note, source))


def record_from_capture(conn: psycopg.Connection, room: str, tournament_id: str, player_id: str, *,
                        rank: int | None = None, field: int | None = None, prize: float | None = None,
                        name: str | None = None, entries: int = 1, rebuys: int = 0,
                        extra_cost: float | None = None) -> None:
    """Atalho para o bot: o que o leitor de lobby (MttMyRankInfoBRC) entrega no fim do torneio."""
    upsert_result(conn, room, tournament_id, player_id, name=name, field_size=field, position=rank,
                  prize=prize, my_entries=entries, rebuys=rebuys, extra_cost=extra_cost, source="capture")


def get_result(conn: psycopg.Connection, room: str, tournament_id: str, player_id: str) -> dict | None:
    r = conn.execute("""SELECT name, my_entries, rebuys, addons, field_size, position, prize, itm,
                        extra_cost, note, source FROM tournament_results
                        WHERE room=%s AND tournament_id=%s AND player_id=%s""",
                     (room, tournament_id, player_id)).fetchone()
    if not r:
        return None
    k = ["name", "my_entries", "rebuys", "addons", "field_size", "position", "prize", "itm",
         "extra_cost", "note", "source"]
    return dict(zip(k, r))
