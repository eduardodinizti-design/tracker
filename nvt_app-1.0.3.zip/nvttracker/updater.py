"""Auto-update do NVT Tracker. O .exe é fixo; o app vive numa pasta atualizável. Ao abrir,
compara a versão local com um MANIFESTO remoto (JSON) e, se houver versão nova, baixa o PACOTE
(.zip) e extrai sobre o app. Assim cada update é só subir manifesto+zip — nunca um .exe novo.

Manifesto (JSON) esperado em NVT_UPDATE_URL:
    {"version": "1.2.0", "url": "https://.../nvt_app-1.2.0.zip", "notes": "o que mudou"}

Só stdlib (urllib, zipfile) — roda no boot antes de carregar o app."""
from __future__ import annotations

import io
import json
import os
import urllib.request
import zipfile
from pathlib import Path


def parse_version(s: str) -> tuple:
    out = []
    for part in str(s or "0").split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out) or (0,)


def is_newer(remote: str, local: str) -> bool:
    return parse_version(remote) > parse_version(local)


def read_local_version(app_dir: Path, fallback: str = "0.0.0") -> str:
    vf = Path(app_dir) / "VERSION"
    try:
        return vf.read_text(encoding="utf-8").strip() or fallback
    except Exception:
        return fallback


def check_manifest(url: str, timeout: float = 5.0) -> dict | None:
    """Baixa o manifesto remoto. None se indisponível (offline, URL errada etc.)."""
    if not url:
        return None
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        if isinstance(data, dict) and data.get("version"):
            return data
    except Exception:
        return None
    return None


def download_and_extract(bundle_url: str, app_dir: Path, version: str, timeout: float = 60.0) -> bool:
    """Baixa o .zip do pacote e extrai sobre app_dir. Grava VERSION ao final (marca de sucesso)."""
    app_dir = Path(app_dir)
    try:
        with urllib.request.urlopen(bundle_url, timeout=timeout) as r:
            blob = r.read()
        app_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            _safe_extract(z, app_dir)
        (app_dir / "VERSION").write_text(version, encoding="utf-8")
        return True
    except Exception:
        return False


def seed_from_zip(seed_zip: Path, app_dir: Path, version: str) -> bool:
    """Extrai um .zip LOCAL (o seed embarcado no .exe) para o app_dir."""
    try:
        app_dir = Path(app_dir)
        app_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(seed_zip) as z:
            _safe_extract(z, app_dir)
        (app_dir / "VERSION").write_text(version, encoding="utf-8")
        return True
    except Exception:
        return False


def _safe_extract(z: zipfile.ZipFile, dest: Path) -> None:
    """Extrai impedindo path traversal (zip slip)."""
    dest = dest.resolve()
    for member in z.namelist():
        target = (dest / member).resolve()
        if not str(target).startswith(str(dest)):
            raise ValueError(f"caminho inseguro no zip: {member}")
    z.extractall(dest)


def check_update(app_dir: Path, manifest_url: str | None = None) -> dict | None:
    """Há update? Devolve {version, url, notes} do manifesto se for mais novo que o local; senão None."""
    url = manifest_url or os.environ.get("NVT_UPDATE_URL")
    man = check_manifest(url)
    if not man:
        return None
    if is_newer(man["version"], read_local_version(app_dir)):
        return man
    return None
