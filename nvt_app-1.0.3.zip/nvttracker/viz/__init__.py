"""NvtDashboard: painel Streamlit sobre stat_acc (``streamlit run nvttracker/viz/app.py``)."""
