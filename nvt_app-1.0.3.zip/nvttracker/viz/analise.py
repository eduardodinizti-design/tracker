"""NvtTracker — PAINEL DE ANÁLISE OFFLINE (estilo H2N). Estuda um jogador: resumo das stats,
**stats e bb/100 POR POSIÇÃO**, e as mãos jogadas (replay em texto da sessão).

    streamlit run nvttracker/viz/analise.py        (lê NVT_DATABASE_URL)
    nvt-analise

É só LEITURA do banco. Complementa o dashboard ao vivo (app.py) com a parte de estudo.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from nvttracker.db import connect, migrate  # noqa: E402
from nvttracker.parser.nlhe_text import parse_hand  # noqa: E402
from nvttracker.stats.definitions import STATS  # noqa: E402
from nvttracker.viz import data  # noqa: E402
from nvttracker.viz.replay import replay_states, svg_table  # noqa: E402

st.set_page_config(page_title="NVT Tracker", page_icon="♠", layout="wide",
                   initial_sidebar_state="expanded")

# ---- visual "pro" estilo Hand2Note: esconde o chrome do Streamlit, barra verde no topo,
#      nav lateral escura, stats e abas com a cara do H2N ----
_H2N_CSS = """
<style>
  [data-testid="stHeader"], #MainMenu, footer {display:none !important;}
  [data-testid="stAppViewContainer"] {background:#0d1117;}
  .block-container {padding-top:4.2rem !important; max-width:100% !important;}
  /* barra verde fixa no topo */
  .nvt-topbar {position:fixed; top:0; left:0; right:0; height:46px; z-index:999990;
      background:linear-gradient(90deg,#15351f 0%,#1a7a3a 45%,#124a25 100%);
      border-bottom:1px solid #0b3d20; display:flex; align-items:center; padding:0 18px;
      box-shadow:0 2px 14px #0007; font-family:Arial,Helvetica,sans-serif;}
  .nvt-topbar .brand {font-weight:900; font-size:17px; letter-spacing:-.5px; color:#f7f6f2;}
  .nvt-topbar .brand span {color:#ffb511; font-style:italic;}
  .nvt-topbar .sub {margin-left:14px; font-size:10px; letter-spacing:.34em; color:#cfe8d6;}
  .nvt-topbar .right {margin-left:auto; font:11px monospace; color:#cfe8d6; opacity:.85;}
  /* nav lateral escura */
  [data-testid="stSidebar"] {background:#0b0e13; border-right:1px solid #1f2630;}
  [data-testid="stSidebar"] * {color:#c9d1d9;}
  /* stats (metric) como as células do H2N: número grande colorido, rótulo cinza */
  [data-testid="stMetric"] {background:#11161d; border:1px solid #1f2630; border-radius:8px;
      padding:8px 12px;}
  [data-testid="stMetricValue"] {font-size:1.7rem !important; font-weight:800 !important;}
  [data-testid="stMetricLabel"] p {color:#8b93a3 !important; font-size:.72rem !important;
      text-transform:uppercase; letter-spacing:.04em;}
  /* abas no estilo H2N */
  [data-testid="stTabs"] [data-baseweb="tab-list"] {gap:6px; border-bottom:1px solid #1f2630;}
  [data-testid="stTabs"] [data-baseweb="tab"] {color:#8b93a3; font-weight:600;}
  [data-testid="stTabs"] [aria-selected="true"] {color:#3fb950 !important;}
  [data-testid="stTabs"] [data-baseweb="tab-highlight"] {background:#3fb950 !important;}
  h1,h2,h3 {color:#e6edf3; font-family:Arial,Helvetica,sans-serif;}
</style>
"""
st.markdown(_H2N_CSS, unsafe_allow_html=True)

_dsn = os.environ.get("NVT_DATABASE_URL")
if not _dsn:
    st.error("Banco não configurado: defina NVT_DATABASE_URL (ou use o nvt_config.ini).")
    st.stop()


@st.cache_resource
def _conn():
    c = connect(_dsn)
    migrate(c)
    return c


conn = _conn()

# ----- barra lateral: formato, sala, jogador -----
with st.sidebar:
    st.header("Filtro")
    fmt = st.radio("Formato", ["tournament", "cash"], format_func=lambda x: "Torneio" if x == "tournament" else "Cash")
    rooms = [r[0] for r in conn.execute("SELECT DISTINCT room FROM hands ORDER BY 1")]
    room = st.selectbox("Sala", rooms or ["PPPoker"])
    top = conn.execute("""
        SELECT a.player_id, a.cases AS maos FROM stat_acc a
        WHERE a.room=%s AND a.format=%s AND a.stat_id='vpip' ORDER BY a.cases DESC LIMIT 300""",
        (room, fmt)).fetchall()
    opts = [f"{p}  ({n} mãos)" for p, n in top]
    pick = st.selectbox("Jogador", opts) if opts else None
    busca = st.text_input("…ou ID do jogador")
    player = busca.strip() if busca.strip() else (pick.split("  (")[0] if pick else None)

if not player:
    st.info("Escolha um jogador na barra lateral para estudar.")
    st.stop()

_fmt_lbl = "Torneio" if fmt == "tournament" else "Cash"
st.markdown(
    f'<div class="nvt-topbar"><span class="brand">NVT <span>TRACKER</span></span>'
    f'<span class="sub">INTELIGÊNCIA EM CADA MÃO</span>'
    f'<span class="right">👤 {player}&nbsp;·&nbsp;{room}&nbsp;·&nbsp;{_fmt_lbl}</span></div>',
    unsafe_allow_html=True)

# ----- resumo (stats gerais) -----
detail = data.player_detail(conn, room, player, fmt)
hands_total = detail["vpip"].opps if "vpip" in detail else 0
cols = st.columns(6)
for i, s in enumerate(["vpip", "pfr", "three_bet", "fold_to_3bet", "steal", "cbet_flop"]):
    v = detail[s].pct if s in detail else None
    cols[i].metric(data.LABELS[s], "–" if v is None else f"{v:.1f}%")
st.caption(f"{hands_total} mãos (oportunidades de VPIP) no total.")

tab_g, tab_p, tab_s, tab_sess, tab_m, tab_mk = st.tabs(
    ["📈 Ganhos", "📊 Por posição", "🎯 Estatísticas", "⏱ Sessões", "🂠 Mãos (replay)", "★ Marcadas"])


def _bbcolor(col):
    return ["color:#51cf66" if isinstance(v, (int, float)) and v > 0 else
            "color:#ff6b6b" if isinstance(v, (int, float)) and v < 0 else "" for v in col]


# ===== GANHOS (gráfico Won / All-in EV / showdown) =====
with tab_g:
    wdf = data.winnings(conn, room, player, fmt)
    if wdf.empty:
        st.info("Sem mãos para o gráfico.")
    else:
        st.line_chart(wdf, height=420)
        last = wdf.iloc[-1]
        c = st.columns(4)
        c[0].metric("Won (real)", f"{last['Won (real)']:+.0f} bb")
        c[1].metric("All-in EV", f"{last['All-in EV']:+.0f} bb")
        c[2].metric("Ganho no showdown", f"{last['Ganho no showdown']:+.0f} bb")
        c[3].metric("Ganho sem showdown", f"{last['Ganho sem showdown']:+.0f} bb")
        st.caption("**Won** = resultado real · **All-in EV** = sem a variância do runout (quando EV > Won, "
                   "você correu abaixo da sorte) · as linhas de showdown separam de onde veio o lucro.")

# ===== POR POSIÇÃO =====
with tab_p:
    bypos = data.by_position(conn, room, player, fmt)
    if bypos.empty:
        st.info("Sem mãos com posição para este jogador.")
    else:
        show_cols = ["Posição", "Mãos", "bb/100", "EV bb/100"] + [data.LABELS[s] for s in STATS]
        sty = bypos[show_cols].style.format(
            {"bb/100": "{:+.1f}", "EV bb/100": "{:+.1f}", **{data.LABELS[s]: "{:.0f}" for s in STATS}}, na_rep="–")
        sty = sty.apply(_bbcolor, subset=["bb/100", "EV bb/100"])
        st.dataframe(sty, use_container_width=True, hide_index=True)
        st.caption("bb/100 = ganho real por 100 mãos. **EV bb/100** = ajustado por equity nos all-ins. "
                   "Verde = lucro, vermelho = prejuízo.")

# ===== ESTATÍSTICAS (painel agrupado) =====
with tab_s:
    GROUPS = [
        ("Pré-flop", ["vpip", "pfr", "three_bet", "four_bet", "squeeze"]),
        ("Defesa", ["fold_to_3bet", "fold_to_4bet", "fold_to_cbet", "fold_to_steal"]),
        ("Roubo / Blinds", ["steal"]),
        ("Pós-flop", ["cbet_flop", "cbet_turn", "check_raise", "wwsf"]),
        ("Showdown", ["wtsd", "wsd"]),
    ]
    for title, keys in GROUPS:
        st.markdown(f"**{title}**")
        cols = st.columns(len(keys))
        for i, k in enumerate(keys):
            sl = detail.get(k)
            v = sl.pct if sl else None
            cols[i].metric(data.LABELS[k], "–" if v is None else f"{v:.0f}%",
                           help=f"{sl.opps} oportunidades" if sl else None)
    st.caption("Cada stat: % (passe o mouse p/ ver o nº de oportunidades). Painel estilo 'Statistics' do H2N — "
               "mais subdivisões (IP/OOP, por rua, SB×BB) entram nas próximas levas.")

# ===== SESSÕES =====
with tab_sess:
    sdf = data.sessions(conn, room, player, fmt)
    if sdf.empty:
        st.info("Sem sessões para este jogador.")
    else:
        ss = sdf.style.format({"Won (bb)": "{:+.1f}", "EV (bb)": "{:+.1f}", "bb/100": "{:+.1f}",
                               "EV bb/100": "{:+.1f}", "VPIP": "{:.0f}", "PFR": "{:.0f}"}, na_rep="–")
        ss = ss.apply(_bbcolor, subset=["Won (bb)", "EV (bb)", "bb/100", "EV bb/100"])
        st.dataframe(ss, use_container_width=True, hide_index=True)
        st.caption("Uma linha por sessão (corte quando há >30 min sem jogar). Won/EV em bb, winrate e VPIP/PFR da sessão.")

# ===== MÃOS (replay visual) =====
with tab_m:
    rows = conn.execute("""
        SELECT h.hand_pk, h.started_utc, h.hand_no, h.table_id, h.pot, h.bb,
               array_to_string(h.board, ' '), hp.position, hp.net_bb
        FROM hands h JOIN hand_players hp USING (hand_pk)
        WHERE hp.player_id = %s AND h.room = %s AND h.format = %s
        ORDER BY h.started_utc DESC LIMIT 300""", (player, room, fmt)).fetchall()
    if not rows:
        st.info("Nenhuma mão encontrada para este jogador.")
    else:
        maos = pd.DataFrame(rows, columns=["pk", "Início", "Mão #", "Mesa", "pot", "bb", "Board", "Pos", "net_bb"])
        maos["Pote(bb)"] = (maos["pot"].astype(float) / maos["bb"].astype(float)).round(1)
        maos["Ganho(bb)"] = maos["net_bb"].astype(float).round(1)
        maos["Início"] = data._local(maos["Início"])
        col1, col2 = st.columns([1, 2])
        with col1:
            st.dataframe(maos[["Início", "Pos", "Mesa", "Pote(bb)", "Ganho(bb)", "Board"]],
                         use_container_width=True, hide_index=True, height=520)
            pk_sel = st.selectbox("Abrir mão (replay)", maos["pk"].tolist(),
                                  format_func=lambda pk: f"#{maos.loc[maos.pk == pk, 'Mão #'].iloc[0]}")
        with col2:
            raw = data.hand_text(conn, int(pk_sel)) or ""
            states = []
            if raw:
                try:
                    states = replay_states(parse_hand(raw, check_chips=False))
                except Exception as e:  # noqa: BLE001
                    st.warning(f"Não deu p/ montar o replay visual: {e}")
            if states:
                i = st.slider("Passo do replay", 0, len(states) - 1, len(states) - 1)
                s = states[i]
                st.caption(f"**{s['label']}**  ·  rua: {s['street']}  ·  pote: {s['pot']:g}")
                components.html(f'<div style="background:#0d1117">{svg_table(s)}</div>', height=460)
            # ----- marcar esta mão (tags + nota) -----
            mk = data.hand_mark(conn, int(pk_sel))
            with st.form(f"mark_{pk_sel}"):
                st.markdown("**⭐ Marcar para estudo**" + ("  ·  _marcada_" if mk else ""))
                tags_in = st.text_input("Tags (separe por vírgula)", value=", ".join(mk[0]) if mk else "")
                note_in = st.text_input("Nota", value=mk[1] if mk else "")
                b1, b2 = st.columns(2)
                if b1.form_submit_button("✏️ Atualizar" if mk else "⭐ Marcar"):
                    data.mark_hand(conn, int(pk_sel),
                                   [t.strip() for t in tags_in.split(",") if t.strip()], note_in)
                    st.rerun()
                if mk and b2.form_submit_button("✖ Desmarcar"):
                    data.unmark_hand(conn, int(pk_sel))
                    st.rerun()
            with st.expander("Texto da mão (HH)"):
                st.code(raw or "(sem texto)", language="text")

# ===== MARCADAS =====
with tab_mk:
    mdf = data.marked_hands(conn, room, player, fmt)
    if mdf.empty:
        st.info("Nenhuma mão marcada ainda. Marque mãos na aba '🂠 Mãos (replay)'.")
    else:
        cL, cR = st.columns([1, 2])
        with cL:
            st.dataframe(mdf[["Marcada", "Tags", "Mesa", "Ganho(bb)", "Board", "Nota"]],
                         use_container_width=True, hide_index=True, height=520)
            mk_sel = st.selectbox("Abrir marcada", mdf["pk"].tolist(),
                                  format_func=lambda pk: f"#{mdf.loc[mdf.pk == pk, 'Mão #'].iloc[0]}")
        with cR:
            raw = data.hand_text(conn, int(mk_sel)) or ""
            states = []
            if raw:
                try:
                    states = replay_states(parse_hand(raw, check_chips=False))
                except Exception as e:  # noqa: BLE001
                    st.warning(f"replay: {e}")
            if states:
                i = st.slider("Passo", 0, len(states) - 1, len(states) - 1, key="mk_step")
                s = states[i]
                st.caption(f"**{s['label']}**  ·  rua: {s['street']}  ·  pote: {s['pot']:g}")
                components.html(f'<div style="background:#0d1117">{svg_table(s)}</div>', height=460)
            if st.button("✖ Desmarcar esta mão"):
                data.unmark_hand(conn, int(mk_sel))
                st.rerun()
