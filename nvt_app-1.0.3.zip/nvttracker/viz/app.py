"""NvtTracker — interface (Streamlit). Páginas: Ao vivo · Jogadores · Mãos · Time · Status.

    streamlit run nvttracker/viz/app.py          (ou pelo NvtTracker.exe, que abre numa janela própria)

Lê NVT_DATABASE_URL. Quando roda dentro do NvtTracker.exe, mostra também o status da captura e da exportação
(``nvttracker.runtime``), que rodam no mesmo processo.
"""
from __future__ import annotations

import html
import os
import sys
from pathlib import Path

import psycopg
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # permite rodar sem "pip install -e ."

from nvttracker.db import migrate  # noqa: E402
from nvttracker.runtime import RUNTIME  # noqa: E402
from nvttracker.viz import data  # noqa: E402

st.set_page_config(page_title="NvtTracker", page_icon="♠", layout="wide")
st.markdown("""<style>
  .block-container {padding-top: 1.2rem; padding-bottom: 1rem;}
  .nvt-card {font-size: 1.35rem; letter-spacing: .05em; font-family: Consolas, monospace}
  .nvt-h {color:#ff6b6b} .nvt-d {color:#4dabf7} .nvt-c {color:#51cf66} .nvt-s {color:inherit}
  .nvt-pill {display:inline-block; padding:2px 10px; border-radius:12px; font-size:.85rem; margin-right:6px}
  .nvt-ok {background:rgba(46,160,67,.25)} .nvt-warn {background:rgba(210,153,34,.3)}
  .nvt-err {background:rgba(218,54,51,.3)} .nvt-off {background:rgba(128,128,128,.25)}
</style>""", unsafe_allow_html=True)


# ------------------------------------------------------------------ conexão

@st.cache_resource(show_spinner=False)
def get_conn(dsn: str) -> psycopg.Connection:
    conn = psycopg.connect(dsn, autocommit=True, application_name="nvt-dashboard")
    migrate(conn)
    return conn


def conn_or_stop(dsn: str) -> psycopg.Connection:
    try:
        conn = get_conn(dsn)
        conn.execute("SELECT 1")
        return conn
    except psycopg.Error:
        get_conn.clear()
        try:
            return get_conn(dsn)
        except psycopg.Error as e:
            st.error(f"Não foi possível conectar ao banco: {e}")
            st.stop()


dsn = os.environ.get("NVT_DATABASE_URL")
if not dsn:
    st.error("Banco não configurado: preencha database_url no nvt_config.ini.")
    st.stop()
conn = conn_or_stop(dsn)

# ------------------------------------------------------------------ barra lateral (filtros globais)

LOGO = Path(__file__).resolve().parent / "assets" / "nvt_logo.png"   # logotipo do NVT Poker Team

with st.sidebar:
    if LOGO.exists():
        st.columns([1, 2, 1])[1].image(str(LOGO), width="stretch")
    st.markdown("### ♠ NvtTracker")
    if RUNTIME.member:
        st.caption(f"Membro: **{RUNTIME.member}**")
    fmt_label = st.radio("Formato", ["Torneio", "Cash"], horizontal=True, key="fmt")
    fmt = "tournament" if fmt_label == "Torneio" else "cash"
    refresh = st.select_slider("Atualizar a cada", options=[3, 5, 10, 30], value=5, format_func=lambda s: f"{s} s")
    st.divider()
    st.caption("**Cores**  \nVPIP: verde < 18 · vermelho > 28  \nPFR: verde > 22 · vermelho < 14  \n"
               "3Bet: roxo > 10 · amarelo < 5")


# ------------------------------------------------------------------ componentes

def cards_html(cards: str) -> str:
    """'Ah Kd 7c' -> cartas coloridas por naipe."""
    out = []
    for c in (cards or "").split():
        suit = c[-1:].lower()
        out.append(f"<span class='nvt-{suit if suit in 'hdcs' else 's'}'>{html.escape(c[:-1])}"
                   f"{ {'h': '♥', 'd': '♦', 'c': '♣', 's': '♠'}.get(suit, '') }</span>")
    return "<span class='nvt-card'>" + " ".join(out) + "</span>" if out else "–"


def status_bar() -> None:
    w = RUNTIME.watcher_state
    if not RUNTIME.member:
        return
    cls = {"ativo": "nvt-ok", "iniciando": "nvt-warn", "duplicado": "nvt-warn", "erro": "nvt-err"}.get(w, "nvt-off")
    label = {"ativo": "Captura ativa", "iniciando": "Iniciando captura…", "duplicado": "Captura em outro lugar",
             "erro": "Captura com erro", "parado": "Captura parada"}.get(w, w)
    pills = [f"<span class='nvt-pill {cls}'>● {label}</span>",
             f"<span class='nvt-pill nvt-off'>{RUNTIME.session_hands} mão(s) nesta sessão</span>"]
    if RUNTIME.last_hand_at:
        pills.append(f"<span class='nvt-pill nvt-off'>última às {RUNTIME.last_hand_at:%H:%M:%S}</span>")
    if RUNTIME.export_enabled:
        ecls = "nvt-err" if RUNTIME.export_state == "erro" else "nvt-ok"
        pills.append(f"<span class='nvt-pill {ecls}'>Exportação do time: {RUNTIME.export_total} mão(s)</span>")
    st.markdown(" ".join(pills), unsafe_allow_html=True)
    if w in ("erro", "duplicado") and RUNTIME.watcher_detail:
        st.warning(RUNTIME.watcher_detail)


def player_detail(room: str, player: str) -> None:
    detail = data.player_detail(conn, room, player, fmt)
    member = conn.execute("SELECT member_id FROM player_links WHERE room=%s AND player_id=%s",
                          (room, player)).fetchone()
    st.markdown(f"#### {room} · {player}" + (f" · time: {member[0]}" if member else ""))
    st.caption(f"{fmt_label} · {detail['vpip'].opps} mãos com decisão pré-flop")
    pre, post, notes = st.tabs(["Pré-Flop", "Pós-Flop", "Notas"])
    with pre:
        cols = st.columns(len(data.PREFLOP_STATS))
        for col, s in zip(cols, data.PREFLOP_STATS):
            d = detail[s]
            col.metric(d.label, "–" if d.pct is None else f"{d.pct:.1f}%", help=f"{d.cases} de {d.opps}")
        st.dataframe([{"Stat": d.label, "Oportunidades": d.opps, "Ações": d.cases,
                       "%": None if d.pct is None else round(d.pct, 1)} for d in (detail[s] for s in data.PREFLOP_STATS)],
                     hide_index=True, width="stretch")
    with post:
        d = detail["cbet_flop"]
        c1, c2, c3 = st.columns(3)
        c1.metric("C-Bet Flop", "–" if d.pct is None else f"{d.pct:.1f}%")
        c2.metric("Oportunidades", d.opps)
        c3.metric("Apostas", d.cases)
    with notes:
        df = data.player_notes(conn, room, player)
        if df.empty:
            st.caption("Sem notas.")
        else:
            st.dataframe(df, hide_index=True, width="stretch")
        with st.form(f"note_{room}_{player}", clear_on_submit=True):
            a, b = st.columns(2)
            category = a.selectbox("Categoria", data.NOTE_CATEGORIES)
            street = b.selectbox("Rua", data.NOTE_STREETS)
            tags = st.multiselect("Tags", data.NOTE_TAGS)
            text = st.text_area("Nota", max_chars=1000)
            if st.form_submit_button("Salvar nota"):
                data.add_note(conn, room, player, category=category, street=street, tags=tags, note=text,
                              author=RUNTIME.member or None)
                st.toast("Nota salva.")
                st.rerun(scope="fragment")


def selectable_table(df, key: str):
    """Tabela com cores; devolve a linha selecionada (ou None). A seleção é guardada pela chave da linha."""
    event = st.dataframe(data.style_table(df), key=key, on_select="rerun", selection_mode="single-row",
                         hide_index=True, width="stretch", height=min(38 + 35 * len(df), 460))
    rows = event.selection.rows if event and event.selection else []
    if rows and rows != st.session_state.get(f"_{key}_rows"):
        st.session_state[f"{key}_sel"] = df.iloc[rows[0]].to_dict()
    st.session_state[f"_{key}_rows"] = rows
    return st.session_state.get(f"{key}_sel")


def ago(age: int) -> str:
    return f"há {age}s" if age < 120 else f"há {age // 60} min" if age < 7200 else f"há {age // 3600} h"


# ------------------------------------------------------------------ páginas

def page_live() -> None:
    @st.fragment(run_every=refresh)
    def body():
        status_bar()
        c1, c2 = st.columns([3, 1])
        c1.markdown("### Mesas ao vivo")
        minutes = c2.select_slider("Janela", options=[10, 30, 60, 180], value=30, key="live_win",
                                   format_func=lambda m: f"{m} min", label_visibility="collapsed")
        tables = [t for t in data.active_tables(conn, minutes=minutes) if t["format"] == fmt]
        if not tables:
            st.info("Nenhuma mesa com mão nos últimos minutos. Assim que o cliente oficial da sua sala de poker "
                    "registrar uma nova mão na pasta monitorada, ela aparecerá aqui automaticamente.")
            return
        for t in tables:
            with st.container(border=True):
                head = f"**{t['room']} · {t['table_id']}** · blinds {t['blinds']} · {t['max_seats'] or '?'}-max"
                st.markdown(head + f" · <span style='opacity:.6'>última mão {ago(t['age'])}</span>",
                            unsafe_allow_html=True)
                df = t["players"]
                sel = selectable_table(df, key=f"live_{t['room']}_{t['table_id']}")
                if sel:
                    player_detail(t["room"], sel["Jogador"])
    body()


def page_players() -> None:
    @st.fragment(run_every=refresh)
    def body():
        status_bar()
        st.markdown("### Jogadores")
        c1, c2, c3 = st.columns([2, 1, 1])
        search = c1.text_input("Buscar jogador (ID)", key="pl_search")
        rooms = [r[0] for r in conn.execute("SELECT DISTINCT room FROM stat_acc ORDER BY 1")]
        room = c2.selectbox("Sala", ["Todas"] + rooms, key="pl_room")
        min_hands = c3.number_input("Mãos mínimas", min_value=0, value=50, step=50, key="pl_min")
        df = data.players_table(conn, fmt=fmt, room=None if room == "Todas" else room, min_hands=int(min_hands),
                                search=search, limit=300)
        st.caption(f"{len(df)} jogador(es)" + (" · mostrando os 300 com mais mãos" if len(df) == 300 else ""))
        if df.empty:
            st.info("Nenhum jogador com esses filtros.")
            return
        sel = selectable_table(df, key="players")
        if sel:
            st.divider()
            player_detail(sel["Sala"], sel["Jogador"])
    body()


def page_hands() -> None:
    status_bar()
    st.markdown("### Mãos")
    c1, c2, c3 = st.columns([1, 1, 2])
    rooms = [r[0] for r in conn.execute("SELECT DISTINCT room FROM hands ORDER BY 1")]
    room = c1.selectbox("Sala", ["Todas"] + rooms, key="h_room")
    members = [r[0] for r in conn.execute("SELECT member_id FROM nvt_members ORDER BY 1")]
    member = c2.selectbox("Enviada por", ["Todos"] + members, key="h_member")
    search = c3.text_input("Buscar nº da mão ou mesa", key="h_search")
    df = data.recent_hands(conn, room=None if room == "Todas" else room,
                           member=None if member == "Todos" else member, search=search, limit=300)
    if df.empty:
        st.info("Nenhuma mão encontrada.")
        return
    view = df[["Início", "Sala", "Mesa", "Mão #", "Pote (bb)", "Board", "Vencedor", "Enviada por"]]
    event = st.dataframe(view, key="hands_grid", on_select="rerun", selection_mode="single-row", hide_index=True,
                         width="stretch", height=380,
                         column_config={"Início": st.column_config.DatetimeColumn(format="DD/MM HH:mm:ss")})
    rows = event.selection.rows if event and event.selection else []
    if rows:
        r = df.iloc[rows[0]]
        st.divider()
        st.markdown(f"#### Mão #{r['Mão #']} · {r['Sala']} · {r['Mesa']}")
        st.markdown(f"Board: {cards_html(r['Board'])} · Pote: **{r['Pote (bb)']} bb** · Vencedor: {r['Vencedor'] or '–'}",
                    unsafe_allow_html=True)
        st.code(data.hand_text(conn, int(r["pk"])), language=None)


def page_team() -> None:
    @st.fragment(run_every=max(refresh, 10))
    def body():
        status_bar()
        st.markdown("### Time")
        df = data.team_overview(conn)
        c1, c2, c3 = st.columns(3)
        c1.metric("Membros", len(df))
        c2.metric("Online agora", int(df["Online"].sum()) if not df.empty else 0)
        c3.metric("Enviadas hoje", int(df["Enviadas hoje"].sum()) if not df.empty else 0)
        st.dataframe(df, hide_index=True, width="stretch",
                     column_config={"Online": st.column_config.CheckboxColumn(),
                                    "Última mão": st.column_config.DatetimeColumn(format="DD/MM HH:mm")})
        st.markdown("#### Mãos por dia (14 dias)")
        per_day = data.hands_per_day(conn)
        if per_day.empty:
            st.caption("Sem mãos no período.")
        else:
            st.bar_chart(per_day)
    body()


def decode_upload(raw: bytes) -> str:
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")      # históricos salvos pelo Bloco de Notas antigo


def page_import() -> None:
    st.markdown("### Importar sessão")
    member = RUNTIME.member or os.environ.get("NVT_MEMBER", "")
    if not member:
        st.warning("Importação disponível só no NvtTracker instalado (falta o membro no nvt_config.ini).")
        return
    st.caption(f"Arraste um ou mais arquivos de histórico (.txt). As mãos entram no banco do time como enviadas por "
               f"**{member}**. Enviar o mesmo arquivo de novo não duplica nada.")
    files = st.file_uploader("Arquivos de histórico", type=["txt"], accept_multiple_files=True,
                             key=f"upl_{st.session_state.get('upl_round', 0)}", label_visibility="collapsed")
    if not files or not st.button("Importar", type="primary"):
        return
    from nvttracker.db import ensure_member, finish_batch, import_text, start_batch
    from nvttracker.stats.store import compute_pending

    ensure_member(conn, member)
    batch = start_batch(conn, root_path="upload", host=os.environ.get("COMPUTERNAME"), kind="import", member_id=member)
    total, rows = {"new": 0, "old": 0, "quar": 0}, []
    with st.spinner("Importando…"):
        for f in files:
            rep = import_text(conn, decode_upload(f.getvalue()), member, f.name, batch_id=batch)
            c = rep.counts
            new, old = c["new"], c["new_source"] + c["duplicate"]
            quar = c["quarantine_new"] + c["quarantine_again"]
            total["new"] += new; total["old"] += old; total["quar"] += quar
            rows.append({"Arquivo": f.name, "Novas": new, "Já no banco": old, "Com erro": quar})
        finish_batch(conn, batch, {"upload": rows}, hands_new=total["new"], errors=total["quar"],
                     status="partial" if total["quar"] else "ok")
        stats = compute_pending(conn)
    RUNTIME.event(f"importação manual: {total['new']} mão(s) nova(s) de {len(files)} arquivo(s)")
    if total["new"] + total["old"] == 0:
        st.error("Nenhuma mão reconhecida. Confira se o arquivo é um histórico de mãos NLHE em texto.")
    elif total["new"] == 0:
        st.info(f"Nenhuma mão nova: as {total['old']} mão(s) do arquivo já estavam no banco do time.")
    else:
        msg = f"Sucesso! {total['new']} mão(s) importada(s)"
        if total["old"]:
            msg += f", {total['old']} já estava(m) no banco"
        st.success(msg + (". Stats do time atualizados." if not stats.blocked else
                          ". Os stats serão atualizados quando o admin recalcular."))
    if total["quar"]:
        st.warning(f"{total['quar']} mão(s) com formato não reconhecido ficaram na quarentena para revisão.")
    st.dataframe(rows, hide_index=True, width="stretch")
    st.session_state["upl_round"] = st.session_state.get("upl_round", 0) + 1   # limpa a área para o próximo envio


def page_status() -> None:
    @st.fragment(run_every=refresh)
    def body():
        st.markdown("### Status")
        o = data.overview(conn)
        c1, c2, c3 = st.columns(3)
        c1.metric("Mãos no banco", f"{o['hands']:,}".replace(",", "."))
        c2.metric("Jogadores", f"{o['players']:,}".replace(",", "."))
        age = o["last_capture_age"]
        c3.metric("Última captura (time)", "–" if age is None else ago(age))
        if RUNTIME.member:
            st.markdown("#### Este computador")
            w = RUNTIME.watcher
            ws = getattr(w, "stats", None)
            st.markdown(
                f"- **Captura:** {RUNTIME.watcher_state} · pasta `{RUNTIME.hh_folder}`"
                + (f" · {ws.files} arquivo(s) monitorado(s)" if ws else "")
                + f"\n- **Exportação do time:** "
                + (f"{RUNTIME.export_state} · `{RUNTIME.export_folder}` · atraso {RUNTIME.export_delay_min} min · "
                   f"{RUNTIME.export_total} mão(s) nesta sessão" if RUNTIME.export_enabled else "desligada")
                + (f"\n- **Erro na exportação:** {RUNTIME.export_error}" if RUNTIME.export_error else ""))
            st.markdown("#### Eventos")
            with RUNTIME.lock:
                events = list(RUNTIME.events)[:200]
            if events:
                st.dataframe([{"Hora": t.strftime("%H:%M:%S"), "Tipo": lvl, "Evento": msg} for t, lvl, msg in events],
                             hide_index=True, width="stretch", height=360)
            else:
                st.caption("Nenhum evento ainda.")
    body()


nav = st.navigation([st.Page(page_live, title="Ao vivo", icon="🟢", default=True),
                     st.Page(page_players, title="Jogadores", icon="👥"),
                     st.Page(page_hands, title="Mãos", icon="🃏"),
                     st.Page(page_team, title="Time", icon="🏆"),
                     st.Page(page_import, title="Importar Sessão", icon="📥", url_path="importar"),
                     st.Page(page_status, title="Status", icon="⚙️")], position="top")
nav.run()
