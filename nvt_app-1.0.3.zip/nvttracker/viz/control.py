"""Painel de CONTROLE do NvtTracker — uma janelinha sempre-no-topo p/ ligar/desligar, com
1 clique, a CAPTURA (capturador do PPPoker), o BANCO (watcher) e o HUD (overlay). Mostra o
status de cada um e se o PPPoker está aberto. Simples e dinâmico: fecha/abre a HUD num botão.

Uso:
    python -m nvttracker.viz.control
    nvt-control --base C:\\NVTLIVE --member eduardo
Cada processo é filho deste painel; fechar o painel encerra todos (a captura com desligamento
limpo, via CTRL_BREAK, p/ não dar fatal-error no PPPoker).
"""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys

from .hud import resolve_dsn

# caminhos padrão nesta máquina (ajustáveis por argumento)
BOT_REPO = r"C:\Meus Projetos\Aplicativos\_repo_software"
CAPTURER = os.path.join(BOT_REPO, "research", "ppp_il2cpp", "capturar_maos.py")
NVT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # raiz do nvttracker
ANALISE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "analise.py")        # painel H2N
_NVTDIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "NvtTracker")
_LOCK_FILE = os.path.join(_NVTDIR, "hud_locked.flag")
_AUTO_FILE = os.path.join(_NVTDIR, "hud_auto.flag")

OK, OFF, RUN = "#3fb950", "#6e7681", "#d29922"


def _pppoker_open() -> bool:
    try:
        import psutil
        return any("pppoker" in (p.name() or "").lower() for p in psutil.process_iter(["name"]))
    except Exception:
        return False


class Proc:
    """Um subprocesso gerenciado (start/stop), com desligamento limpo opcional (CTRL_BREAK)."""

    def __init__(self, cmd, cwd, env, clean_break=False):
        self.cmd, self.cwd, self.env, self.clean_break = cmd, cwd, env, clean_break
        self.p = None

    def running(self) -> bool:
        return self.p is not None and self.p.poll() is None

    def start(self):
        if self.running():
            return
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if self.clean_break else 0
        self.p = subprocess.Popen(self.cmd, cwd=self.cwd, env=self.env, creationflags=flags,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def stop(self):
        if not self.running():
            self.p = None
            return
        try:
            if self.clean_break:
                self.p.send_signal(signal.CTRL_BREAK_EVENT)   # capturador desanexa limpo
                try:
                    self.p.wait(timeout=4)
                except Exception:
                    pass
            if self.p.poll() is None:
                self.p.terminate()
        except Exception:
            pass
        self.p = None

    def toggle(self):
        self.stop() if self.running() else self.start()


def build(args):
    env = dict(os.environ)
    env["NVT_DATABASE_URL"] = resolve_dsn(args.dsn)
    env["PYTHONPATH"] = NVT_ROOT
    py = sys.executable
    live = os.path.join(args.base, "_live")
    cap = Proc([py, "-I", "-u", CAPTURER, "--base", args.base, "--tournament", args.tournament],
               cwd=os.path.dirname(CAPTURER), env=env, clean_break=True)
    watch = Proc([py, "-u", "-m", "nvttracker.cli", "nvt-watch", args.base, "--member", args.member,
                  "--poll", "1", "--debounce", "1", "--rescan", "8"], cwd=NVT_ROOT, env=env)
    hud = Proc([py, "-u", "-m", "nvttracker.viz.hud_overlay", "--live-dir", live,
                "--minutes", str(args.minutes), "--refresh", "3"], cwd=NVT_ROOT, env=env)
    analise = Proc([py, "-m", "streamlit", "run", ANALISE], cwd=NVT_ROOT, env=env)   # painel H2N (abre no navegador)
    return {"Captura": cap, "Banco": watch, "HUD": hud, "Análise": analise}


def run(args):
    import tkinter as tk
    procs = build(args)
    root = tk.Tk()
    root.title("NVT Tracker")
    root.configure(bg="#0d1117")
    root.attributes("-topmost", True)
    root.geometry("+30+30")
    tk.Label(root, text="NVT Tracker", bg="#0d1117", fg="#e6edf3",
             font=("Segoe UI", 11, "bold")).grid(row=0, column=0, columnspan=3, padx=8, pady=(8, 2), sticky="w")
    pp = tk.Label(root, text="PPPoker: …", bg="#0d1117", fg="#8b93a3", font=("Segoe UI", 8))
    pp.grid(row=0, column=2, padx=8, sticky="e")

    dots, btns = {}, {}
    for i, (name, proc) in enumerate(procs.items(), start=1):
        dots[name] = tk.Label(root, text="●", bg="#0d1117", fg=OFF, font=("Segoe UI", 12))
        dots[name].grid(row=i, column=0, padx=(10, 2), pady=3)
        tk.Label(root, text=name, bg="#0d1117", fg="#e6edf3", font=("Segoe UI", 10),
                 width=8, anchor="w").grid(row=i, column=1, sticky="w")
        b = tk.Button(root, text="Ligar", width=8, font=("Segoe UI", 9),
                      command=lambda n=name: (procs[n].toggle(), refresh()))
        b.grid(row=i, column=2, padx=8, pady=3)
        btns[name] = b

    def all_on():
        for p in procs.values():
            p.start()
        refresh()

    def all_off():
        for p in procs.values():
            p.stop()
        refresh()

    def toggle_lock():
        try:
            if os.path.exists(_LOCK_FILE):
                os.remove(_LOCK_FILE)
            else:
                os.makedirs(os.path.dirname(_LOCK_FILE), exist_ok=True)
                open(_LOCK_FILE, "w").close()
        except Exception:
            pass
        refresh()

    def do_auto():
        try:
            os.makedirs(_NVTDIR, exist_ok=True)
            open(_AUTO_FILE, "w").close()
        except Exception:
            pass

    r0 = len(procs) + 1          # linhas dos processos ocupam 1..len(procs)
    tk.Button(root, text="⊞ Organizar", width=10, font=("Segoe UI", 9), command=do_auto).grid(
        row=r0, column=0, columnspan=2, pady=(6, 2), padx=(10, 0), sticky="w")
    lock_btn = tk.Button(root, text="🔒 Fixar", width=8, font=("Segoe UI", 9), command=toggle_lock)
    lock_btn.grid(row=r0, column=2, pady=(6, 2), padx=8)
    tk.Button(root, text="▶ Tudo", width=8, font=("Segoe UI", 9, "bold"), command=all_on).grid(
        row=r0 + 1, column=1, pady=(2, 10))
    tk.Button(root, text="⏸ Tudo", width=8, font=("Segoe UI", 9), command=all_off).grid(
        row=r0 + 1, column=2, pady=(2, 10), padx=8)

    def refresh():
        pp.config(text="PPPoker: " + ("aberto" if _pppoker_open() else "fechado"),
                  fg=OK if _pppoker_open() else OFF)
        lock_btn.config(text=("🔓 Soltar" if os.path.exists(_LOCK_FILE) else "🔒 Fixar"))
        for name, proc in procs.items():
            on = proc.running()
            dots[name].config(fg=(RUN if name == "Captura" and on and not _pppoker_open() else (OK if on else OFF)))
            btns[name].config(text="Desligar" if on else "Ligar")
        root.after(1000, refresh)

    def on_close():
        for p in procs.values():
            p.stop()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    refresh()
    root.mainloop()


def main() -> int:
    ap = argparse.ArgumentParser(description="Painel de controle do NvtTracker (Captura/Banco/HUD)")
    ap.add_argument("--dsn")
    ap.add_argument("--base", default=r"C:\NVTLIVE", help="pasta de captura (.txt + _live)")
    ap.add_argument("--member", default="eduardo")
    ap.add_argument("--tournament", default="live")
    ap.add_argument("--minutes", type=int, default=1440)
    a = ap.parse_args()
    run(a)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
