"""Dados e regras visuais do NvtDashboard (sem Streamlit: testável isoladamente)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import pandas as pd
import psycopg

from ..stats.definitions import STATS

# rótulos das colunas, na ordem do painel
LABELS = {"vpip": "VPIP", "pfr": "PFR", "three_bet": "3Bet", "fold_to_3bet": "F3B", "steal": "Steal",
          "cbet_flop": "CBet", "check_raise": "CheckRaise", "fold_to_cbet": "FoldCBet",
          "wtsd": "WTSD", "wsd": "W$SD", "wwsf": "WWSF", "squeeze": "Squeeze", "four_bet": "4Bet",
          "fold_to_4bet": "F4B", "fold_to_steal": "FvSteal", "cbet_turn": "CBetT"}
PREFLOP_STATS = ["vpip", "pfr", "three_bet", "fold_to_3bet", "steal", "squeeze", "four_bet",
                 "fold_to_4bet", "fold_to_steal"]
POSTFLOP_STATS = ["cbet_flop", "cbet_turn", "check_raise", "fold_to_cbet", "wtsd", "wsd", "wwsf"]
NOTE_CATEGORIES = ["fish", "reg", "nit", "maniac", "lag", "tag", "outro"]
NOTE_STREETS = ["geral", "preflop", "flop", "turn", "river"]
NOTE_TAGS = ["overfold_vs_3bet", "3bet_light", "cbet_alto", "cbet_baixo", "limper", "calling_station",
             "steal_alto", "defende_bb", "tilt", "short_stack"]

# ------------------------------------------------------------------ cores (limites padrão)

GREEN, RED, NEUTRAL, PURPLE, YELLOW = "green", "red", "neutral", "purple", "yellow"
CSS = {
    GREEN: "background-color: rgba(46, 160, 67, 0.35)",
    RED: "background-color: rgba(218, 54, 51, 0.35)",
    PURPLE: "background-color: rgba(137, 87, 229, 0.38)",
    YELLOW: "background-color: rgba(210, 153, 34, 0.38)",
    NEUTRAL: "",
}


def stat_color(stat: str, value: float | None) -> str:
    """Faixa de cor do valor: VPIP (<18 verde, 18–28 neutro, >28 vermelho), PFR (>22 verde, 14–22 neutro,
    <14 vermelho), 3Bet (>10 roxo, 5–10 neutro, <5 amarelo). Demais stats e valores vazios: neutro."""
    if value is None or pd.isna(value):
        return NEUTRAL
    if stat == "vpip":
        return GREEN if value < 18 else RED if value > 28 else NEUTRAL
    if stat == "pfr":
        return GREEN if value > 22 else RED if value < 14 else NEUTRAL
    if stat == "three_bet":
        return PURPLE if value > 10 else YELLOW if value < 5 else NEUTRAL
    return NEUTRAL


def style_table(df: pd.DataFrame):
    """Styler com a formatação condicional nas colunas VPIP, PFR e 3Bet e valores com 1 casa decimal."""
    def col_css(col: pd.Series, stat: str) -> list[str]:
        return [CSS[stat_color(stat, v)] for v in col]

    df = df.copy()
    for s in STATS:                       # None em coluna object vira NaN (senão aparece "None")
        if LABELS[s] in df.columns:
            df[LABELS[s]] = pd.to_numeric(df[LABELS[s]], errors="coerce")
    styler = df.style
    for stat in ("vpip", "pfr", "three_bet"):
        if LABELS[stat] in df.columns:
            styler = styler.apply(col_css, stat=stat, subset=[LABELS[stat]])
    fmt = {LABELS[s]: "{:.1f}" for s in STATS if LABELS[s] in df.columns}
    if "Stack (bb)" in df.columns:
        fmt["Stack (bb)"] = "{:.0f}"
    return styler.format(fmt, na_rep="–")


# ------------------------------------------------------------------ consultas

def players_table(conn: psycopg.Connection, *, fmt: str, room: str | None = None, active_minutes: int | None = None,
                  min_hands: int = 0, search: str | None = None, limit: int = 500) -> pd.DataFrame:
    """Uma linha por jogador (no formato escolhido) com os 6 stats; ``active_minutes`` restringe aos jogadores das
    mãos capturadas nesse intervalo (mesa ativa)."""
    rows = conn.execute("""
        WITH active AS (
            SELECT DISTINCT h.room, hp.player_id FROM hands h JOIN hand_players hp USING (hand_pk)
            WHERE %(mins)s::int IS NOT NULL AND h.created_at >= now() - make_interval(mins => %(mins)s::int)
              AND h.format = %(fmt)s
        ), last_seen AS (
            SELECT h.room, hp.player_id, max(h.created_at) AS last_seen
            FROM hands h JOIN hand_players hp USING (hand_pk) JOIN active a USING (room, player_id)
            GROUP BY 1, 2
        )
        SELECT a.room, a.player_id, l.member_id, a.stat_id, a.opps, a.cases, ls.last_seen
        FROM stat_acc a
        LEFT JOIN player_links l ON l.room = a.room AND l.player_id = a.player_id
        LEFT JOIN last_seen ls ON ls.room = a.room AND ls.player_id = a.player_id
        WHERE a.format = %(fmt)s
          AND (%(room)s::text IS NULL OR a.room = %(room)s)
          AND (%(search)s::text IS NULL OR a.player_id ILIKE '%%' || %(search)s || '%%')
          AND (%(mins)s::int IS NULL OR (a.room, a.player_id) IN (SELECT room, player_id FROM active))""",
        {"fmt": fmt, "room": room, "mins": active_minutes, "search": search or None}).fetchall()
    cols = ["Sala", "Jogador", "Membro", "Mãos"] + [LABELS[s] for s in STATS]
    if not rows:
        return pd.DataFrame(columns=cols)
    raw = pd.DataFrame(rows, columns=["room", "player_id", "member", "stat", "opps", "cases", "last_seen"])
    raw["value"] = (100.0 * raw["cases"] / raw["opps"].where(raw["opps"] > 0)).astype(float)
    wide = raw.pivot_table(index=["room", "player_id"], columns="stat", values="value", aggfunc="first")
    hands = raw[raw["stat"] == "vpip"].set_index(["room", "player_id"])["opps"].rename("hands")
    meta = raw.groupby(["room", "player_id"]).agg(member=("member", "first"), last_seen=("last_seen", "max"))
    df = meta.join(hands).join(wide).reset_index()
    df["hands"] = df["hands"].fillna(0).astype(int)
    df = df[df["hands"] >= min_hands]
    order = ["last_seen", "hands"] if active_minutes else ["hands"]
    df = df.sort_values(order, ascending=False).head(limit)
    df = df.rename(columns={"room": "Sala", "player_id": "Jogador", "member": "Membro", "hands": "Mãos",
                            **{s: LABELS[s] for s in STATS}})
    for c in cols:
        if c not in df.columns:
            df[c] = None
    stat_cols = [LABELS[s] for s in STATS]
    df[stat_cols] = df[stat_cols].astype(float)          # vazio vira NaN e aparece como "–"
    df["Membro"] = df["Membro"].fillna("–")
    return df[cols].reset_index(drop=True)


@dataclass(frozen=True)
class StatLine:
    stat_id: str
    label: str
    opps: int
    cases: int

    @property
    def pct(self) -> float | None:
        return 100.0 * self.cases / self.opps if self.opps else None


def player_detail(conn: psycopg.Connection, room: str, player_id: str, fmt: str) -> dict[str, StatLine]:
    got = {s: (o, c) for s, o, c in conn.execute(
        "SELECT stat_id, opps, cases FROM stat_acc WHERE room=%s AND player_id=%s AND format=%s",
        (room, player_id, fmt))}
    return {s: StatLine(s, LABELS[s], *got.get(s, (0, 0))) for s in STATS}


def _player_hands(conn: psycopg.Connection, room: str, player_id: str, fmt: str, *,
                  require_position: bool = False, limit: int | None = None) -> list:
    """Mãos PARSEADAS do jogador (com cartas/fichas), em ordem cronológica. Usado por várias
    análises (posição, curva de ganhos, sessões). `limit` pega as N mais recentes (p/ resposta
    rápida na UI; parsear+equity de milhares de mãos é caro)."""
    from ..parser.nlhe_text import parse_hand

    cond = "AND hp.position IS NOT NULL" if require_position else ""
    order = f"ORDER BY h.started_utc DESC LIMIT {int(limit)}" if limit else "ORDER BY h.started_utc"
    rows = conn.execute(f"""
        SELECT r.raw_text
        FROM hands h JOIN hand_players hp USING (hand_pk)
        JOIN LATERAL (SELECT raw_text FROM hand_raw hr WHERE hr.hand_pk = h.hand_pk
                      ORDER BY length(raw_text) DESC LIMIT 1) r ON TRUE
        WHERE hp.player_id = %s AND h.room = %s AND h.format = %s {cond}
        {order}
    """, (player_id, room, fmt)).fetchall()
    out = []
    for (raw,) in rows:
        try:
            out.append(parse_hand(raw, check_chips=False))
        except Exception:
            continue
    if limit:
        out.reverse()          # DESC+LIMIT pegou as recentes; volta p/ cronológico
    return out


def winnings(conn: psycopg.Connection, room: str, player_id: str, fmt: str,
             limit: int | None = None, with_ev: bool = True) -> pd.DataFrame:
    """Curva de ganhos acumulada (Graph do H2N): Won · All-in EV · ganho no/sem showdown, em bb."""
    from ..stats.curves import winnings_curve

    pts = winnings_curve(_player_hands(conn, room, player_id, fmt, limit=limit), player_id, with_ev=with_ev)
    if not pts:
        return pd.DataFrame()
    df = pd.DataFrame(pts).set_index("n")
    return df.rename(columns={"won": "Won (real)", "ev": "All-in EV",
                              "won_sd": "Ganho no showdown", "won_nosd": "Ganho sem showdown"})


def range_grid(conn: psycopg.Connection, room: str, player_id: str, fmt: str, stat: str,
               limit: int | None = None) -> dict[str, list[int]]:
    """Matriz 13×13: {combo: [oportunidades, casos]} para uma stat (vpip/pfr/three_bet…)."""
    from ..stats.range_matrix import range_matrix

    hands = _player_hands(conn, room, player_id, fmt, limit=limit)
    return range_matrix(hands, player_id, stat)


def postflop_by_texture(conn: psycopg.Connection, room: str, player_id: str, fmt: str, stat: str,
                        limit: int | None = None) -> dict[str, list[int]]:
    """{textura: [oportunidades, casos]} para uma stat pós-flop (ex.: cbet_flop)."""
    from ..stats.postflop_texture import texture_report

    hands = _player_hands(conn, room, player_id, fmt, limit=limit)
    return texture_report(hands, player_id, stat)


def sessions(conn: psycopg.Connection, room: str, player_id: str, fmt: str, gap_minutes: int = 30,
             limit: int | None = None, with_ev: bool = True) -> pd.DataFrame:
    """Sessões do jogador (aba Sessions do H2N): uma linha por sessão com ganho/EV/duração/VPIP/PFR."""
    from ..stats.sessions import session_rows

    rows = session_rows(_player_hands(conn, room, player_id, fmt, limit=limit), player_id,
                        gap_minutes, with_ev=with_ev)
    if not rows:
        return pd.DataFrame()
    out = []
    for r in rows:                       # datetimes puros (Hand.started_utc), não Timestamp do pandas
        m = r["duracao_min"]
        dur = f"{int(m // 60)}h{int(m % 60):02d}m" if m >= 60 else f"{int(m)}m"
        out.append({"Início": r["inicio"].astimezone().strftime("%d/%m %H:%M"), "Duração": dur,
                    "Mãos": r["maos"], "Won (bb)": r["won_bb"], "EV (bb)": r["ev_bb"],
                    "bb/100": r["bb100"], "EV bb/100": r["ev_bb100"], "VPIP": r["vpip"], "PFR": r["pfr"]})
    return pd.DataFrame(out)


def by_position(conn: psycopg.Connection, room: str, player_id: str, fmt: str,
                limit: int | None = None, with_ev: bool = True) -> pd.DataFrame:
    """Tabela de ANÁLISE por POSIÇÃO (estilo H2N): Posição × [Mãos, bb/100, EV bb/100, stats].
    Parseia o texto de cada mão (dá cartas/fichas p/ o EV all-in ajustado) e agrega por posição."""
    from ..stats.by_position import ordered_positions, position_report

    cols = ["Posição", "Mãos", "bb/100", "EV bb/100"] + [LABELS[s] for s in STATS]
    hands = _player_hands(conn, room, player_id, fmt, require_position=True, limit=limit)
    if not hands:
        return pd.DataFrame(columns=cols)
    rep = position_report(hands, player_id, with_ev=with_ev)
    data = []
    for pos in ordered_positions(rep.keys()):
        d = rep[pos]
        n = d["hands"] or 1
        row = {"Posição": pos, "Mãos": d["hands"],
               "bb/100": round(100.0 * d["net_bb"] / n, 1),
               "EV bb/100": round(100.0 * d["ev_bb"] / n, 1)}
        for s in STATS:
            o, c = d["stats"].get(s, (0, 0))
            row[LABELS[s]] = round(100.0 * c / o, 1) if o else None
        data.append(row)
    return pd.DataFrame(data)[cols]


def player_notes(conn: psycopg.Connection, room: str, player_id: str) -> pd.DataFrame:
    rows = conn.execute("""
        SELECT created_at, category, street, tags, note, author FROM player_notes
        WHERE room=%s AND player_id=%s ORDER BY created_at DESC""", (room, player_id)).fetchall()
    rows = [(ts.astimezone().strftime("%d/%m/%Y %H:%M"), cat, street, ", ".join(tags), note, author or "–")
            for ts, cat, street, tags, note, author in rows]
    return pd.DataFrame(rows, columns=["Quando", "Categoria", "Rua", "Tags", "Nota", "Autor"])


def add_note(conn: psycopg.Connection, room: str, player_id: str, *, category: str, street: str = "geral",
             tags: list[str] | None = None, note: str = "", author: str | None = None) -> int:
    if category not in NOTE_CATEGORIES or street not in NOTE_STREETS:
        raise ValueError("categoria ou rua inválida")
    return conn.execute("""
        INSERT INTO player_notes (room, player_id, category, street, tags, note, author)
        VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING note_id""",
        (room, player_id, category, street, tags or [], note.strip(), author or None)).fetchone()[0]


def hand_mark(conn: psycopg.Connection, hand_pk: int):
    """Marcação da mão pelo usuário atual: (tags, nota) ou None se não marcada."""
    return conn.execute(
        "SELECT tags, note FROM marked_hands WHERE hand_pk=%s AND author=current_user", (hand_pk,)).fetchone()


def mark_hand(conn: psycopg.Connection, hand_pk: int, tags: list[str], note: str = "") -> None:
    """Marca (ou re-marca) a mão para estudo, com tags e nota."""
    conn.execute("""
        INSERT INTO marked_hands (hand_pk, tags, note) VALUES (%s, %s, %s)
        ON CONFLICT (hand_pk, author) DO UPDATE SET tags=EXCLUDED.tags, note=EXCLUDED.note, marked_at=now()""",
        (hand_pk, tags, note.strip()))


def unmark_hand(conn: psycopg.Connection, hand_pk: int) -> None:
    conn.execute("DELETE FROM marked_hands WHERE hand_pk=%s AND author=current_user", (hand_pk,))


def marked_hands(conn: psycopg.Connection, room: str, player_id: str, fmt: str) -> pd.DataFrame:
    """Mãos marcadas (aba Marked Hands do H2N): tags, nota, data, board e o ganho do jogador."""
    rows = conn.execute("""
        SELECT h.hand_pk, m.marked_at, m.tags, m.note, h.hand_no, h.table_id,
               array_to_string(h.board, ' '), h.pot, h.bb, hp.net_bb
        FROM marked_hands m JOIN hands h USING (hand_pk)
        LEFT JOIN hand_players hp ON hp.hand_pk = h.hand_pk AND hp.player_id = %s
        WHERE h.room = %s AND h.format = %s AND m.author = current_user
        ORDER BY m.marked_at DESC""", (player_id, room, fmt)).fetchall()
    out = []
    for pk, when, tags, note, no, table, board, pot, bb, net in rows:
        out.append({"pk": pk, "Marcada": when.astimezone().strftime("%d/%m %H:%M"),
                    "Tags": ", ".join(tags), "Mesa": table, "Board": board,
                    "Ganho(bb)": round(float(net), 1) if net is not None else None,
                    "Nota": note, "Mão #": no})
    return pd.DataFrame(out)


def overview(conn: psycopg.Connection) -> dict:
    # idade calculada no relógio do banco: o relógio do PC do jogador pode estar adiantado ou atrasado
    hands, players, last, age = conn.execute("""
        SELECT (SELECT count(*) FROM hands), (SELECT count(DISTINCT (room, player_id)) FROM stat_acc),
               m.last, extract(epoch FROM now() - m.last)::int
        FROM (SELECT max(created_at) AS last FROM hands) m""").fetchone()
    watch = conn.execute("""
        SELECT member_id, started_at FROM batches WHERE kind='watch' AND status='running'
        ORDER BY started_at DESC""").fetchall()
    return {"hands": hands, "players": players, "last_capture": last, "last_capture_age": age, "watchers": watch}


# ------------------------------------------------------------------ painéis novos (Ao vivo, Mãos, Time)

def _local(col: pd.Series) -> pd.Series:
    """Horários do banco (UTC) no fuso deste computador, sem tz (para exibir)."""
    tz = datetime.now().astimezone().tzinfo
    return pd.to_datetime(col, utc=True).dt.tz_convert(tz).dt.tz_localize(None)


def _stats_for(conn: psycopg.Connection, fmt: str, keys: list[tuple[str, str]]) -> dict[tuple[str, str], dict]:
    """{(sala, jogador): {"hands": n, "vpip": %, ...}} para uma lista de jogadores."""
    if not keys:
        return {}
    rows = conn.execute("""
        SELECT a.room, a.player_id, a.stat_id, a.opps, a.cases
        FROM stat_acc a JOIN unnest(%s::text[], %s::text[]) k(room, player_id) USING (room, player_id)
        WHERE a.format = %s""", ([k[0] for k in keys], [k[1] for k in keys], fmt)).fetchall()
    out: dict[tuple[str, str], dict] = {}
    for room, pid, stat, opps, cases in rows:
        d = out.setdefault((room, pid), {})
        d[stat] = 100.0 * cases / opps if opps else None
        if stat == "vpip":
            d["hands"] = opps
    return out


def active_tables(conn: psycopg.Connection, *, minutes: int = 30, limit: int = 12) -> list[dict]:
    """Mesas com mão capturada nos últimos ``minutes``: dados da última mão e os jogadores sentados nela."""
    tables = conn.execute("""
        SELECT DISTINCT ON (h.room, h.table_id) h.hand_pk, h.room, h.table_id, h.format, h.tournament_id,
               h.sb, h.bb, h.ante, h.max_seats, h.created_at, extract(epoch FROM now() - h.created_at)::int
        FROM hands h
        WHERE h.created_at >= now() - make_interval(mins => %s) AND h.table_id IS NOT NULL
        ORDER BY h.room, h.table_id, h.started_utc DESC""", (minutes,)).fetchall()
    tables = sorted(tables, key=lambda t: t[10])[:limit]
    result = []
    for pk, room, table_id, fmt, tid, sb, bb, ante, max_seats, created, age in tables:
        seats = conn.execute("""
            SELECT hp.seat, hp.player_id, hp.position, hp.stack_start, l.member_id
            FROM hand_players hp LEFT JOIN player_links l ON l.room = %s AND l.player_id = hp.player_id
            WHERE hp.hand_pk = %s AND NOT hp.sitting_out ORDER BY hp.seat""", (room, pk)).fetchall()
        stats = _stats_for(conn, fmt, [(room, s[1]) for s in seats])
        players = []
        for seat, pid, pos, stack, member in seats:
            s = stats.get((room, pid), {})
            players.append({"Assento": seat, "Jogador": pid, "Pos": pos or "", "Stack (bb)": float(stack / bb) if bb else None,
                            "Time": member or "", "Mãos": s.get("hands", 0),
                            **{LABELS[k]: s.get(k) for k in STATS}})
        blinds = f"{float(sb):g}/{float(bb):g}" + (f" · ante {float(ante):g}" if ante else "")
        result.append({"room": room, "table_id": table_id, "format": fmt, "tournament_id": tid, "blinds": blinds,
                       "max_seats": max_seats, "age": age, "players": pd.DataFrame(players)})
    return result


def recent_hands(conn: psycopg.Connection, *, room: str | None = None, member: str | None = None,
                 search: str | None = None, limit: int = 200) -> pd.DataFrame:
    rows = conn.execute("""
        SELECT h.hand_pk, h.started_utc, h.room, h.table_id, h.format, h.hand_no, h.bb, h.pot,
               array_to_string(h.board, ' '),
               (SELECT string_agg(DISTINCT s.member_id, ', ') FROM hand_sources s WHERE s.hand_pk = h.hand_pk),
               (SELECT string_agg(hp.player_id, ', ') FROM hand_players hp WHERE hp.hand_pk = h.hand_pk AND hp.collected > 0)
        FROM hands h
        WHERE (%(room)s::text IS NULL OR h.room = %(room)s)
          AND (%(member)s::text IS NULL OR EXISTS (SELECT 1 FROM hand_sources s WHERE s.hand_pk = h.hand_pk
                                                    AND s.member_id = %(member)s))
          AND (%(search)s::text IS NULL OR h.hand_no LIKE '%%' || %(search)s || '%%'
               OR h.table_id ILIKE '%%' || %(search)s || '%%')
        ORDER BY h.started_utc DESC LIMIT %(limit)s""",
        {"room": room, "member": member, "search": search or None, "limit": limit}).fetchall()
    df = pd.DataFrame(rows, columns=["pk", "Início", "Sala", "Mesa", "Formato", "Mão #", "bb", "Pote", "Board",
                                     "Enviada por", "Vencedor"])
    if not df.empty:
        df["Início"] = _local(df["Início"])
        df["Pote (bb)"] = (df["Pote"].astype(float) / df["bb"].astype(float)).round(1)
    return df


def hand_text(conn: psycopg.Connection, hand_pk: int) -> str:
    row = conn.execute("SELECT raw_text FROM hand_raw WHERE hand_pk = %s ORDER BY length(raw_text) DESC LIMIT 1",
                       (hand_pk,)).fetchone()
    return row[0] if row else ""


def team_overview(conn: psycopg.Connection) -> pd.DataFrame:
    rows = conn.execute("""
        SELECT m.member_id, m.name,
               (SELECT count(*) FROM hand_sources s WHERE s.member_id = m.member_id),
               (SELECT count(*) FROM hand_sources s WHERE s.member_id = m.member_id
                                                       AND s.created_at >= date_trunc('day', now())),
               (SELECT max(s.created_at) FROM hand_sources s WHERE s.member_id = m.member_id),
               EXISTS (SELECT 1 FROM batches b WHERE b.kind = 'watch' AND b.status = 'running'
                                                 AND b.member_id = m.member_id)
        FROM nvt_members m ORDER BY 3 DESC""").fetchall()
    df = pd.DataFrame(rows, columns=["Membro", "Nome", "Mãos enviadas", "Enviadas hoje", "Última mão", "Online"])
    if not df.empty:
        df["Última mão"] = _local(df["Última mão"])
    return df


def hands_per_day(conn: psycopg.Connection, days: int = 14) -> pd.DataFrame:
    rows = conn.execute("""
        SELECT date_trunc('day', h.started_utc)::date AS dia, s.member_id, count(*)
        FROM hands h JOIN hand_sources s USING (hand_pk)
        WHERE h.started_utc >= now() - make_interval(days => %s)
        GROUP BY 1, 2 ORDER BY 1""", (days,)).fetchall()
    df = pd.DataFrame(rows, columns=["Dia", "Membro", "Mãos"])
    return df.pivot_table(index="Dia", columns="Membro", values="Mãos", fill_value=0) if not df.empty else df
