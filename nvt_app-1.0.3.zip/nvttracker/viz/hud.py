"""HUD simples do NvtTracker — painel always-on-top com os stats dos jogadores das
MESAS ATIVAS (mãos capturadas nos últimos N minutos). Lê o MESMO ``stat_acc`` e usa as
MESMAS faixas de cor do NvtDashboard (``viz/data``), então fica sempre em sincronia com
os números homologados. Atualiza sozinho. Usa só Tkinter (nada de dependência nova).

Uso:
    python -m nvttracker.viz.hud                       # lê NVT_DATABASE_URL / nvt_config.ini
    python -m nvttracker.viz.hud --minutes 30 --refresh 5
    nvt-hud --dsn postgresql://user:senha@host/nvt

É só LEITURA do banco — não captura nem decide nada. A captura das mãos é do watcher
(``nvt-watch``) + o capturador ao vivo do PPPoker; o HUD só MOSTRA o que já está no banco.
"""
from __future__ import annotations

import argparse
import configparser
import os
from pathlib import Path

import pandas as pd

from ..stats.definitions import STATS
from .data import LABELS, active_tables, stat_color

# ordem das colunas de stat (a mesma do dashboard)
STAT_ORDER = list(STATS)

# cores do dashboard (CSS rgba) traduzidas p/ hex sólido sobre fundo escuro do Tk
BG, FG, HEADER_BG, GRID = "#0e1117", "#e6e6e6", "#161a23", "#2a2f3a"
CELL_BG = {"green": "#1f5c2e", "red": "#5c1f1f", "purple": "#432a73",
           "yellow": "#5c4a16", "neutral": "#0e1117"}
COLS = ["Assento", "Jogador", "Pos", "bb", "Mãos"] + [LABELS[s] for s in STAT_ORDER]


def _num(v) -> float | None:
    """Valor da célula como float, ou None (vazio/NaN)."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _fmt(v: float | None, decimals: int = 0) -> str:
    return "–" if v is None else f"{v:.{decimals}f}"


def table_panels(tables: list[dict]) -> list[dict]:
    """PURO (testável sem Tk nem banco): converte o resultado de ``active_tables`` em
    painéis prontos p/ desenhar: ``[{title, columns, rows:[[(texto, cor), ...]]}]``.
    A cor sai do MESMO ``stat_color`` do dashboard (só VPIP/PFR/3Bet pintam; resto neutro)."""
    panels = []
    for t in tables:
        df = t.get("players")
        rows = []
        if df is not None and not df.empty:
            for _, r in df.iterrows():
                cells = [
                    (str(r.get("Assento", "")), "neutral"),
                    (str(r.get("Jogador", "")), "neutral"),
                    (str(r.get("Pos", "") or ""), "neutral"),
                    (_fmt(_num(r.get("Stack (bb)"))), "neutral"),
                    (str(int(_num(r.get("Mãos")) or 0)), "neutral"),
                ]
                for s in STAT_ORDER:
                    v = _num(r.get(LABELS[s]))
                    cells.append((_fmt(v), stat_color(s, v)))
                rows.append(cells)
        title = f'{t.get("room", "")} · {t.get("table_id", "")} · {t.get("blinds", "")} · {t.get("age", 0)}s'
        panels.append({"title": title, "columns": COLS, "rows": rows})
    return panels


# ------------------------------------------------------------------ config / dados

def resolve_dsn(dsn: str | None = None) -> str:
    """DSN: argumento > ``NVT_DATABASE_URL`` > ``[nvt] database_url`` de um nvt_config.ini
    (lar do usuário, pasta atual, ou ao lado do .exe)."""
    dsn = dsn or os.environ.get("NVT_DATABASE_URL")
    if dsn:
        return dsn
    for p in (Path.home() / "nvt_config.ini", Path.cwd() / "nvt_config.ini"):
        if p.exists():
            cfg = configparser.ConfigParser()
            cfg.read(p, encoding="utf-8")
            if cfg.has_option("nvt", "database_url") and cfg.get("nvt", "database_url").strip():
                return cfg.get("nvt", "database_url").strip()
    raise RuntimeError("defina NVT_DATABASE_URL, passe --dsn ou preencha database_url no nvt_config.ini")


def fetch_panels(dsn: str, minutes: int) -> list[dict]:
    from ..db import connect
    with connect(dsn) as conn:
        return table_panels(active_tables(conn, minutes=minutes))


# ------------------------------------------------------------------ janela Tk

class HudWindow:
    def __init__(self, dsn: str, *, minutes: int = 30, refresh: int = 5):
        import tkinter as tk
        self.dsn, self.minutes, self.refresh = dsn, minutes, max(2, refresh)
        self.tk = tk
        self.root = tk.Tk()
        self.root.title("NVT HUD")
        self.root.configure(bg=BG)
        self.root.attributes("-topmost", True)            # sempre no topo
        self.root.geometry("+40+40")
        top = tk.Frame(self.root, bg=HEADER_BG)
        top.pack(fill="x")
        tk.Label(top, text="NVT HUD · mesas ativas", bg=HEADER_BG, fg=FG,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=8, pady=4)
        self.status = tk.Label(top, text="", bg=HEADER_BG, fg="#9aa4b2", font=("Segoe UI", 8))
        self.status.pack(side="right", padx=8)
        self.body = tk.Frame(self.root, bg=BG)
        self.body.pack(fill="both", expand=True, padx=6, pady=6)
        self._tick()

    def _render(self, panels: list[dict], note: str = "") -> None:
        tk = self.tk
        for w in self.body.winfo_children():
            w.destroy()
        if not panels:
            tk.Label(self.body, text="Nenhuma mesa ativa nos últimos %d min." % self.minutes,
                     bg=BG, fg="#9aa4b2", font=("Segoe UI", 10)).pack(padx=10, pady=10)
        for panel in panels:
            tk.Label(self.body, text=panel["title"], bg=BG, fg="#7bdcb5",
                     font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x", pady=(6, 2))
            grid = tk.Frame(self.body, bg=GRID)
            grid.pack(fill="x")
            for c, col in enumerate(panel["columns"]):
                tk.Label(grid, text=col, bg=HEADER_BG, fg=FG, font=("Segoe UI", 8, "bold"),
                         padx=6, pady=2, borderwidth=0).grid(row=0, column=c, sticky="nsew", padx=1, pady=1)
            for ri, cells in enumerate(panel["rows"], start=1):
                for c, (text, color) in enumerate(cells):
                    tk.Label(grid, text=text, bg=CELL_BG.get(color, BG), fg=FG,
                             font=("Segoe UI", 8), padx=6, pady=1).grid(
                        row=ri, column=c, sticky="nsew", padx=1, pady=1)
        self.status.config(text=note)

    def _tick(self) -> None:
        from datetime import datetime
        try:
            panels = fetch_panels(self.dsn, self.minutes)
            self._render(panels, note=f"atualizado {datetime.now():%H:%M:%S} · a cada {self.refresh}s")
        except Exception as e:  # noqa: BLE001 — mostra o erro no painel e segue tentando
            self._render([], note=f"erro: {type(e).__name__}: {e}")
        self.root.after(self.refresh * 1000, self._tick)

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    ap = argparse.ArgumentParser(description="HUD simples do NvtTracker (mesas ativas, always-on-top)")
    ap.add_argument("--dsn", help="padrão: NVT_DATABASE_URL ou nvt_config.ini")
    ap.add_argument("--minutes", type=int, default=30, help="janela de 'mesa ativa' (min)")
    ap.add_argument("--refresh", type=int, default=5, help="intervalo de atualização (s)")
    a = ap.parse_args()
    dsn = resolve_dsn(a.dsn)
    HudWindow(dsn, minutes=a.minutes, refresh=a.refresh).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
