"""HUD OVERLAY dinâmico estilo PPPoker VIP / Hand2Note.

Por jogador, sem borda, sempre-no-topo, ARRASTÁVEL e REDIMENSIONÁVEL (roda do mouse ou
botões ＋／−). CABEÇALHO ao vivo: nick · posição NO momento da mão · stack em BB NO momento
da mão · bounty (PKO). CORPO: VPIP/PFR/Steal/Check-Raise, 3-Bet/Fold 3-Bet/C-Bet/Fold C-Bet,
ITM/Título/Total de mãos, barra WTSD/W$SD — do banco, por uid.

Fonte AO VIVO: snapshots que o capturador grava em <base>\\_live\\<mesa>.json (nick/pos/bb/
bounty no início de cada mão). Sem snapshots, cai p/ as mãos do banco (active_tables).
Funciona em QUALQUER mesa, inclusive observando (sem jogar). Só LEITURA.

Uso:
    python -m nvttracker.viz.hud_overlay --live-dir C:\\NVTLIVE\\_live
    nvt-hud-overlay --minutes 30 --refresh 3
Mouse: arrastar = mover · roda = tamanho · ＋／− = tamanho · botão direito = esconder.
"""
from __future__ import annotations

import argparse
import glob
import json
import os

import pandas as pd

from .data import LABELS, active_tables, stat_color
from .hud import resolve_dsn

BG, FG, SUB, LINE = "#0d1117", "#f5f6f8", "#8b93a3", "#262c36"
CELL = {"green": "#3fb950", "red": "#f85149", "purple": "#a371f7", "yellow": "#d29922", "neutral": FG}
ROW1 = [("vpip", "VPIP"), ("pfr", "PFR"), ("steal", "Steal"), ("check_raise", "Check-Raise")]
ROW2 = [("three_bet", "3-Bet"), ("fold_to_3bet", "Fold 3-Bet"), ("cbet_flop", "C-Bet"), ("fold_to_cbet", "Fold C-Bet")]

_POS_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "NvtTracker")
_POS_FILE = os.path.join(_POS_DIR, "hud_overlay_pos.json")
_LOCK_FILE = os.path.join(_POS_DIR, "hud_locked.flag")   # existe = HUD fixada (sem arrastar)
_AUTO_FILE = os.path.join(_POS_DIR, "hud_auto.flag")     # existe = pedido de auto-organizar
_REF_W = 3840.0                                          # largura de referência p/ auto-escala

# posições (fração do TILE da mesa) onde a caixinha fica embaixo de cada assento (oval 9-max).
# APROX. — calibrável; o usuário afina arrastando e fica salvo.
SEAT_SLOTS = {
    0: (0.50, 0.80), 1: (0.19, 0.72), 2: (0.06, 0.46), 3: (0.16, 0.22), 4: (0.40, 0.13),
    5: (0.60, 0.13), 6: (0.84, 0.22), 7: (0.94, 0.46), 8: (0.81, 0.72),
}


def _grid_dims(n):
    """Grade de tiles (cols, rows) pelo nº de mesas tiladas na janela."""
    return {0: (1, 1), 1: (1, 1), 2: (2, 1), 3: (2, 2), 4: (2, 2), 5: (3, 2), 6: (3, 2)}.get(n, (3, 3))


# sentido da rotação dos assentos (horário=+1); calibrável após teste ao vivo.
ROTATE_DIR = 1


def seat_slot(seat, hero_seat, max_seats=9):
    """Índice do SLOT no oval (0=embaixo) p/ um assento. Com hero_seat conhecido, ROTACIONA
    pondo o HERÓI embaixo (slot 0) e os demais em volta; sem herói (observando), usa o seatid
    direto. mod max_seats. (SEAT_SLOTS tem 9 posições; p/ mesas 9-max o índice bate 1:1.)"""
    m = int(max_seats or 9)
    if hero_seat is None:
        return int(seat) % m
    return (ROTATE_DIR * (int(seat) - int(hero_seat))) % m


def poker_window():
    """Retângulo da janela ÚNICA do PPPoker (as mesas são tiladas por dentro dela). As caixas
    ancoram NELA: seguem quando ela move/redimensiona e a auto-escala sai da largura dela.
    Devolve {x,y,w,h} ou None."""
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return None
    try:
        import psutil
        pids = {p.pid for p in psutil.process_iter(["name"]) if "pppoker" in (p.info["name"] or "").lower()}
    except Exception:
        pids = set()
    u = ctypes.windll.user32
    best = {"a": 0, "r": None}
    proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _l):
        if not u.IsWindowVisible(hwnd):
            return True
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        n = u.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(hwnd, buf, n + 1)
        title = buf.value or ""
        if pid.value not in pids and "pppoker" not in title.lower():
            return True
        r = wintypes.RECT()
        u.GetWindowRect(hwnd, ctypes.byref(r))
        w, h = r.right - r.left, r.bottom - r.top
        if w > 100 and h > 100 and w * h > best["a"]:   # a MAIOR janela do PPPoker = a das mesas
            best.update(a=w * h, r={"x": r.left, "y": r.top, "w": w, "h": h})
        return True

    try:
        u.EnumWindows(proto(cb), 0)
    except Exception:
        return None
    return best["r"]


def _num(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _pct(v):
    return "–" if v is None else f"{v:.0f}%"


def box_cells(player: dict) -> dict:
    """PURO (testável): painel de UM jogador. `player` traz os stats (chaves LABELS) e, quando
    há snapshot ao vivo, o cabeçalho (nick/pos/bb/bounty). Cores = stat_color (VPIP/PFR/3Bet)."""
    def cell(stat, label):
        v = _num(player.get(LABELS[stat]))
        return (label, _pct(v), stat_color(stat, v))

    hands = int(_num(player.get("Mãos")) or 0)
    wt = _num(player.get(LABELS["wtsd"]))
    ws = _num(player.get(LABELS["wsd"]))
    bb = _num(player.get("bb") if player.get("bb") is not None else player.get("Stack (bb)"))
    bounty = _num(player.get("bounty"))
    nick = str(player.get("nick") or player.get("Jogador") or "")
    pos = str(player.get("pos") or player.get("Pos") or "")
    head = nick
    if pos:
        head += f" · {pos}"
    if bb is not None:
        head += f" · {bb:.0f}bb"
    if bounty:
        head += f" · 🏆{bounty:.0f}"
    # MINI-HUD (1 linha na mesa): VPIP · PFR · Steal · 3Bet (sem rótulo, estilo PPPoker).
    mini = [(_pct(_num(player.get(LABELS[s]))).replace("%", ""), stat_color(s, _num(player.get(LABELS[s]))))
            for s in ("vpip", "pfr", "steal", "three_bet")]
    return {
        "header": head, "nick": nick, "pos": pos, "mini": mini,
        "rows": [[cell(s, l) for s, l in ROW1], [cell(s, l) for s, l in ROW2]],
        "meta": [("ITM", "–"), ("Título", "–"), ("Total de mãos", f"{hands:,}".replace(",", "."))],
        "wtsd": (_pct(wt), (wt or 0) / 100.0),
        "wsd": (_pct(ws), (ws or 0) / 100.0),
    }


def load_positions() -> dict:
    try:
        with open(_POS_FILE, encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return {}
    out = {}
    for k, v in (raw or {}).items():
        if isinstance(v, list) and len(v) >= 2:
            out[k] = {"x": v[0], "y": v[1], "scale": 1.0}
        elif isinstance(v, dict):
            out[k] = v
    return out


def save_positions(pos: dict) -> None:
    try:
        os.makedirs(_POS_DIR, exist_ok=True)
        with open(_POS_FILE, "w", encoding="utf-8") as f:
            json.dump(pos, f)
    except Exception:
        pass


def read_tiles(live_dir: str) -> dict | None:
    """Ordem de roomids das páginas (tiles) que o capturador leu da UI: {order:[...], total}."""
    try:
        with open(os.path.join(live_dir or "", "_tiles.json"), encoding="utf-8") as f:
            d = json.load(f)
        return d if d.get("order") else None
    except Exception:
        return None


def _raw_roomid(tag: str) -> str:
    """Extrai o roomid cru do table_id ('live_r14603946' -> '14603946')."""
    return tag.split("_r")[-1] if "_r" in tag else tag


def read_snapshots(live_dir: str) -> dict:
    """{table_id: snapshot} dos _live/*.json (exceto _tiles.json) — p/ hero_seat/max_seats na rotação."""
    out = {}
    for path in glob.glob(os.path.join(live_dir or "", "*.json")):
        if os.path.basename(path) == "_tiles.json":
            continue
        try:
            with open(path, encoding="utf-8") as f:
                snap = json.load(f)
            out[str(snap.get("table_id"))] = snap
        except Exception:
            continue
    return out


def read_live(live_dir: str) -> dict:
    """{table_id: {seat: {uid, nick, pos, bb, bounty}}} dos snapshots do capturador."""
    out = {}
    for path in glob.glob(os.path.join(live_dir or "", "*.json")):
        try:
            with open(path, encoding="utf-8") as f:
                snap = json.load(f)
            tid = str(snap.get("table_id") or os.path.splitext(os.path.basename(path))[0])
            out[tid] = {int(s["seat"]): s for s in snap.get("seats", []) if s.get("seat") is not None}
        except Exception:
            continue
    return out


def stats_by_uid(conn, uids):
    """{uid: {LABELS[stat]: pct}} do stat_acc (torneio), p/ o corpo das caixas por uid."""
    uids = [str(u) for u in uids if u]
    if not uids:
        return {}
    rows = conn.execute(
        "SELECT player_id, stat_id, opps, cases FROM stat_acc WHERE player_id = ANY(%s) AND format='tournament'",
        (uids,)).fetchall()
    out = {}
    for pid, stat, opps, cases in rows:
        d = out.setdefault(str(pid), {})
        if stat in LABELS:
            d[LABELS[stat]] = (100.0 * cases / opps) if opps else None
        if stat == "vpip":
            d["Mãos"] = opps
    return out


class PlayerBox:
    """Mini-HUD de 1 LINHA na mesa (pos · nick · números-chave). CLICAR abre o POPUP com o
    painel completo. Arrastar move; roda/＋－ redimensiona; botão direito esconde."""

    def __init__(self, tk, owner, key, state, on_change, on_hide):
        self.tk, self.owner, self.root = tk, owner, owner.root
        self.key, self.on_change, self.on_hide = key, on_change, on_hide
        self.scale = float(state.get("scale", 1.0))
        self.rel = state.get("rel")          # [rx, ry] relativo à janela do PPPoker (âncora)
        self.top = tk.Toplevel(owner.root)
        self.top.overrideredirect(True)
        self.top.attributes("-topmost", True)
        try:
            self.top.attributes("-alpha", 0.95)
        except Exception:
            pass
        self.top.geometry(f"+{int(state.get('x', 60))}+{int(state.get('y', 60))}")
        self.holder = tk.Frame(self.top, bg=BG)
        self.holder.pack()
        self._drag = {"x": 0, "y": 0}
        self._moved = False
        self._last = None
        self.popup = None
        self._bind(self.top)

    def _f(self, px):
        return max(6, int(round(px * self.scale)))

    def _bind(self, w):
        w.bind("<Button-1>", self._start)
        w.bind("<B1-Motion>", self._move)
        w.bind("<ButtonRelease-1>", self._end)
        w.bind("<Button-3>", lambda e: self.on_hide(self.key))
        w.bind("<MouseWheel>", self._wheel)
        w.bind("<Button-4>", lambda e: self._zoom(+1))
        w.bind("<Button-5>", lambda e: self._zoom(-1))

    def _start(self, e):
        self._moved = False
        self._drag = {"x": e.x_root - self.top.winfo_x(), "y": e.y_root - self.top.winfo_y()}

    def _move(self, e):
        if self.owner.locked:            # HUD fixada: não arrasta (só segue a janela)
            return
        self._moved = True
        self.top.geometry(f"+{e.x_root - self._drag['x']}+{e.y_root - self._drag['y']}")

    def _end(self, e):
        if self._moved:
            win = self.owner._win
            if win and win["w"] and win["h"]:   # guarda a posição RELATIVA à janela do PPPoker
                self.rel = [(self.top.winfo_x() - win["x"]) / win["w"], (self.top.winfo_y() - win["y"]) / win["h"]]
            self._persist()
        else:
            self._toggle_popup()      # clique sem arrastar = abre/fecha o popup

    def apply_window(self, win):
        """Reposiciona a caixa ANCORADA na janela do PPPoker (segue move/resize)."""
        if not win or not self.rel:
            return
        x = int(win["x"] + self.rel[0] * win["w"])
        y = int(win["y"] + self.rel[1] * win["h"])
        if (x, y) != (self.top.winfo_x(), self.top.winfo_y()):
            self.top.geometry(f"+{x}+{y}")

    def _wheel(self, e):
        self._zoom(1 if e.delta > 0 else -1)

    def _zoom(self, d):
        self.scale = min(2.4, max(0.5, round(self.scale + 0.1 * d, 2)))
        if self._last:
            self.render(self._last)
        self._persist()

    def _persist(self):
        self.on_change(self.key, {"x": self.top.winfo_x(), "y": self.top.winfo_y(),
                                  "scale": self.scale, "rel": self.rel})

    # ---------------- mini-HUD (1 linha na mesa) ----------------
    def render(self, cells: dict):
        self._last = cells
        tk = self.tk
        for w in self.holder.winfo_children():
            w.destroy()
        panel = tk.Frame(self.holder, bg=BG, highlightthickness=1, highlightbackground="#30363d")
        panel.pack()
        line = tk.Frame(panel, bg=BG)
        line.pack(padx=self._f(2), pady=0)
        self._bind(panel); self._bind(line)
        fs = self._f(7)
        pos = cells.get("pos") or ""
        if pos:
            lp = tk.Label(line, text=pos, bg=BG, fg="#7ee787", font=("Segoe UI", fs, "bold"), padx=0)
            lp.pack(side="left", padx=(0, self._f(2))); self._bind(lp)
        nick = (cells.get("nick") or "")
        if len(nick) > 10:
            nick = nick[:10]
        ln = tk.Label(line, text=nick, bg=BG, fg="#e6edf3", font=("Segoe UI", fs, "bold"), padx=0)
        ln.pack(side="left", padx=(0, self._f(2))); self._bind(ln)
        for text, color in cells.get("mini", []):
            lb = tk.Label(line, text=text, bg=BG, fg=CELL.get(color, FG),
                          font=("Segoe UI", fs, "bold"), padx=0)
            lb.pack(side="left", padx=(0, self._f(1))); self._bind(lb)
        if self.popup is not None:
            self._fill_popup(cells)

    # ---------------- popup completo (ao clicar) ----------------
    def _toggle_popup(self):
        if self.popup is not None:
            self._close_popup()
        else:
            self._open_popup()

    def _close_popup(self, *_a):
        try:
            self.popup.destroy()
        except Exception:
            pass
        self.popup = None

    def _open_popup(self):
        tk = self.tk
        self.popup = tk.Toplevel(self.root)
        self.popup.overrideredirect(True)
        self.popup.attributes("-topmost", True)
        self.popup.geometry(f"+{self.top.winfo_x()}+{self.top.winfo_y() + self.top.winfo_height() + 2}")
        self.popup_body = tk.Frame(self.popup, bg=BG)
        self.popup_body.pack()
        if self._last:
            self._fill_popup(self._last)

    def _popup_drag_start(self, e):
        self._pdrag = {"x": e.x_root - self.popup.winfo_x(), "y": e.y_root - self.popup.winfo_y()}

    def _popup_drag(self, e):
        self.popup.geometry(f"+{e.x_root - self._pdrag['x']}+{e.y_root - self._pdrag['y']}")

    def _fill_popup(self, cells):
        tk = self.tk
        if self.popup is None:
            return
        for w in self.popup_body.winfo_children():
            w.destroy()
        s = max(self.scale, 1.0)

        def f(px):
            return max(7, int(round(px * s)))

        panel = tk.Frame(self.popup_body, bg=BG, highlightthickness=1, highlightbackground="#30363d")
        panel.pack()
        # título arrastável + fechar
        bar = tk.Frame(panel, bg="#161b22")
        bar.grid(row=0, column=0, columnspan=4, sticky="ew")
        bar.columnconfigure(0, weight=1)
        head = tk.Label(bar, text=cells["header"], bg="#161b22", fg="#e6edf3",
                        font=("Segoe UI", f(9), "bold"), anchor="w", padx=f(4))
        head.grid(row=0, column=0, sticky="w")
        for w in (bar, head):
            w.bind("<Button-1>", self._popup_drag_start)
            w.bind("<B1-Motion>", self._popup_drag)
        x = tk.Label(bar, text="✕", bg="#21262d", fg=FG, font=("Segoe UI", f(9), "bold"), padx=f(5), cursor="hand2")
        x.grid(row=0, column=1)
        x.bind("<Button-1>", self._close_popup)

        def put(parent, r, c, big, small, color):
            cf = tk.Frame(parent, bg=BG)
            cf.grid(row=r, column=c, padx=f(5), pady=f(3), sticky="nsew")
            tk.Label(cf, text=big, bg=BG, fg=color, font=("Segoe UI", f(15), "bold")).pack()
            tk.Label(cf, text=small, bg=BG, fg=SUB, font=("Segoe UI", f(7))).pack()

        grid = tk.Frame(panel, bg=BG)
        grid.grid(row=1, column=0, columnspan=4, padx=f(4), pady=(f(2), 0))
        for r, rc in enumerate(cells["rows"]):
            for c, (label, text, color) in enumerate(rc):
                put(grid, r, c, text, label, CELL.get(color, FG))
        meta = tk.Frame(panel, bg=BG)
        meta.grid(row=2, column=0, columnspan=4, padx=f(4))
        for c, (label, text) in enumerate(cells["meta"]):
            put(meta, 0, c, text, label, FG)
        wt_txt, wt_frac = cells["wtsd"]
        ws_txt, _ = cells["wsd"]
        bw = tk.Frame(panel, bg=BG)
        bw.grid(row=3, column=0, columnspan=4, sticky="ew", padx=f(4), pady=(f(3), 0))
        tk.Label(bw, text=f"WTSD {wt_txt}", bg=BG, fg="#d29922", font=("Segoe UI", f(8), "bold")).pack(side="left")
        tk.Label(bw, text=f"{ws_txt} W$SD", bg=BG, fg="#3fb950", font=("Segoe UI", f(8), "bold")).pack(side="right")
        w = max(f(230), 140)
        bar2 = tk.Canvas(panel, height=f(6), width=w, bg=LINE, highlightthickness=0)
        bar2.grid(row=4, column=0, columnspan=4, sticky="ew", padx=f(4), pady=(0, f(4)))
        bar2.create_rectangle(0, 0, int(w * min(1.0, wt_frac)), f(6), fill="#d29922", width=0)

    def destroy(self):
        self._close_popup()
        try:
            self.top.destroy()
        except Exception:
            pass


class Overlay:
    def __init__(self, dsn, *, minutes=30, refresh=3, live_dir=None):
        import tkinter as tk
        self.tk = tk
        self.dsn, self.minutes, self.refresh, self.live_dir = dsn, minutes, max(1, refresh), live_dir
        self.root = tk.Tk()
        self.root.withdraw()
        self.state = load_positions()
        self.hidden = set()
        self.boxes = {}
        self._win = None            # retângulo da janela do PPPoker (âncora)
        self.locked = False         # HUD fixada (não arrasta)
        self._tick()

    def _on_change(self, key, st):
        self.state[key] = st
        save_positions(self.state)

    def _on_hide(self, key):
        self.hidden.add(key)
        b = self.boxes.pop(key, None)
        if b:
            b.destroy()

    def _auto_arrange(self, keys):
        """Distribui as mesas (roomid) nos tiles da janela e põe cada assento no seu slot
        (SEAT_SLOTS). Usa a ORDEM REAL dos tiles (_tiles.json, lida da UI do PPPoker) quando
        existir; senão cai p/ ordem por roomid. Grava a posição RELATIVA (apply_window segue/escala)."""
        tids = sorted({k.split("|")[0] for k in keys})
        tiles = read_tiles(self.live_dir)
        snaps = read_snapshots(self.live_dir)
        if tiles:
            order = {str(r): i for i, r in enumerate(tiles["order"])}   # roomid cru -> índice do tile
            idx = {}
            nxt = len(tiles["order"])
            for tid in tids:
                raw = _raw_roomid(tid)
                if raw in order:
                    idx[tid] = order[raw]
                else:
                    idx[tid] = nxt; nxt += 1
            cols, rows = _grid_dims(max(tiles.get("total", 0), len(tids)))
        else:
            cols, rows = _grid_dims(len(tids))
            idx = {tid: i for i, tid in enumerate(tids)}
        for key in keys:
            tid, seat = key.split("|")
            i = idx[tid]
            col, row = i % cols, i // cols
            snap = snaps.get(tid, {})
            slot = seat_slot(int(seat), snap.get("hero_seat"), snap.get("max_seats", 9))  # rotação herói-embaixo
            sx, sy = SEAT_SLOTS.get(slot, (0.5, 0.5))
            rel = [(col + sx) / cols, (row + sy) / rows]
            st = dict(self.state.get(key, {}))
            st["rel"] = rel
            self.state[key] = st
            if key in self.boxes:
                self.boxes[key].rel = rel
        save_positions(self.state)

    def _rows_from_live(self, conn):
        """Caixas a partir dos snapshots ao vivo (cabeçalho) + stats do banco por uid."""
        live = read_live(self.live_dir)
        if not live:
            return None
        uids = {str(s.get("uid")) for seats in live.values() for s in seats.values() if s.get("uid")}
        stats = stats_by_uid(conn, uids)
        out = []
        for tid, seats in live.items():
            for seat, s in sorted(seats.items()):
                row = dict(stats.get(str(s.get("uid")), {}))
                row.update({"nick": s.get("nick"), "pos": s.get("pos"), "bb": s.get("bb"),
                            "bounty": s.get("bounty"), "Jogador": s.get("uid")})
                out.append((f"{tid}|{seat}", row))
        return out

    def _rows_from_db(self, conn):
        out = []
        for t in active_tables(conn, minutes=self.minutes):
            df = t.get("players")
            tag = str(t.get("table_id") or t.get("room"))
            if df is None:
                continue
            for _, r in df.iterrows():
                out.append((f"{tag}|{int(_num(r.get('Assento')) or 0)}", r.to_dict()))
        return out

    def _tick(self):
        try:
            self._win = poker_window()
            self.locked = os.path.exists(_LOCK_FILE)
            auto = max(0.5, min(1.4, (self._win["w"] / _REF_W) if self._win else 1.0))  # tamanho pela resolução
            from ..db import connect
            with connect(self.dsn) as conn:
                rows = self._rows_from_live(conn)
                if rows is None:
                    rows = self._rows_from_db(conn)
            if os.path.exists(_AUTO_FILE):           # pedido de auto-organizar (botão do painel)
                self._auto_arrange([k for k, _ in rows])
                try:
                    os.remove(_AUTO_FILE)
                except Exception:
                    pass
            seen = set()
            for i, (key, player) in enumerate(rows):
                seen.add(key)
                if key in self.hidden:
                    continue
                cells = box_cells(player)
                box = self.boxes.get(key)
                if box is None:
                    st = self.state.get(key) or {"x": 60 + (i % 3) * 250, "y": 60 + (i // 3) * 200, "scale": auto}
                    box = PlayerBox(self.tk, self, key, st, self._on_change, self._on_hide)
                    self.boxes[key] = box
                box.render(cells)
                box.apply_window(self._win)    # ancora/segue a janela do PPPoker
            for key in [k for k in self.boxes if k not in seen]:
                self.boxes.pop(key).destroy()
        except Exception as e:  # noqa: BLE001
            print("[hud-overlay] erro:", type(e).__name__, e, flush=True)
        self.root.after(self.refresh * 1000, self._tick)

    def run(self):
        self.root.mainloop()


def main() -> int:
    ap = argparse.ArgumentParser(description="HUD overlay por jogador (PPPoker VIP): dinâmico, arrastável, redimensionável")
    ap.add_argument("--dsn")
    ap.add_argument("--minutes", type=int, default=30)
    ap.add_argument("--refresh", type=int, default=3)
    ap.add_argument("--live-dir", default=os.environ.get("NVT_LIVE_DIR", r"C:\NVTLIVE\_live"),
                    help="pasta dos snapshots do capturador (cabeçalho ao vivo)")
    a = ap.parse_args()
    Overlay(resolve_dsn(a.dsn), minutes=a.minutes, refresh=a.refresh, live_dir=a.live_dir).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
