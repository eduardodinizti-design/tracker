"""Replay VISUAL de uma mão (fase 2). PURO: `replay_states(hand)` devolve o estado da mesa
passo a passo (stacks, aposta na rua, fold, board, pote, de quem é a vez). `svg_table(state)`
desenha a mesa em SVG. O painel (analise.py) usa um slider sobre os estados."""
from __future__ import annotations

import math

from ..models import ActionType, Hand, Street

_BOARD = {Street.PREFLOP: 0, Street.FLOP: 3, Street.TURN: 4, Street.RIVER: 5}
_VERB = {ActionType.FOLD: "fold", ActionType.CHECK: "check", ActionType.CALL: "call",
         ActionType.BET: "bet", ActionType.RAISE: "raise", ActionType.POST_SB: "SB",
         ActionType.POST_BB: "BB", ActionType.POST_ANTE: "ante", ActionType.POST_OTHER: "post"}
_POSTS = {ActionType.POST_SB, ActionType.POST_BB, ActionType.POST_ANTE, ActionType.POST_OTHER}


def replay_states(hand: Hand) -> list[dict]:
    """Lista de estados (um por ação). Cada estado: {label, street, board, pot, acting, seats[]}."""
    seats = {p.seat: {"seat": p.seat, "name": p.name, "stack": float(p.stack or 0), "bet": 0.0,
                      "invested": 0.0, "folded": False, "cards": list(p.cards or []), "pos": p.position or ""}
             for p in hand.players}
    by_name = {p.name: p.seat for p in hand.players}
    board = [str(c) for c in (hand.board or [])]
    states: list[dict] = []
    street = Street.PREFLOP

    def snap(label, acting):
        pot = sum(s["invested"] for s in seats.values())
        return {"label": label, "street": street.value, "board": board[:_BOARD[street]], "pot": round(pot),
                "acting": acting,
                "seats": [{"seat": s["seat"], "name": s["name"], "pos": s["pos"], "stack": round(s["stack"]),
                           "bet": round(s["bet"]), "folded": s["folded"], "cards": s["cards"]}
                          for s in sorted(seats.values(), key=lambda x: x["seat"])]}

    for a in hand.actions:
        seat = by_name.get(a.player)
        if seat is None:
            continue
        if a.street != street:                 # nova rua: zera as apostas da rua
            for s in seats.values():
                s["bet"] = 0.0
            street = a.street
        s = seats[seat]
        amt = float(a.amount or 0)
        if a.type in _POSTS:
            s["invested"] += amt; s["stack"] -= amt
            if a.type != ActionType.POST_ANTE:
                s["bet"] += amt
            label = f"{a.player}: {_VERB[a.type]} {amt:g}"
        elif a.type == ActionType.FOLD:
            s["folded"] = True; label = f"{a.player}: fold"
        elif a.type == ActionType.CHECK:
            label = f"{a.player}: check"
        elif a.type == ActionType.RAISE:
            to = float(a.amount_to or (s["bet"] + amt)); inc = to - s["bet"]
            s["bet"] = to; s["invested"] += inc; s["stack"] -= inc
            label = f"{a.player}: raise p/ {to:g}"
        else:  # CALL / BET
            s["bet"] += amt; s["invested"] += amt; s["stack"] -= amt
            label = f"{a.player}: {_VERB.get(a.type, 'bet')} {amt:g}"
        states.append(snap(label, seat))
    return states or [snap("(sem ações)", None)]


# ------------------------------------------------------------------ SVG
_RED = {"h", "d"}


def _card_svg(x, y, card, w=24, h=32):
    if not card or len(card) < 2:
        return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="#2b3340" stroke="#3a414d"/>'
    rank, suit = card[0], card[1].lower()
    sym = {"s": "♠", "h": "♥", "d": "♦", "c": "♣"}.get(suit, suit)
    col = "#e5484d" if suit in _RED else "#1a1a1a"
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="#f5f5f5" stroke="#999"/>'
            f'<text x="{x + w / 2}" y="{y + 14}" font-size="12" font-weight="bold" fill="{col}" '
            f'text-anchor="middle">{rank}</text>'
            f'<text x="{x + w / 2}" y="{y + 28}" font-size="13" fill="{col}" text-anchor="middle">{sym}</text>')


def svg_table(state: dict, width: int = 680, height: int = 440) -> str:
    cx, cy, rx, ry = width / 2, height / 2, width * 0.40, height * 0.33
    seats = state["seats"]
    n = max(len(seats), 1)
    out = [f'<svg viewBox="0 0 {width} {height}" width="100%" xmlns="http://www.w3.org/2000/svg">']
    out.append(f'<ellipse cx="{cx}" cy="{cy}" rx="{rx + 30}" ry="{ry + 30}" fill="#14532d" stroke="#0b3d20" stroke-width="3"/>')
    # board + pote no centro
    board = state.get("board") or []
    bw = 28
    bx = cx - (len(board) * bw) / 2
    for i, c in enumerate(board):
        out.append(_card_svg(bx + i * bw, cy - 16, c))
    out.append(f'<text x="{cx}" y="{cy + 34}" font-size="14" fill="#e6edf3" text-anchor="middle" '
               f'font-weight="bold">Pote: {state["pot"]:g}</text>')
    # assentos ao redor da elipse (1º embaixo)
    for i, s in enumerate(seats):
        ang = math.radians(90 + i * 360 / n)
        px, py = cx + rx * math.cos(ang), cy + ry * math.sin(ang)
        acting = (s["seat"] == state.get("acting"))
        op = "0.4" if s["folded"] else "1"
        stroke = "#f0c000" if acting else "#3a414d"
        out.append(f'<g opacity="{op}">')
        out.append(f'<rect x="{px - 55}" y="{py - 20}" width="110" height="40" rx="6" fill="#11151c" '
                   f'stroke="{stroke}" stroke-width="{3 if acting else 1}"/>')
        nm = (s["name"] or "")[:9]
        out.append(f'<text x="{px}" y="{py - 5}" font-size="11" fill="#e6edf3" text-anchor="middle" '
                   f'font-weight="bold">{nm} {("· " + s["pos"]) if s["pos"] else ""}</text>')
        out.append(f'<text x="{px}" y="{py + 11}" font-size="11" fill="#8b93a3" text-anchor="middle">{s["stack"]:g}</text>')
        # cartas do jogador (se conhecidas)
        if s["cards"]:
            start = px - (len(s["cards"]) * 15) / 2
            for j, c in enumerate(s["cards"]):
                out.append(_card_svg(start + j * 15, py - 56, c, w=14, h=20))
        # aposta atual (fichas) entre o assento e o centro
        if s["bet"]:
            cxp, cyp = px + (cx - px) * 0.32, py + (cy - py) * 0.32
            out.append(f'<circle cx="{cxp}" cy="{cyp}" r="9" fill="#d29922"/>')
            out.append(f'<text x="{cxp}" y="{cyp - 14}" font-size="11" fill="#ffd866" text-anchor="middle">{s["bet"]:g}</text>')
        out.append('</g>')
    out.append('</svg>')
    return "".join(out)
