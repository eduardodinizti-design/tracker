/* NVT Tracker — shell compartilhado: injeta a nav lateral e a barra de topo em cada tela. */
(function () {
  const ICON = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    bars: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
    cal:  '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    users:'<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/><path d="M17 15c2 0 4 2 4 5"/>',
    cards:'<rect x="4" y="3" width="11" height="15" rx="2"/><rect x="9" y="6" width="11" height="15" rx="2"/>',
    hud:  '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
    book: '<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2z"/><path d="M4 19V5"/>',
    down: '<path d="M12 3v12M8 11l4 4 4-4"/><path d="M4 21h16"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.1-1l2-1.6-2-3.4-2.3 1a7 7 0 00-1.7-1l-.4-2.5H10l-.4 2.5a7 7 0 00-1.7 1l-2.3-1-2 3.4 2 1.6a7 7 0 000 2l-2 1.6 2 3.4 2.3-1a7 7 0 001.7 1l.4 2.5h3.9l.4-2.5a7 7 0 001.7-1l2.3 1 2-3.4-2-1.6c.1-.3.1-.7.1-1z"/>',
    chev: '<path d="M6 9l6 6 6-6"/>'
  };
  const NAV = [
    ['overview', 'Visão geral', 'home', 'nvt_app.html'],
    ['resultados', 'Resultados', 'bars', 'resultados.html'],
    ['sessoes', 'Sessões', 'cal', 'sessoes.html'],
    ['jogadores', 'Jogadores', 'users', 'jogadores.html'],
    ['maos', 'Mãos', 'cards', 'explorador.html'],
    ['estatisticas', 'Estatísticas', 'bars', 'estatisticas.html'],
    ['hud', 'HUD Studio', 'hud', 'hud_biblioteca.html'],
    ['estudo', 'Estudo', 'book', 'caderno.html'],
    ['importacoes', 'Importações', 'down', 'importacoes.html'],
    ['config', 'Configurações', 'gear', 'config.html']
  ];
  const svg = (n) => '<svg viewBox="0 0 24 24">' + ICON[n] + '</svg>';

  function navHTML(active) {
    const items = NAV.map(([k, label, ic, file]) =>
      `<a class="item${k === active ? ' active' : ''}" href="${file}">${svg(ic)}${label}</a>`).join('');
    return `<aside class="nav">
      <div class="brand"><img src="nvt_logo.png" alt="NVT">
        <div><div class="bt">NVT <span>TRACKER</span></div>
        <div class="bs">Análise · Resultados · Estudo</div></div></div>
      ${items}<div class="spacer"></div><div class="motto">NADA VENCE O TRABALHO</div></aside>`;
  }
  function crumbHTML(crumbs) {
    const parts = crumbs.map((c, i) =>
      i === crumbs.length - 1 ? `<span class="cur">${c}</span>` : `<span>${c}</span>`);
    return `<div class="crumb">${svg('home')}<span class="sep">›</span>` +
      parts.join('<span class="sep">›</span>') + `</div>`;
  }
  window.NVT = {
    shell(opts) {
      document.body.insertAdjacentHTML('afterbegin', navHTML(opts.active));
      const bar = `<div class="topbar">${crumbHTML(opts.crumb || ['Visão geral'])}
        <div class="right">
          <div class="pill" style="padding:0;overflow:hidden">
            <svg viewBox="0 0 24 24" style="margin:0 0 0 10px"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
            <input id="nvt-pid" list="nvt-plist" placeholder="Estudar jogador por ID…" autocomplete="off"
              style="background:transparent;border:0;outline:0;color:var(--txt);padding:8px 12px;width:190px;font-size:13px">
            <datalist id="nvt-plist"></datalist>
          </div>
          <div class="pill">${svg('cal')}Últimos 30 dias ${svg('chev')}</div>
          <div class="pill"><span class="av"></span>Eduardo ${svg('chev')}</div>
        </div></div>`;
      document.querySelector('.main').insertAdjacentHTML('afterbegin', bar);
      // busca global: digite/cole QUALQUER ID -> estuda esse jogador (vai pro Perfil)
      (function () {
        var inp = document.getElementById('nvt-pid'), dl = document.getElementById('nvt-plist'), t;
        if (!inp) return;
        inp.oninput = function () {
          clearTimeout(t);
          t = setTimeout(function () {
            fetch('/api/search_players?q=' + encodeURIComponent(inp.value.trim())).then(function (r) { return r.json(); })
              .then(function (d) {
                dl.innerHTML = (d.players || []).map(function (p) {
                  return '<option value="' + p.id + '">' + p.id + ' · ' + (p.hands || 0) + ' mãos</option>';
                }).join('');
              }).catch(function () {});
          }, 200);
        };
        inp.onkeydown = function (e) {
          var v = inp.value.trim();
          if (e.key === 'Enter' && v) location.href = 'perfil.html?id=' + encodeURIComponent(v.split(' ')[0]);
        };
        inp.onchange = function () {
          var v = inp.value.trim(); if (v) location.href = 'perfil.html?id=' + encodeURIComponent(v.split(' ')[0]);
        };
      })();
      // autorização: só jogadores do NVT (e-mail cadastrado). Senão, vai pro login.
      fetch('/api/auth/status').then(function (r) { return r.json(); }).then(function (s) {
        if (!s.authorized) { location.replace('login.html'); return; }
        if (s.name) {
          var pills = document.querySelectorAll('.topbar .right .pill');
          var up = pills[pills.length - 1];
          if (up) { up.lastChild.textContent = ' ' + s.name + ' '; up.title = s.email || ''; up.style.cursor = 'pointer';
            up.onclick = function () { if (confirm('Sair da conta ' + (s.email || '') + '?'))
              fetch('/api/auth/logout', { method: 'POST' }).then(function () { location.href = 'login.html'; }); }; }
        }
      }).catch(function () {});
      // banner de nova versão (auto-update)
      fetch('/api/version').then(function (r) { return r.json(); }).then(function (v) {
        if (!v || !v.update_available) return;
        var b = document.createElement('div');
        b.style.cssText = 'background:linear-gradient(90deg,#f2b50d,#8a6a12);color:#17130a;font-weight:800;' +
          'padding:9px 18px;display:flex;align-items:center;gap:12px;font-family:Arial,sans-serif';
        b.innerHTML = '✨ Nova versão <b>' + v.latest + '</b> disponível' +
          (v.notes ? ' — ' + v.notes : '') +
          ' &nbsp;·&nbsp; será aplicada automaticamente ao reabrir o NVT Tracker.' +
          '<span style="margin-left:auto;cursor:pointer;opacity:.7" onclick="this.parentNode.remove()">✕</span>';
        document.querySelector('.main').insertAdjacentHTML('afterbegin', '');
        document.querySelector('.topbar').insertAdjacentElement('afterend', b);
      }).catch(function () {});
    }
  };

  // ===== popup profundo de stat (clica numa stat -> Range / Boards / Mãos) =====
  const RANGE_STATS = { vpip:1,pfr:1,three_bet:1,four_bet:1,steal:1,squeeze:1,fold_to_3bet:1,fold_to_4bet:1,fold_to_steal:1 };
  const BOARD_STATS = { cbet_flop:1,cbet_turn:1,fold_to_cbet:1,check_raise:1 };
  const SUIT = { s:'♠',h:'♥',d:'♦',c:'♣' };
  function card(c){ return (!c||c.length<2)?'':'<span class="hc2'+(/[hd]/.test(c[1])?' red':'')+'">'+c[0]+(SUIT[c[1]]||c[1])+'</span>'; }

  window.NVT.statPopup = function (o) {   // {player, stat, label, pct}
    const tabs = [];
    if (RANGE_STATS[o.stat]) tabs.push('Range');
    if (BOARD_STATS[o.stat]) tabs.push('Boards');
    tabs.push('Mãos');
    const ov = document.createElement('div'); ov.className = 'ov';
    ov.innerHTML = '<div class="modal"><div class="mh"><span class="tt">' + (o.label || o.stat) +
      '</span><span class="pc">' + (o.pct == null ? '–' : o.pct.toFixed(1).replace('.', ',') + '%') +
      '</span><span class="x">✕</span></div><div class="subtabs" style="margin:12px 18px 0">' +
      tabs.map((t, i) => '<button class="' + (i ? '' : 'active') + '" data-t="' + t + '">' + t + '</button>').join('') +
      '</div><div class="mb" id="mbody">Carregando…</div></div>';
    document.body.appendChild(ov);
    ov.querySelector('.x').onclick = () => ov.remove();
    ov.onclick = (e) => { if (e.target === ov) ov.remove(); };
    const body = ov.querySelector('#mbody');
    const qp = 'player=' + encodeURIComponent(o.player) + '&stat=' + o.stat;

    function range() {
      fetch('/api/range?' + qp).then(r => r.json()).then(d => {
        const col = f => f == null ? ['#1a1c22', '#555'] : f >= 66 ? ['#3fb96f', '#0c0c0c'] : f >= 33 ? ['#e8c84a', '#0c0c0c'] : ['#e06a74', '#330e11'];
        body.innerHTML = '<div class="sub" style="margin:0 0 8px;font-size:12px">' + (d.sample || 0).toLocaleString('pt-BR') +
          ' oportunidades · verde=alta · amarelo=média · vermelho=baixa</div><div class="rangegrid sm" id="rg"></div>';
        const g = body.querySelector('#rg');
        (d.combos || []).forEach(c => {
          const v = (d.grid || {})[c], f = v ? v.freq : null, cc = col(f);
          const el = document.createElement('div'); el.className = 'rcell'; el.style.background = cc[0]; el.style.color = cc[1];
          el.title = c + (v ? ' — ' + f + '% (' + v.cases + '/' + v.opps + ')' : ''); el.textContent = c; g.appendChild(el);
        });
      });
    }
    function boards() {
      fetch('/api/postflop?' + qp).then(r => r.json()).then(d => {
        const rows = (d.textures || []).map(t => {
          const r = (d.rows || {})[t]; if (!r) return '';
          return '<tr><td style="text-align:left"><b>' + t + '</b></td><td style="text-align:left">' +
            (r.freq == null ? '–' : r.freq + '%') + '<span class="mbar"><i style="width:' + (r.freq || 0) + '%"></i></span></td><td>' + (r.opps || 0) + '</td></tr>';
        }).join('');
        body.innerHTML = '<table class="tbl"><thead><tr><th style="text-align:left">Textura do board</th><th style="text-align:left">Frequência</th><th>Amostra</th></tr></thead><tbody>' +
          (rows || '<tr><td colspan="3" style="color:var(--muted)">Sem amostra pós-flop.</td></tr>') + '</tbody></table>';
      });
    }
    function hands() {
      fetch('/api/hands_detailed?player=' + encodeURIComponent(o.player) + '&limit=25').then(r => r.json()).then(d => {
        const acts = a => a.map(x => '<span class="ac ' + x.kind + (x.hero ? ' hero' : '') + '">' + x.code + '</span>').join('');
        body.innerHTML = (d.hands || []).slice(0, 25).map(h => {
          const r = h.result_bb;
          return '<div style="display:flex;gap:8px;align-items:center;font-size:12px;border-bottom:1px solid var(--line2);padding:5px 0">' +
            '<span style="white-space:nowrap">' + ((h.cards || []).map(card).join('') || '—') + '</span>' +
            '<span style="color:var(--muted);width:30px">' + (h.pos || '') + '</span>' +
            '<span style="flex:1;line-height:1.8">' + acts(h.streets.preflop.acts) + '</span>' +
            '<span class="' + (r >= 0 ? 'pos' : 'neg') + '" style="font-weight:800;white-space:nowrap">' + (r >= 0 ? '+' : '') + r + '</span></div>';
        }).join('') || '<div class="sub">Sem mãos.</div>';
      });
    }
    function show(t) { body.innerHTML = 'Carregando…'; t === 'Range' ? range() : t === 'Boards' ? boards() : hands(); }
    ov.querySelectorAll('.subtabs button').forEach(b => b.onclick = () => {
      ov.querySelectorAll('.subtabs button').forEach(x => x.classList.remove('active')); b.classList.add('active'); show(b.dataset.t);
    });
    show(tabs[0]);
  };
})();
