"""Versão do NVT Tracker. O updater compara esta versão com o manifesto remoto."""
__version__ = "1.0.4"
